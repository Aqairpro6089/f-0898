import { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LoadingScreen } from './components/common/LoadingScreen';
import { AuthProvider } from './context/AuthContext';
import { SubscriptionProvider } from './context/SubscriptionContext';

// Lazy load components
const Header = lazy(() => import('./components/Header').then(m => ({ default: m.Header })));
const HomeHeader = lazy(() => import('./components/HomeHeader').then(m => ({ default: m.HomeHeader })));
const Home = lazy(() => import('./components/Home').then(m => ({ default: m.Home })));
const Footer = lazy(() => import('./components/Footer').then(m => ({ default: m.Footer })));

// Auth Routes
const AdminLogin = lazy(() => import('./components/admin/AdminLogin').then(m => ({ default: m.AdminLogin })));
const AdminDashboard = lazy(() => import('./components/admin/AdminDashboard').then(m => ({ default: m.AdminDashboard })));
const Register = lazy(() => import('./components/auth/Register').then(m => ({ default: m.Register })));
const SignIn = lazy(() => import('./components/auth/SignIn').then(m => ({ default: m.SignIn })));

// Other Routes
const PropertyListings = lazy(() => import('./components/PropertyListings').then(m => ({ default: m.PropertyListings })));
const VehicleListings = lazy(() => import('./components/VehicleListings').then(m => ({ default: m.VehicleListings })));
const PropertyRequests = lazy(() => import('./components/PropertyRequests').then(m => ({ default: m.PropertyRequests })));
const VehicleRequests = lazy(() => import('./components/VehicleRequests').then(m => ({ default: m.VehicleRequests })));

function App() {
  return (
    <Router>
      <AuthProvider>
        <SubscriptionProvider>
          <Suspense fallback={<LoadingScreen />}>
            <Routes>
              {/* Admin Routes */}
              <Route path="/admin-login" element={<AdminLogin />} />
              <Route path="/admin" element={<AdminDashboard />} />
              
              {/* Auth Routes */}
              <Route path="/register" element={<Register />} />
              <Route path="/login" element={<SignIn />} />
              
              {/* Public Routes */}
              <Route path="/" element={
                <>
                  <HomeHeader />
                  <Home />
                  <Footer />
                </>
              } />
              
              <Route path="/properties" element={
                <>
                  <Header defaultSection="real-estate" />
                  <PropertyListings />
                  <Footer />
                </>
              } />
              
              <Route path="/vehicles" element={
                <>
                  <Header defaultSection="cars" />
                  <VehicleListings />
                  <Footer />
                </>
              } />
              
              <Route path="/property-requests" element={
                <>
                  <Header defaultSection="real-estate" />
                  <PropertyRequests />
                  <Footer />
                </>
              } />
              
              <Route path="/vehicle-requests" element={
                <>
                  <Header defaultSection="cars" />
                  <VehicleRequests />
                  <Footer />
                </>
              } />

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
        </SubscriptionProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;