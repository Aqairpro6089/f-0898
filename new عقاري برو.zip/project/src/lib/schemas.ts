import { z } from 'zod';

// User schemas
export const userSchema = z.object({
  email: z.string().email('البريد الإلكتروني غير صالح'),
  username: z.string().min(3, 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل').max(20),
  full_name: z.string().min(2, 'الاسم الكامل مطلوب'),
  phone: z.string().optional(),
  country: z.string().default('ye'),
  account_type: z.enum(['personal', 'business']),
  business_name: z.string().optional(),
  business_type: z.string().optional(),
  selected_plan: z.enum(['free', 'monthly', 'annual']).default('free'),
  password: z.string().min(8, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل'),
});

// Property schemas
export const propertySchema = z.object({
  title: z.string().min(10, 'العنوان يجب أن يكون 10 أحرف على الأقل'),
  description: z.string().optional(),
  type: z.string(),
  price: z.number().positive('السعر يجب أن يكون أكبر من 0'),
  location: z.string(),
  area: z.number().optional(),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
  features: z.array(z.string()).optional(),
  images: z.array(z.string()).optional(),
});

// Vehicle schemas
export const vehicleSchema = z.object({
  title: z.string().min(10, 'العنوان يجب أن يكون 10 أحرف على الأقل'),
  description: z.string().optional(),
  make: z.string(),
  model: z.string(),
  year: z.number().min(1900).max(new Date().getFullYear() + 1),
  price: z.number().positive('السعر يجب أن يكون أكبر من 0'),
  location: z.string(),
  mileage: z.number().optional(),
  fuel_type: z.string().optional(),
  transmission: z.string().optional(),
  features: z.array(z.string()).optional(),
  images: z.array(z.string()).optional(),
});

// Request schemas
export const propertyRequestSchema = z.object({
  title: z.string().min(10, 'العنوان يجب أن يكون 10 أحرف على الأقل'),
  description: z.string().optional(),
  type: z.string(),
  location: z.string(),
  min_price: z.number().optional(),
  max_price: z.number().optional(),
  min_area: z.number().optional(),
  max_area: z.number().optional(),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
});

export const vehicleRequestSchema = z.object({
  title: z.string().min(10, 'العنوان يجب أن يكون 10 أحرف على الأقل'),
  description: z.string().optional(),
  make: z.string().optional(),
  model: z.string().optional(),
  min_year: z.number().optional(),
  max_year: z.number().optional(),
  min_price: z.number().optional(),
  max_price: z.number().optional(),
  location: z.string(),
});

// Subscription schema
export const subscriptionSchema = z.object({
  plan_id: z.string(),
  end_date: z.string(),
});