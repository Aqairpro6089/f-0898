import { supabase, handleSupabaseError } from './supabase';
import type { Database } from './database.types';
import * as schemas from './schemas';

// Admin Authentication
export const adminApi = {
  async login(username: string, password: string) {
    // Admin credentials check
    if (username === 'odaiZ' && password === '6089') {
      return { 
        success: true, 
        data: {
          id: 'admin',
          username,
          role: 'admin',
          token: 'admin-token' // In production, use proper JWT
        }
      };
    }
    return { success: false, error: 'Invalid credentials' };
  },

  async validateToken(token: string) {
    // In production, implement proper token validation
    return token === 'admin-token';
  }
};

// Properties API
export const propertiesApi = {
  async list(filters?: Partial<Database['public']['Tables']['properties']['Row']>) {
    try {
      let query = supabase.from('properties').select('*');
      
      if (filters) {
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== undefined) {
            query = query.eq(key, value);
          }
        });
      }

      const { data, error } = await query;
      
      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error: handleSupabaseError(error) };
    }
  },

  async create(data: schemas.propertySchema) {
    try {
      const validated = await schemas.propertySchema.parseAsync(data);
      const { data: property, error } = await supabase
        .from('properties')
        .insert([validated])
        .select()
        .single();

      if (error) throw error;
      return { data: property, error: null };
    } catch (error) {
      return { data: null, error: handleSupabaseError(error) };
    }
  },

  async update(id: string, data: Partial<schemas.propertySchema>) {
    try {
      const { data: property, error } = await supabase
        .from('properties')
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return { data: property, error: null };
    } catch (error) {
      return { data: null, error: handleSupabaseError(error) };
    }
  },

  async delete(id: string) {
    try {
      const { error } = await supabase
        .from('properties')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { error: null };
    } catch (error) {
      return { error: handleSupabaseError(error) };
    }
  }
};

// Export other APIs...
export * from './api/vehicles';
export * from './api/requests';
export * from './api/subscriptions';