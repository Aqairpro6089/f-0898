import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { CurrencySwitch } from './common/CurrencySwitch';

export const TopHeader = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="tw-fixed tw-top-0 tw-left-0 tw-right-0 tw-z-[1000]">
      {/* Dark Background Base */}
      <div className="tw-absolute tw-inset-0 tw-bg-[#030303]/98 tw-backdrop-blur-xl" />
      
      {/* Left-side Darker Gradient */}
      <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-black/98 tw-via-[#030303]/95 tw-to-transparent" />
      
      {/* Purple Accent */}
      <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-purple-950/98 tw-via-purple-950/20 tw-to-transparent" />
      
      {/* Subtle Border */}
      <div className="tw-absolute tw-inset-0 tw-border-b tw-border-purple-950/20" />
      
      <div className="tw-max-w-[1320px] tw-mx-auto tw-px-4">
        <div className="tw-relative tw-h-[48px] tw-flex tw-items-center tw-justify-between">
          {/* Currency Switch */}
          <div className="tw-flex tw-items-center tw-gap-4 tw-relative tw-z-10">
            <CurrencySwitch />
          </div>

          {/* User Info */}
          <div className="tw-flex tw-items-center tw-gap-6 tw-relative tw-z-10">
            {isAuthenticated && (
              <>
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-[15px] tw-text-gray-600">
                  <span>مرحباً, {user?.username}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="tw-flex tw-items-center tw-gap-2 tw-text-[15px] tw-text-gray-600 hover:tw-text-white tw-transition-colors"
                >
                  <LogOut className="tw-w-4 tw-h-4" />
                  <span>تسجيل خروج</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};