import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Building2, Car, User, Briefcase, Plus, 
  TrendingUp, DollarSign, Users, Target,
  Shield, CheckCircle, AlertTriangle
} from 'lucide-react';
import { Features } from './Features';

export const Home = () => {
  const navigate = useNavigate();
  const [accountType, setAccountType] = useState<'personal' | 'business'>('personal');

  const marketingFeatures = [
    {
      icon: TrendingUp,
      title: 'وصول أوسع',
      description: 'نصل إلى جمهور واسع من المشترين المحتملين'
    },
    {
      icon: Shield,
      title: 'حماية متكاملة',
      description: 'نظام حماية متطور لضمان أمان معاملاتك'
    },
    {
      icon: Target,
      title: 'استهداف ذكي',
      description: 'أدوات استهداف متقدمة للوصول للعملاء المناسبين'
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      {/* Hero Section with Animated Background */}
      <div className="tw-relative tw-min-h-[calc(100vh-160px)] tw-flex tw-items-center tw-justify-center tw-overflow-hidden">
        {/* Animated Background */}
        <div className="tw-absolute tw-inset-0">
          {/* Reduced Purple Gradient Overlay */}
          <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-b tw-from-purple-900/10 tw-via-transparent tw-to-black/50" />
          
          {/* Animated Purple Circles - Reduced Opacity */}
          <div className="tw-absolute tw-inset-0">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="tw-absolute tw-w-[500px] tw-h-[500px] tw-rounded-full tw-bg-purple-600/5 tw-animate-pulse"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  transform: 'translate(-50%, -50%)',
                  animationDelay: `${i * 0.5}s`,
                  filter: 'blur(100px)'
                }}
              />
            ))}
          </div>

          {/* Animated Stars - Reduced Opacity */}
          <div className="tw-absolute tw-inset-0">
            {[...Array(50)].map((_, i) => (
              <div
                key={i}
                className="tw-absolute tw-w-1 tw-h-1 tw-bg-purple-400/20 tw-rounded-full tw-animate-twinkle"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`
                }}
              />
            ))}
          </div>

          {/* Pattern Overlay */}
          <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        </div>

        {/* Content */}
        <div className="tw-container tw-mx-auto tw-px-4 tw-relative tw-z-10">
          <div className="tw-text-center">
            {/* Main Title with Gradient - Reduced Intensity */}
            <h1 className="tw-text-4xl md:tw-text-6xl lg:tw-text-7xl tw-font-bold tw-mb-8">
              <span className="tw-relative">
                <span className="tw-absolute -tw-inset-1 tw-blur-2xl tw-bg-gradient-to-r tw-from-purple-600/10 tw-via-purple-400/10 tw-to-purple-600/10" />
                <span className="tw-relative tw-bg-gradient-to-r tw-from-white tw-via-purple-100 tw-to-white tw-bg-clip-text tw-text-transparent">
                  اكتشف فرصتك الآن
                </span>
              </span>
            </h1>

            {/* Subtitle with Glow */}
            <p className="tw-text-xl tw-text-gray-400 tw-mb-12 tw-relative">
              <span className="tw-absolute -tw-inset-1 tw-blur-xl tw-bg-purple-600/10" />
              <span className="tw-relative">اختر القسم الذي تريد البحث فيه</span>
            </p>

            {/* Category Buttons */}
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-8 tw-max-w-4xl tw-mx-auto">
              {/* Properties Button */}
              <button 
                onClick={() => navigate('/properties')}
                className="tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-[#1a1a1a] tw-p-8 tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50 tw-transition-all"
              >
                {/* Button Glow Effect */}
                <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-purple-600/0 tw-via-purple-600/10 tw-to-purple-600/0 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
                
                <div className="tw-relative tw-z-10">
                  <div className="tw-bg-purple-400/10 tw-w-16 tw-h-16 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mb-6 tw-mx-auto group-hover:tw-scale-110 tw-transition-transform">
                    <Building2 className="tw-w-8 tw-h-8 tw-text-purple-400" />
                  </div>
                  
                  <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-4">عقارات</h2>
                  <p className="tw-text-gray-400">
                    ابحث عن العقارات المناسبة لك من شقق وفلل وأراضي
                  </p>
                </div>

                {/* Animated Border */}
                <div className="tw-absolute tw-inset-0 tw-rounded-2xl tw-border tw-border-transparent group-hover:tw-border-purple-400/20 tw-transition-all tw-duration-300" />
              </button>

              {/* Vehicles Button */}
              <button 
                onClick={() => navigate('/vehicles')}
                className="tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-[#1a1a1a] tw-p-8 tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50 tw-transition-all"
              >
                {/* Button Glow Effect */}
                <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-purple-600/0 tw-via-purple-600/10 tw-to-purple-600/0 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
                
                <div className="tw-relative tw-z-10">
                  <div className="tw-bg-purple-400/10 tw-w-16 tw-h-16 tw-rounded-full tw-flex tw-items-center tw-justify-center tw-mb-6 tw-mx-auto group-hover:tw-scale-110 tw-transition-transform">
                    <Car className="tw-w-8 tw-h-8 tw-text-purple-400" />
                  </div>
                  
                  <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-4">سيارات</h2>
                  <p className="tw-text-gray-400">
                    اكتشف مجموعة واسعة من السيارات الجديدة والمستعملة
                  </p>
                </div>

                {/* Animated Border */}
                <div className="tw-absolute tw-inset-0 tw-rounded-2xl tw-border tw-border-transparent group-hover:tw-border-purple-400/20 tw-transition-all tw-duration-300" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Marketing Section */}
      <section className="tw-relative tw-py-24">
        <div className="tw-absolute tw-inset-0">
          <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        </div>

        <div className="tw-container tw-mx-auto tw-px-4">
          <div className="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-16">
            {/* Left Column - Problems */}
            <div className="tw-space-y-8">
              <div className="tw-space-y-4">
                <h2 className="tw-text-3xl tw-font-bold tw-text-white">
                  حقق نجاحك في نشر وترويج مالديك من عقارات وسيارات بكل سهولة الآن
                </h2>
                <p className="tw-text-gray-400 tw-text-lg">
                  عقاري برو... الحل المثالي لترويج عقاراتك وسياراتك. من خلال منصتنا، يمكنك نشر إعلاناتك بسهولة والوصول إلى جمهور واسع من المشترين المحتملين.
                </p>
              </div>

              <div className="tw-space-y-6">
                <h3 className="tw-text-xl tw-font-bold tw-text-amber-400">المشاكل ونحن نوجد الحل...</h3>
                <div className="tw-space-y-4">
                  <div className="tw-flex tw-items-start tw-gap-4">
                    <div className="tw-p-2 tw-bg-red-400/10 tw-rounded-lg">
                      <AlertTriangle className="tw-w-5 tw-h-5 tw-text-red-400" />
                    </div>
                    <div>
                      <p className="tw-text-gray-400">
                        يشتكو البعض من ارتفاع تكلفة الإعلانات المدفوعة على فيسبوك والإنستغرام مع عدم تحقيق النتائج
                      </p>
                    </div>
                  </div>

                  <div className="tw-flex tw-items-start tw-gap-4">
                    <div className="tw-p-2 tw-bg-red-400/10 tw-rounded-lg">
                      <AlertTriangle className="tw-w-5 tw-h-5 tw-text-red-400" />
                    </div>
                    <div>
                      <p className="tw-text-gray-400">
                        غالباً ما يعاني المروجون من قلة التفاعل (الإعجابات، التعليقات، والمشاركات) مع إعلاناتهم
                      </p>
                    </div>
                  </div>

                  <div className="tw-flex tw-items-start tw-gap-4">
                    <div className="tw-p-2 tw-bg-red-400/10 tw-rounded-lg">
                      <AlertTriangle className="tw-w-5 tw-h-5 tw-text-red-400" />
                    </div>
                    <div>
                      <p className="tw-text-gray-400">
                        السوق مشبع بالإعلانات المماثلة، مما يجعل من الصعب أن تبرز إعلانات العقارات والسيارات
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Pricing Card */}
            <div className="tw-relative">
              <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-amber-400/20 tw-via-purple-600/20 tw-to-amber-400/20 tw-rounded-2xl" />
              <div className="tw-absolute tw-inset-0 tw-bg-[#1a1a1a] tw-rounded-2xl tw-m-[1px]" />
              
              <div className="tw-relative tw-bg-[#1a1a1a]/90 tw-backdrop-blur-xl tw-rounded-2xl tw-p-8 tw-shadow-2xl">
                <div className="tw-text-center tw-mb-8">
                  <h3 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-2">
                    احجز مكانك الآن مقابل 50 دولار
                  </h3>
                  <p className="tw-text-gray-400">
                    سيرتفع السعر من 50 دولار إلى 90 دولار عند وصول عدد الأعضاء إلى 8000 عضو
                  </p>
                </div>

                <div className="tw-space-y-6">
                  {/* Current Stats */}
                  <div className="tw-grid tw-grid-cols-2 tw-gap-4">
                    <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4 tw-text-center">
                      <div className="tw-text-2xl tw-font-bold tw-text-amber-400">2,640</div>
                      <div className="tw-text-sm tw-text-gray-400">عضو حالي</div>
                    </div>
                    <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4 tw-text-center">
                      <div className="tw-text-2xl tw-font-bold tw-text-purple-400">8,000</div>
                      <div className="tw-text-sm tw-text-gray-400">الهدف</div>
                    </div>
                  </div>

                  {/* Features List */}
                  <div className="tw-space-y-4">
                    {marketingFeatures.map((feature, index) => (
                      <div key={index} className="tw-flex tw-items-center tw-gap-3">
                        <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
                          <feature.icon className="tw-w-5 tw-h-5 tw-text-amber-400" />
                        </div>
                        <div>
                          <h4 className="tw-text-white tw-font-medium">{feature.title}</h4>
                          <p className="tw-text-sm tw-text-gray-400">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Important Note */}
                  <div className="tw-bg-purple-600/10 tw-border tw-border-purple-600/20 tw-rounded-lg tw-p-4">
                    <h4 className="tw-text-purple-400 tw-font-medium tw-mb-2">ملاحظة بسيطة...</h4>
                    <p className="tw-text-sm tw-text-gray-400">
                      إذا لم تشترك مبكرا وتغتنم الفرصة، سيقوم نظامنا الذكي المبني على تقنيات الذكاء الاصطناعي بتحديث الأسعار تلقائيا مع زيادة التفاعل والضغط على الموقع من المشتركين، مما سيؤدي إلى رفع سعر الباقة!
                    </p>
                  </div>

                  {/* CTA Button */}
                  <button
                    onClick={() => navigate('/register')}
                    className="tw-w-full tw-bg-gradient-to-r tw-from-amber-400 tw-to-amber-500 hover:tw-from-amber-500 hover:tw-to-amber-600 tw-text-black tw-font-medium tw-py-4 tw-rounded-xl tw-transition-all tw-duration-300 tw-relative tw-overflow-hidden"
                  >
                    <span className="tw-relative tw-z-10 tw-flex tw-items-center tw-justify-center tw-gap-2">
                      <Plus className="tw-w-5 tw-h-5" />
                      انضم الآن واستفد من العرض
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <Features />
    </div>
  );
};

export default Home;