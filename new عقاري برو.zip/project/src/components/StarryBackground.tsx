import React from 'react';

interface StarryBackgroundProps {
  children: React.ReactNode;
}

export const StarryBackground: React.FC<StarryBackgroundProps> = ({ children }) => {
  return (
    <div className="tw-relative tw-min-h-screen">
      {/* Content */}
      <div className="tw-relative tw-z-0">
        {children}
      </div>

      {/* Static Background */}
      <div className="tw-fixed tw-inset-0 -tw-z-10">
        <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-b tw-from-black/50 tw-via-transparent tw-to-black/50" />
      </div>
    </div>
  );
};