import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { 
  Database, Shield, Settings, Bell, Download, Activity,
  Crown, Lock, Users, Globe, DollarSign, Building2,
  Car, FileText, CheckCircle, AlertTriangle
} from 'lucide-react';

export const AdminSettings = () => {
  // State for all settings
  const [settings, setSettings] = useState({
    // System Settings
    automaticBackups: true,
    backupFrequency: 'Daily',
    systemLanguage: 'ar',
    defaultCurrency: 'USD',
    maintenanceMode: false,

    // Security Settings
    twoFactorAuth: false,
    sessionTimeout: '30',
    passwordPolicy: 'medium',
    ipWhitelist: true,

    // Content Settings
    premiumContentEnabled: true,
    contentModeration: true,
    autoPublish: false,
    featuredListingsLimit: '5',

    // Notification Settings
    emailNotifications: true,
    smsNotifications: true,
    pushNotifications: true,
    notificationTypes: {
      newUser: true,
      newListing: true,
      newRequest: true,
      reports: true
    },

    // Property Settings
    propertyTypes: ['شقق', 'فلل', 'بيوت'],
    propertyFeatures: ['مسبح', 'حديقة', 'موقف سيارات'],
    propertyStatuses: ['متاح', 'محجوز', 'مباع'],
    propertyValidation: true,

    // Vehicle Settings
    vehicleTypes: ['سيدان', 'SUV', 'بيك اب'],
    vehicleFeatures: ['تكييف', 'ABS', 'وسائد هوائية'],
    vehicleStatuses: ['متاح', 'محجوز', 'مباع'],
    vehicleValidation: true,

    // User Account Settings
    userVerification: true,
    businessVerification: true,
    maxListingsPerUser: '10',
    maxImagesPerListing: '10'
  });

  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');
  const [activeTab, setActiveTab] = useState('system');

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSave = async () => {
    setSaveStatus('saving');
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const tabs = [
    { id: 'system', label: 'النظام', icon: Settings },
    { id: 'security', label: 'الأمان', icon: Shield },
    { id: 'content', label: 'المحتوى', icon: FileText },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'properties', label: 'العقارات', icon: Building2 },
    { id: 'vehicles', label: 'السيارات', icon: Car },
    { id: 'users', label: 'المستخدمين', icon: Users }
  ];

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إعدادات النظام"
        subtitle="تخصيص وتكوين إعدادات النظام"
      />

      {/* Save Status Messages */}
      {saveStatus === 'success' && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-flex tw-items-center tw-gap-2">
          <CheckCircle className="tw-w-5 tw-h-5" />
          <span>تم حفظ التغييرات بنجاح</span>
        </div>
      )}

      {saveStatus === 'error' && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-flex tw-items-center tw-gap-2">
          <AlertTriangle className="tw-w-5 tw-h-5" />
          <span>حدث خطأ أثناء حفظ التغييرات</span>
        </div>
      )}

      {/* Settings Tabs */}
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
        <div className="tw-flex tw-flex-wrap tw-gap-2 tw-mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-transition-colors ${
                activeTab === tab.id
                  ? 'tw-bg-amber-400 tw-text-black'
                  : 'tw-bg-neutral-800 tw-text-gray-400 hover:tw-text-white'
              }`}
            >
              <tab.icon className="tw-w-4 tw-h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* System Settings */}
        {activeTab === 'system' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Backup Settings */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">النسخ الاحتياطي</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">النسخ الاحتياطي التلقائي</p>
                    <p className="tw-text-sm tw-text-gray-400">جدولة نسخ احتياطي منتظم للنظام</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.automaticBackups}
                      onChange={(e) => handleSettingChange('automaticBackups', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">تكرار النسخ الاحتياطي</label>
                  <select
                    value={settings.backupFrequency}
                    onChange={(e) => handleSettingChange('backupFrequency', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  >
                    <option value="Daily">يومي</option>
                    <option value="Weekly">أسبوعي</option>
                    <option value="Monthly">شهري</option>
                  </select>
                </div>
              </div>

              {/* Language & Currency */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">اللغة والعملة</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">لغة النظام</label>
                  <select
                    value={settings.systemLanguage}
                    onChange={(e) => handleSettingChange('systemLanguage', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  >
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </div>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">العملة الافتراضية</label>
                  <select
                    value={settings.defaultCurrency}
                    onChange={(e) => handleSettingChange('defaultCurrency', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  >
                    <option value="USD">USD - دولار أمريكي</option>
                    <option value="YER">YER - ريال يمني</option>
                    <option value="SAR">SAR - ريال سعودي</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Maintenance Mode */}
            <div className="tw-flex tw-items-center tw-justify-between tw-p-4 tw-bg-neutral-800 tw-rounded-xl">
              <div>
                <p className="tw-text-white">وضع الصيانة</p>
                <p className="tw-text-sm tw-text-gray-400">تفعيل وضع الصيانة للموقع</p>
              </div>
              <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.maintenanceMode}
                  onChange={(e) => handleSettingChange('maintenanceMode', e.target.checked)}
                  className="tw-sr-only tw-peer"
                />
                <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
              </label>
            </div>
          </div>
        )}

        {/* Security Settings */}
        {activeTab === 'security' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Two-Factor Authentication */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">المصادقة الثنائية</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل المصادقة الثنائية</p>
                    <p className="tw-text-sm tw-text-gray-400">تفعيل المصادقة الثنائية لجميع المستخدمين</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.twoFactorAuth}
                      onChange={(e) => handleSettingChange('twoFactorAuth', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Session Settings */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">إعدادات الجلسة</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">مدة الجلسة</label>
                  <select
                    value={settings.sessionTimeout}
                    onChange={(e) => handleSettingChange('sessionTimeout', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  >
                    <option value="15">15 دقيقة</option>
                    <option value="30">30 دقيقة</option>
                    <option value="60">ساعة واحدة</option>
                  </select>
                </div>
              </div>

              {/* Password Policy */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">سياسة كلمة المرور</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">مستوى التعقيد</label>
                  <select
                    value={settings.passwordPolicy}
                    onChange={(e) => handleSettingChange('passwordPolicy', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  >
                    <option value="low">منخفض</option>
                    <option value="medium">متوسط</option>
                    <option value="high">عالي</option>
                  </select>
                </div>
              </div>

              {/* IP Whitelist */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">القائمة البيضاء للـ IP</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل القائمة البيضاء</p>
                    <p className="tw-text-sm tw-text-gray-400">تقييد الوصول لعناوين IP محددة</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.ipWhitelist}
                      onChange={(e) => handleSettingChange('ipWhitelist', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Content Settings */}
        {activeTab === 'content' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Premium Content */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">المحتوى المميز</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل المحتوى المميز</p>
                    <p className="tw-text-sm tw-text-gray-400">عرض المحتوى المميز للمشتركين فقط</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.premiumContentEnabled}
                      onChange={(e) => handleSettingChange('premiumContentEnabled', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Content Moderation */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">مراقبة المحتوى</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل المراقبة التلقائية</p>
                    <p className="tw-text-sm tw-text-gray-400">فحص المحتوى قبل النشر</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.contentModeration}
                      onChange={(e) => handleSettingChange('contentModeration', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Featured Listings */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">الإعلانات المميزة</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">الحد الأقصى للإعلانات المميزة</label>
                  <input
                    type="number"
                    value={settings.featuredListingsLimit}
                    onChange={(e) => handleSettingChange('featuredListingsLimit', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  />
                </div>
              </div>

              {/* Auto-Publish */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">النشر التلقائي</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل النشر التلقائي</p>
                    <p className="tw-text-sm tw-text-gray-400">نشر الإعلانات تلقائياً دون مراجعة</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.autoPublish}
                      onChange={(e) => handleSettingChange('autoPublish', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Notification Settings */}
        {activeTab === 'notifications' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Email Notifications */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">إشعارات البريد الإلكتروني</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل إشعارات البريد</p>
                    <p className="tw-text-sm tw-text-gray-400">إرسال إشعارات عبر البريد الإلكتروني</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.emailNotifications}
                      onChange={(e) => handleSettingChange('emailNotifications', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* SMS Notifications */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">إشعارات الرسائل النصية</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل إشعارات SMS</p>
                    <p className="tw-text-sm tw-text-gray-400">إرسال إشعارات عبر الرسائل النصية</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.smsNotifications}
                      onChange={(e) => handleSettingChange('smsNotifications', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Push Notifications */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">إشعارات الويب</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل إشعارات الويب</p>
                    <p className="tw-text-sm tw-text-gray-400">إرسال إشعارات عبر المتصفح</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.pushNotifications}
                      onChange={(e) => handleSettingChange('pushNotifications', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Notification Types */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">أنواع الإشعارات</h3>
                <div className="tw-space-y-3">
                  {Object.entries(settings.notificationTypes).map(([key, value]) => (
                    <div key={key} className="tw-flex tw-items-center tw-justify-between">
                      <p className="tw-text-white">{
                        key === 'newUser' ? 'مستخدم جديد' :
                        key === 'newListing' ? 'إعلان جديد' :
                        key === 'newRequest' ? 'طلب جديد' :
                        'تقارير'
                      }</p>
                      <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                        <input
                          type="checkbox"
                          checked={value}
                          onChange={(e) => handleSettingChange(`notificationTypes.${key}`, e.target.checked)}
                          className="tw-sr-only tw-peer"
                        />
                        <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Property Settings */}
        {activeTab === 'properties' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Property Types */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">أنواع العقارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.propertyTypes.map((type, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {type}
                    </div>
                  ))}
                  <button className="tw-bg-amber-400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة نوع
                  </button>
                </div>
              </div>

              {/* Property Features */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">مميزات العقارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.propertyFeatures.map((feature, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {feature}
                    </div>
                  ))}
                  <button className="tw-bg-amber-400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة ميزة
                  </button>
                </div>
              </div>

              {/* Property Statuses */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">حالات العقارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.propertyStatuses.map((status, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {status}
                    </div>
                  ))}
                  <button className="tw-bg-amber-400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة حالة
                  </button>
                </div>
              </div>

              {/* Property Validation */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">التحقق من العقارات</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل التحقق من العقارات</p>
                    <p className="tw-text-sm tw-text-gray-400">التحقق من صحة معلومات العقارات</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.propertyValidation}
                      onChange={(e) => handleSettingChange('propertyValidation', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Vehicle Settings */}
        {activeTab === 'vehicles' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* Vehicle Types */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">أنواع السيارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.vehicleTypes.map((type, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {type}
                    </div>
                  ))}
                  <button className="tw-bg-amber- 400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة نوع
                  </button>
                </div>
              </div>

              {/* Vehicle Features */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">مميزات السيارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.vehicleFeatures.map((feature, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {feature}
                    </div>
                  ))}
                  <button className="tw-bg-amber-400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة ميزة
                  </button>
                </div>
              </div>

              {/* Vehicle Statuses */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">حالات السيارات</h3>
                <div className="tw-flex tw-flex-wrap tw-gap-2">
                  {settings.vehicleStatuses.map((status, index) => (
                    <div key={index} className="tw-bg-neutral-800 tw-rounded-lg tw-px-3 tw-py-1 tw-text-white">
                      {status}
                    </div>
                  ))}
                  <button className="tw-bg-amber-400 tw-text-black tw-rounded-lg tw-px-3 tw-py-1">
                    إضافة حالة
                  </button>
                </div>
              </div>

              {/* Vehicle Validation */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">التحقق من السيارات</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل التحقق من السيارات</p>
                    <p className="tw-text-sm tw-text-gray-400">التحقق من صحة معلومات السيارات</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.vehicleValidation}
                      onChange={(e) => handleSettingChange('vehicleValidation', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* User Settings */}
        {activeTab === 'users' && (
          <div className="tw-space-y-6">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              {/* User Verification */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">التحقق من المستخدمين</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل التحقق من المستخدمين</p>
                    <p className="tw-text-sm tw-text-gray-400">التحقق من هوية المستخدمين</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.userVerification}
                      onChange={(e) => handleSettingChange('userVerification', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Business Verification */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">التحقق من الحسابات التجارية</h3>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-white">تفعيل التحقق من الشركات</p>
                    <p className="tw-text-sm tw-text-gray-400">التحقق من الحسابات التجارية</p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.businessVerification}
                      onChange={(e) => handleSettingChange('businessVerification', e.target.checked)}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>

              {/* Listing Limits */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">حدود الإعلانات</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">الحد الأقصى للإعلانات لكل مستخدم</label>
                  <input
                    type="number"
                    value={settings.maxListingsPerUser}
                    onChange={(e) => handleSettingChange('maxListingsPerUser', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  />
                </div>
              </div>

              {/* Image Limits */}
              <div className="tw-space-y-4">
                <h3 className="tw-text-lg tw-font-medium tw-text-white">حدود الصور</h3>
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">الحد الأقصى للصور لكل إعلان</label>
                  <input
                    type="number"
                    value={settings.maxImagesPerListing}
                    onChange={(e) => handleSettingChange('maxImagesPerListing', e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-2 tw-text-white"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Save Button */}
        <div className="tw-flex tw-justify-end tw-mt-8">
          <button
            onClick={handleSave}
            disabled={saveStatus === 'saving'}
            className="tw-px-6 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg tw-font-medium tw-transition-colors disabled:tw-opacity-50"
          >
            {saveStatus === 'saving' ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;