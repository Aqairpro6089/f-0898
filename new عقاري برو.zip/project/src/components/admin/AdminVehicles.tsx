import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Plus, Edit2, Trash2, Filter, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const AdminVehicles = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | 'edit' | 'delete' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [editData, setEditData] = useState({
    title: '',
    price: '',
    location: '',
    type: '',
    description: ''
  });
  
  const vehicles = [
    {
      id: 1,
      title: 'تويوتا كامري 2023',
      location: 'صنعاء',
      price: '25,000',
      type: 'سيدان',
      status: 'Pending',
      description: 'سيارة حديثة بحالة ممتازة',
      agent: {
        username: 'ahmed123',
        name: 'عمار عبدالرحمن',
        accountType: 'business',
        businessName: 'Ahmed Auto'
      },
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=60'
    },
    {
      id: 2,
      title: 'هوندا اكورد 2022',
      location: 'عدن',
      price: '22,000',
      type: 'سيدان',
      status: 'Pending',
      description: 'سيارة اقتصادية وعائلية',
      agent: {
        username: 'MOhmedX1',
        name: 'محمد احمد',
        accountType: 'personal'
      },
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1630990325544-58e7ed0d18ea?w=800&auto=format&fit=crop&q=60'
    }
  ];

  const handleAction = (vehicle: any, action: 'approve' | 'reject' | 'edit' | 'delete') => {
    setSelectedVehicle(vehicle);
    setActionType(action);
    if (action === 'edit') {
      setEditData({
        title: vehicle.title,
        price: vehicle.price,
        location: vehicle.location,
        type: vehicle.type,
        description: vehicle.description
      });
    }
    setShowActionModal(true);
  };

  const handleConfirmAction = () => {
    // Here you would implement the actual action logic
    switch (actionType) {
      case 'approve':
        console.log('Approving vehicle:', selectedVehicle.id);
        break;
      case 'reject':
        console.log('Rejecting vehicle:', selectedVehicle.id, 'Reason:', rejectionReason);
        break;
      case 'edit':
        console.log('Updating vehicle:', selectedVehicle.id, 'New data:', editData);
        break;
      case 'delete':
        console.log('Deleting vehicle:', selectedVehicle.id);
        break;
    }
    setShowActionModal(false);
    setSelectedVehicle(null);
    setActionType(null);
    setRejectionReason('');
    setEditData({
      title: '',
      price: '',
      location: '',
      type: '',
      description: ''
    });
  };

  const ActionModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        {actionType === 'approve' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <CheckCircle className="tw-w-6 tw-h-6 tw-text-green-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تأكيد الموافقة</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من الموافقة على نشر هذا الإعلان؟
            </p>
          </>
        )}

        {actionType === 'reject' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <XCircle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">رفض الإعلان</h3>
            </div>
            <div className="tw-mb-6">
              <label className="tw-block tw-text-gray-300 tw-mb-2">سبب الرفض</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                rows={4}
                placeholder="اذكر سبب رفض الإعلان..."
              />
            </div>
          </>
        )}

        {actionType === 'edit' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <Edit2 className="tw-w-6 tw-h-6 tw-text-purple-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تعديل الإعلان</h3>
            </div>
            <div className="tw-space-y-4 tw-mb-6">
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">العنوان</label>
                <input
                  type="text"
                  value={editData.title}
                  onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">السعر</label>
                <input
                  type="text"
                  value={editData.price}
                  onChange={(e) => setEditData({ ...editData, price: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">الموقع</label>
                <input
                  type="text"
                  value={editData.location}
                  onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">النوع</label>
                <select
                  value={editData.type}
                  onChange={(e) => setEditData({ ...editData, type: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                >
                  <option value="سيدان">سيدان</option>
                  <option value="SUV">SUV</option>
                  <option value="بيك اب">بيك اب</option>
                </select>
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">الوصف</label>
                <textarea
                  value={editData.description}
                  onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                  rows={4}
                />
              </div>
            </div>
          </>
        )}

        {actionType === 'delete' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <AlertTriangle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">حذف الإعلان</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من حذف هذا الإعلان؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
          </>
        )}

        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowActionModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className={`tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium ${
              actionType === 'approve'
                ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                : actionType === 'reject' || actionType === 'delete'
                ? 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
                : 'tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white'
            }`}
          >
            {actionType === 'approve' && 'تأكيد الموافقة'}
            {actionType === 'reject' && 'تأكيد الرفض'}
            {actionType === 'edit' && 'حفظ التغييرات'}
            {actionType === 'delete' && 'تأكيد الحذف'}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة السيارات"
        subtitle="إدارة وتنظيم جميع السيارات"
      />

      <div className="tw-flex tw-items-center tw-justify-between">
        <div className="tw-flex tw-space-x-4">
          <button 
            onClick={() => navigate('/admin/vehicles/add')}
            className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-lg tw-font-medium tw-transition-colors"
          >
            <Plus className="tw-w-4 tw-h-4" />
            إضافة سيارة جديدة
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="tw-flex tw-items-center tw-gap-4">
        <div className="tw-relative tw-flex-1">
          <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
          <input
            type="text"
            placeholder="البحث عن السيارات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="tw-w-full tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
          />
        </div>
        
        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400">
          <option value="all">جميع الأنواع</option>
          <option value="sedan">سيدان</option>
          <option value="suv">SUV</option>
          <option value="pickup">بيك اب</option>
        </select>

        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400">
          <option value="all">جميع المناطق</option>
          <option value="sanaa">صنعاء</option>
          <option value="aden">عدن</option>
          <option value="taiz">تعز</option>
        </select>
      </div>

      {/* Vehicles Table */}
      <div className="tw-bg-neutral-800 tw-rounded-lg tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-700">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">السيارة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">النوع</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">السعر</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الحالة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">المعلن</th>
              <th className="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {vehicles.map((vehicle) => (
              <tr key={vehicle.id} className="hover:tw-bg-neutral-700/50">
                <td className="tw-px-6 tw-py-4">
                  <div className="tw-flex tw-items-center tw-gap-4">
                    <div className="tw-w-16 tw-h-16 tw-rounded-lg tw-overflow-hidden">
                      <img 
                        src={vehicle.image}
                        alt={vehicle.title}
                        className="tw-w-full tw-h-full tw-object-cover"
                      />
                    </div>
                    <div>
                      <div className="tw-text-sm tw-font-medium tw-text-white">{vehicle.title}</div>
                      <div className="tw-text-sm tw-text-gray-400">{vehicle.location}</div>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className="tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full tw-bg-purple-400/10 tw-text-purple-400">
                    {vehicle.type}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-white">
                  ${vehicle.price}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                    vehicle.status === 'Active' 
                      ? 'tw-bg-green-400/10 tw-text-green-400' 
                      : 'tw-bg-yellow-400/10 tw-text-yellow-400'
                  }`}>
                    {vehicle.status === 'Active' ? 'نشط' : 'معلق'}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div>
                    <div className="tw-text-sm tw-font-medium tw-text-white">
                      {vehicle.agent.accountType === 'business' ? vehicle.agent.businessName : vehicle.agent.name}
                    </div>
                    <div className="tw-text-sm tw-text-gray-400">@{vehicle.agent.username}</div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                  <div className="tw-flex tw-justify-end tw-gap-2">
                    {vehicle.status === 'Pending' && (
                      <>
                        <button 
                          onClick={() => handleAction(vehicle, 'approve')}
                          className="tw-p-2 tw-text-green-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="موافقة"
                        >
                          <CheckCircle className="tw-w-4 tw-h-4" />
                        </button>
                        <button 
                          onClick={() => handleAction(vehicle, 'reject')}
                          className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="رفض"
                        >
                          <XCircle className="tw-w-4 tw-h-4" />
                        </button>
                      </>
                    )}
                    <button 
                      onClick={() => handleAction(vehicle, 'edit')}
                      className="tw-p-2 tw-text-purple-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="تعديل"
                    >
                      <Edit2 className="tw-w-4 tw-h-4" />
                    </button>
                    <button 
                      onClick={() => handleAction(vehicle, 'delete')}
                      className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="tw-w-4 tw-h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Modal */}
      {showActionModal && <ActionModal />}
    </div>
  );
};

export default AdminVehicles;