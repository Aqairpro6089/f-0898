import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Plus, Edit2, Trash2, Filter, CheckCircle, XCircle, AlertTriangle, Lock, Unlock, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Property {
  id: number;
  title: string;
  location: string;
  price: string;
  type: string;
  status: string;
  isPremium: boolean;
  isLocked: boolean;
  description: string;
  image: string;
  agent: {
    username: string;
    name: string;
    accountType: string;
    businessName?: string;
  };
  createdAt: string;
}

export const AdminProperties = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<any>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | 'edit' | 'delete' | 'premium' | 'lock' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [editData, setEditData] = useState({
    title: '',
    price: '',
    location: '',
    type: '',
    description: ''
  });
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showLockModal, setShowLockModal] = useState(false);
  
  const properties = [
    {
      id: 1,
      title: 'للبيع عمارة 5 صنعاء دار سلم',
      location: 'صنعاء',
      price: '301,887',
      type: 'عمارة',
      status: 'Pending',
      isPremium: true,
      isLocked: false,
      description: 'عمارة سكنية مميزة في موقع حيوي',
      agent: {
        username: 'ahmed123',
        name: 'عمار عبدالرحمن',
        accountType: 'business',
        businessName: 'Ahmed Real Estate'
      },
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&auto=format&fit=crop&q=60'
    },
    {
      id: 2,
      title: 'شقة للبيع في صنعاء',
      location: 'صنعاء',
      price: '150,000',
      type: 'شقة',
      status: 'Pending',
      isPremium: false,
      isLocked: false,
      description: 'شقة حديثة مع إطلالة رائعة',
      agent: {
        username: 'MOhmedX1',
        name: 'محمد احمد',
        accountType: 'personal'
      },
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&auto=format&fit=crop&q=60'
    }
  ];

  const handleAction = (property: any, action: 'approve' | 'reject' | 'edit' | 'delete' | 'premium' | 'lock') => {
    setSelectedProperty(property);
    setActionType(action);
    if (action === 'edit') {
      setEditData({
        title: property.title,
        price: property.price,
        location: property.location,
        type: property.type,
        description: property.description
      });
    }
    setShowActionModal(true);
  };

  const handlePremiumToggle = (property: Property) => {
    setSelectedProperty(property);
    setShowPremiumModal(true);
  };

  const handleLockToggle = (property: Property) => {
    setSelectedProperty(property);
    setShowLockModal(true);
  };

  const confirmPremiumToggle = () => {
    if (selectedProperty) {
      console.log(`Toggling premium status for property ${selectedProperty.id}`);
    }
    setShowPremiumModal(false);
    setSelectedProperty(null);
  };

  const confirmLockToggle = () => {
    if (selectedProperty) {
      console.log(`Toggling lock status for property ${selectedProperty.id}`);
    }
    setShowLockModal(false);
    setSelectedProperty(null);
  };

  const handleConfirmAction = () => {
    switch (actionType) {
      case 'approve':
        console.log('Approving property:', selectedProperty.id);
        break;
      case 'reject':
        console.log('Rejecting property:', selectedProperty.id, 'Reason:', rejectionReason);
        break;
      case 'edit':
        console.log('Updating property:', selectedProperty.id, 'New data:', editData);
        break;
      case 'delete':
        console.log('Deleting property:', selectedProperty.id);
        break;
      case 'premium':
        confirmPremiumToggle();
        break;
      case 'lock':
        confirmLockToggle();
        break;
    }
    setShowActionModal(false);
    setSelectedProperty(null);
    setActionType(null);
    setRejectionReason('');
    setEditData({
      title: '',
      price: '',
      location: '',
      type: '',
      description: ''
    });
  };

  const ActionModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        {actionType === 'approve' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <CheckCircle className="tw-w-6 tw-h-6 tw-text-green-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تأكيد الموافقة</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من الموافقة على نشر هذا الإعلان؟
            </p>
          </>
        )}

        {actionType === 'reject' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <XCircle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">رفض الإعلان</h3>
            </div>
            <div className="tw-mb-6">
              <label className="tw-block tw-text-gray-300 tw-mb-2">سبب الرفض</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                rows={4}
                placeholder="اذكر سبب رفض الإعلان..."
              />
            </div>
          </>
        )}

        {actionType === 'edit' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <Edit2 className="tw-w-6 tw-h-6 tw-text-amber-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تعديل الإعلان</h3>
            </div>
            <div className="tw-space-y-4 tw-mb-6">
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">العنوان</label>
                <input
                  type="text"
                  value={editData.title}
                  onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">السعر</label>
                <input
                  type="text"
                  value={editData.price}
                  onChange={(e) => setEditData({ ...editData, price: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">الموقع</label>
                <input
                  type="text"
                  value={editData.location}
                  onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                />
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">النوع</label>
                <select
                  value={editData.type}
                  onChange={(e) => setEditData({ ...editData, type: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                >
                  <option value="عمارة">عمارة</option>
                  <option value="شقة">شقة</option>
                  <option value="فيلا">فيلا</option>
                </select>
              </div>
              <div>
                <label className="tw-block tw-text-gray-300 tw-mb-2">الوصف</label>
                <textarea
                  value={editData.description}
                  onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                  className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                  rows={4}
                />
              </div>
            </div>
          </>
        )}

        {actionType === 'delete' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <AlertTriangle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">حذف الإعلان</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من حذف هذا الإعلان؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
          </>
        )}

        {actionType === 'premium' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <Crown className="tw-w-6 tw-h-6 tw-text-amber-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">
                {selectedProperty?.isPremium ? 'إلغاء المحتوى المميز' : 'تعيين كمحتوى مميز'}
              </h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              {selectedProperty?.isPremium 
                ? 'هل أنت متأكد من إلغاء المحتوى المميز لهذا العقار؟'
                : 'هل أنت متأكد من تعيين هذا العقار كمحتوى مميز؟'
              }
            </p>
          </>
        )}

        {actionType === 'lock' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              {selectedProperty?.isLocked ? (
                <Unlock className="tw-w-6 tw-h-6 tw-text-green-400" />
              ) : (
                <Lock className="tw-w-6 tw-h-6 tw-text-red-400" />
              )}
              <h3 className="tw-text-xl tw-font-bold tw-text-white">
                {selectedProperty?.isLocked ? 'فتح العقار' : 'قفل العقار'}
              </h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              {selectedProperty?.isLocked 
                ? 'هل أنت متأكد من فتح هذا العقار؟'
                : 'هل أنت متأكد من قفل هذا العقار؟'
              }
            </p>
          </>
        )}

        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowActionModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className={`tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium ${
              actionType === 'approve'
                ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                : actionType === 'reject' || actionType === 'delete'
                ? 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
                : actionType === 'premium'
                ? 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
                : actionType === 'lock'
                ? selectedProperty?.isLocked
                  ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                  : 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
                : 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
            }`}
          >
            {actionType === 'approve' && 'تأكيد الموافقة'}
            {actionType === 'reject' && 'تأكيد الرفض'}
            {actionType === 'edit' && 'حفظ التغييرات'}
            {actionType === 'delete' && 'تأكيد الحذف'}
            {actionType === 'premium' && (selectedProperty?.isPremium ? 'إلغاء المميز' : 'تعيين مميز')}
            {actionType === 'lock' && (selectedProperty?.isLocked ? 'فتح' : 'قفل')}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة العقارات"
        subtitle="إدارة وتنظيم جميع العقارات"
      />

      <div className="tw-flex tw-items-center tw-justify-between">
        <div className="tw-flex tw-space-x-4">
          <button 
            onClick={() => navigate('/admin/properties/add')}
            className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg tw-font-medium tw-transition-colors"
          >
            <Plus className="tw-w-4 tw-h-4" />
            إضافة عقار جديد
          </button>
        </div>
      </div>

      <div className="tw-flex tw-items-center tw-gap-4">
        <div className="tw-relative tw-flex-1">
          <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
          <input
            type="text"
            placeholder="البحث عن العقارات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="tw-w-full tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
          />
        </div>
        
        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
          <option value="all">جميع الأنواع</option>
          <option value="apartment">شقق</option>
          <option value="villa">فلل</option>
          <option value="building">عمارات</option>
        </select>

        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
          <option value="all">جميع المناطق</option>
          <option value="sanaa">صنعاء</option>
          <option value="aden">عدن</option>
          <option value="taiz">تعز</option>
        </select>
      </div>

      <div className="tw-bg-neutral-800 tw-rounded-lg tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-700">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">العقار</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">النوع</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">السعر</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الحالة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">المعلن</th>
              <th className="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {properties.map((property) => (
              <tr key={property.id} className="hover:tw-bg-neutral-700/50">
                <td className="tw-px-6 tw-py-4">
                  <div className="tw-flex tw-items-center tw-gap-4">
                    <div className="tw-w-16 tw-h-16 tw-rounded-lg tw-overflow-hidden">
                      <img 
                        src={property.image}
                        alt={property.title}
                        className="tw-w-full tw-h-full tw-object-cover"
                      />
                    </div>
                    <div>
                      <div className="tw-text-sm tw-font-medium tw-text-white">{property.title}</div>
                      <div className="tw-text-sm tw-text-gray-400">{property.location}</div>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className="tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full tw-bg-amber-400/10 tw-text-amber-400">
                    {property.type}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-white">
                  ${property.price}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div className="tw-flex tw-items-center tw-gap-2">
                    {property.isPremium && (
                      <span className="tw-px-2 tw-py-1 tw-bg-amber-400/10 tw-text-amber-400 tw-rounded-full tw-text-xs">
                        مميز
                      </span>
                    )}
                    {property.isLocked && (
                      <span className="tw-px-2 tw-py-1 tw-bg-red-400/10 tw-text-red-400 tw-rounded-full tw-text-xs">
                        مقفل
                      </span>
                    )}
                    <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                      property.status === 'Active' 
                        ? 'tw-bg-green-400/10 tw-text-green-400' 
                        : 'tw-bg-yellow-400/10 tw-text-yellow-400'
                    }`}>
                      {property.status === 'Active' ? 'نشط' : 'معلق'}
                    </span>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div>
                    <div className="tw-text-sm tw-font-medium tw-text-white">
                      {property.agent.accountType === 'business' ? property.agent.businessName : property.agent.name}
                    </div>
                    <div className="tw-text-sm tw-text-gray-400">@{property.agent.username}</div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                  <div className="tw-flex tw-justify-end tw-gap-2">
                    <button 
                      onClick={() => handleAction(property, 'premium')}
                      className={`tw-p-2 ${
                        property.isPremium 
                          ? 'tw-text-amber-400 hover:tw-bg-neutral-700' 
                          : 'tw-text-gray-400 hover:tw-text-amber-400 hover:tw-bg-neutral-700'
                      } tw-rounded-lg tw-transition-colors`}
                      title={property.isPremium ? 'إلغاء المميز' : 'تعيين مميز'}
                    >
                      <Crown className="tw-w-4 tw-h-4" />
                    </button>

                    <button 
                      onClick={() => handleAction(property, 'lock')}
                      className={`tw-p-2 ${
                        property.isLocked 
                          ? 'tw-text-red-400 hover:tw-bg-neutral-700' 
                          : 'tw-text-gray-400 hover:tw-text-red-400 hover:tw-bg-neutral-700'
                      } tw-rounded-lg tw-transition-colors`}
                      title={property.isLocked ? 'فتح' : 'قفل'}
                    >
                      {property.isLocked ? (
                        <Lock className="tw-w-4 tw-h-4" />
                      ) : (
                        <Unlock className="tw-w-4 tw-h-4" />
                      )}
                    </button>

                    {property.status === 'Pending' && (
                      <>
                        <button 
                          onClick={() => handleAction(property, 'approve')}
                          className="tw-p-2 tw-text-green-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="موافقة"
                        >
                          <CheckCircle className="tw-w-4 tw-h-4" />
                        </button>
                        <button 
                          onClick={() => handleAction(property, 'reject')}
                          className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="رفض"
                        >
                          <XCircle className="tw-w-4 tw-h-4" />
                        </button>
                      </>
                    )}
                    <button 
                      onClick={() => handleAction(property, 'edit')}
                      className="tw-p-2 tw-text-amber-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="تعديل"
                    >
                      <Edit2 className="tw-w-4 tw-h-4" />
                    </button>
                    <button 
                      onClick={() => handleAction(property, 'delete')}
                      className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="tw-w-4 tw-h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showActionModal && <ActionModal />}
    </div>
  );
};

export default AdminProperties;