import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Activity, Users, Building2, Car, DollarSign, AlertTriangle, LogOut } from 'lucide-react';

export const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const stats = [
    { title: 'Total Users', value: '2,543', icon: Users, color: 'amber' },
    { title: 'Properties', value: '1,234', icon: Building2, color: 'amber' },
    { title: 'Vehicles', value: '567', icon: Car, color: 'purple' },
    { title: 'Revenue', value: '$12,345', icon: DollarSign, color: 'green' }
  ];

  const recentAlerts = [
    { type: 'error', message: 'Failed login attempt detected', time: '2 minutes ago' },
    { type: 'success', message: 'Database backup completed', time: '1 hour ago' },
    { type: 'info', message: 'New user registration', time: '3 hours ago' }
  ];

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'error': return 'tw-text-red-400 tw-bg-red-400/10';
      case 'success': return 'tw-text-green-400 tw-bg-green-400/10';
      case 'info': return 'tw-text-blue-400 tw-bg-blue-400/10';
      default: return 'tw-text-gray-400 tw-bg-gray-400/10';
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin-login');
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-p-8">
      {/* Header */}
      <div className="tw-flex tw-justify-between tw-items-center tw-mb-8">
        <div>
          <h1 className="tw-text-3xl tw-font-bold tw-text-white">لوحة التحكم</h1>
          <p className="tw-text-gray-400">مرحباً بك {user?.username}</p>
        </div>
        <button 
          onClick={handleLogout}
          className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-red-500/10 hover:tw-bg-red-500/20 tw-text-red-500 tw-rounded-lg"
        >
          <LogOut className="tw-w-5 tw-h-5" />
          تسجيل خروج
        </button>
      </div>

      {/* Stats Grid */}
      <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-6 tw-mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
            <div className="tw-flex tw-items-center tw-justify-between">
              <div>
                <p className="tw-text-gray-400 tw-text-sm">{stat.title}</p>
                <p className="tw-text-2xl tw-font-bold tw-text-white">{stat.value}</p>
              </div>
              <div className={`tw-bg-${stat.color}-400/10 tw-p-3 tw-rounded-lg`}>
                <stat.icon className={`tw-w-6 tw-h-6 tw-text-${stat.color}-400`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* System Alerts */}
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
        <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-6">System Alerts</h2>
        <div className="tw-space-y-4">
          {recentAlerts.map((alert, index) => (
            <div key={index} className="tw-flex tw-items-center tw-space-x-4">
              <div className={`tw-p-2 tw-rounded-lg ${getAlertColor(alert.type)}`}>
                <AlertTriangle className="tw-w-5 tw-h-5" />
              </div>
              <div>
                <p className="tw-text-white">{alert.message}</p>
                <p className="tw-text-gray-400 tw-text-sm">{alert.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;