import React, { useState, useEffect } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Edit2, Save, X, Plus, AlertTriangle } from 'lucide-react';
import { useSubscription } from '../../context/SubscriptionContext';

export const AdminSubscriptions = () => {
  const { plans, updatePlans } = useSubscription();
  const [editingPlan, setEditingPlan] = useState<string | null>(null);
  const [editData, setEditData] = useState({
    title: '',
    price: '',
    period: '',
    features: ['']
  });
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  const handleEdit = (planId: string) => {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      setEditData({
        title: plan.title,
        price: plan.price,
        period: plan.period,
        features: [...plan.features]
      });
      setEditingPlan(planId);
    }
  };

  const handleSave = (planId: string) => {
    setSaveStatus('saving');
    try {
      const updatedPlans = plans.map(plan => 
        plan.id === planId
          ? { 
              ...plan, 
              title: editData.title,
              price: editData.price,
              period: editData.period,
              features: editData.features
            }
          : plan
      );
      
      // Update plans globally through context
      updatePlans(updatedPlans);
      setEditingPlan(null);
      setSaveStatus('success');

      // Reset status after 2 seconds
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  // Reset edit data when switching plans
  useEffect(() => {
    if (!editingPlan) {
      setEditData({
        title: '',
        price: '',
        period: '',
        features: ['']
      });
    }
  }, [editingPlan]);

  const handleAddFeature = () => {
    setEditData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };

  const handleRemoveFeature = (index: number) => {
    setEditData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const handleFeatureChange = (index: number, value: string) => {
    setEditData(prev => ({
      ...prev,
      features: prev.features.map((feature, i) => 
        i === index ? value : feature
      )
    }));
  };

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة الاشتراكات"
        subtitle="تعديل باقات الاشتراك والأسعار"
      />

      {/* Save Status Message */}
      {saveStatus === 'success' && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-text-center">
          تم حفظ التغييرات بنجاح
        </div>
      )}

      {saveStatus === 'error' && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-text-center">
          حدث خطأ أثناء حفظ التغييرات
        </div>
      )}

      <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`tw-relative tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a] ${
              editingPlan === plan.id ? 'tw-ring-2 tw-ring-amber-400' : ''
            }`}
          >
            {editingPlan === plan.id ? (
              // Edit Mode
              <div className="tw-space-y-4">
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-400 tw-mb-1">
                    عنوان الباقة
                  </label>
                  <input
                    type="text"
                    value={editData.title}
                    onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                  />
                </div>

                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-400 tw-mb-1">
                    السعر
                  </label>
                  <input
                    type="text"
                    value={editData.price}
                    onChange={(e) => setEditData({ ...editData, price: e.target.value })}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                  />
                </div>

                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-400 tw-mb-1">
                    المدة
                  </label>
                  <input
                    type="text"
                    value={editData.period}
                    onChange={(e) => setEditData({ ...editData, period: e.target.value })}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                  />
                </div>

                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-400 tw-mb-1">
                    المميزات
                  </label>
                  <div className="tw-space-y-2">
                    {editData.features.map((feature, index) => (
                      <div key={index} className="tw-flex tw-gap-2">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => handleFeatureChange(index, e.target.value)}
                          className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                        />
                        <button
                          onClick={() => handleRemoveFeature(index)}
                          className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg"
                        >
                          <X className="tw-w-5 tw-h-5" />
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={handleAddFeature}
                      className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
                    >
                      <Plus className="tw-w-4 tw-h-4" />
                      <span>إضافة ميزة</span>
                    </button>
                  </div>
                </div>

                <div className="tw-flex tw-justify-end tw-gap-2 tw-mt-4">
                  <button
                    onClick={() => setEditingPlan(null)}
                    className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
                  >
                    إلغاء
                  </button>
                  <button
                    onClick={() => handleSave(plan.id)}
                    disabled={saveStatus === 'saving'}
                    className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
                  >
                    <Save className="tw-w-4 tw-h-4" />
                    <span>{saveStatus === 'saving' ? 'جاري الحفظ...' : 'حفظ'}</span>
                  </button>
                </div>
              </div>
            ) : (
              // View Mode
              <>
                <div className="tw-mb-4">
                  <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-2">
                    {plan.title}
                  </h3>
                  <div className="tw-flex tw-items-baseline tw-gap-2">
                    <span className="tw-text-2xl tw-font-bold tw-text-amber-400">
                      {plan.price}
                    </span>
                    <span className="tw-text-gray-400">/ {plan.period}</span>
                  </div>
                </div>

                <ul className="tw-space-y-2 tw-mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="tw-text-gray-300 tw-text-sm">
                      • {feature}
                    </li>
                  ))}
                </ul>

                <div className="tw-flex tw-justify-end tw-gap-2">
                  <button
                    onClick={() => handleEdit(plan.id)}
                    className="tw-p-2 tw-text-amber-400 hover:tw-bg-neutral-700 tw-rounded-lg"
                  >
                    <Edit2 className="tw-w-5 tw-h-5" />
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminSubscriptions;