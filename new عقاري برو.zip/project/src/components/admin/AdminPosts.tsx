import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { 
  Search, Filter, CheckCircle, XCircle, Edit2, Trash2, 
  MapPin, Building2, Car, Crown, Lock, Unlock, Eye,
  AlertTriangle, Star, MessageCircle, Share2
} from 'lucide-react';

export const AdminPosts = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | 'edit' | 'delete' | 'premium' | 'lock' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showLockModal, setShowLockModal] = useState(false);

  // Mock posts data
  const posts = [
    {
      id: 1,
      title: 'فيلا فاخرة في صنعاء',
      type: 'property',
      category: 'فيلا',
      location: 'صنعاء',
      price: '301,887',
      status: 'pending',
      isPremium: true,
      isLocked: false,
      views: 245,
      interactions: 12,
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&auto=format&fit=crop&q=60',
      user: {
        name: 'عمار عبدالرحمن',
        avatar: 'https://i.pravatar.cc/150?img=1',
        accountType: 'business',
        businessName: 'عمار للعقارات'
      }
    },
    {
      id: 2,
      title: 'تويوتا كامري 2023',
      type: 'vehicle',
      category: 'سيدان',
      location: 'صنعاء',
      price: '25,000',
      status: 'active',
      isPremium: false,
      isLocked: false,
      views: 180,
      interactions: 8,
      createdAt: '2024-03-15',
      image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=60',
      user: {
        name: 'محمد أحمد',
        avatar: 'https://i.pravatar.cc/150?img=2',
        accountType: 'personal'
      }
    }
  ];

  const handleAction = (post: any, action: 'approve' | 'reject' | 'edit' | 'delete' | 'premium' | 'lock') => {
    setSelectedPost(post);
    setActionType(action);
    
    if (action === 'premium') {
      setShowPremiumModal(true);
    } else if (action === 'lock') {
      setShowLockModal(true);
    } else {
      setShowActionModal(true);
    }
  };

  const handleConfirmAction = () => {
    // Here you would implement the actual action logic
    switch (actionType) {
      case 'approve':
        console.log('Approving post:', selectedPost.id);
        break;
      case 'reject':
        console.log('Rejecting post:', selectedPost.id, 'Reason:', rejectionReason);
        break;
      case 'edit':
        console.log('Updating post:', selectedPost.id);
        break;
      case 'delete':
        console.log('Deleting post:', selectedPost.id);
        break;
      case 'premium':
        console.log('Toggling premium status for post:', selectedPost.id);
        break;
      case 'lock':
        console.log('Toggling lock status for post:', selectedPost.id);
        break;
    }
    setShowActionModal(false);
    setShowPremiumModal(false);
    setShowLockModal(false);
    setSelectedPost(null);
    setActionType(null);
    setRejectionReason('');
  };

  const ActionModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        {actionType === 'approve' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <CheckCircle className="tw-w-6 tw-h-6 tw-text-green-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تأكيد الموافقة</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من الموافقة على نشر هذا الإعلان؟
            </p>
          </>
        )}

        {actionType === 'reject' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <XCircle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">رفض الإعلان</h3>
            </div>
            <div className="tw-mb-6">
              <label className="tw-block tw-text-gray-300 tw-mb-2">سبب الرفض</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                rows={4}
                placeholder="اذكر سبب رفض الإعلان..."
              />
            </div>
          </>
        )}

        {actionType === 'delete' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <AlertTriangle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">حذف الإعلان</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من حذف هذا الإعلان؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
          </>
        )}

        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowActionModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className={`tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium ${
              actionType === 'approve'
                ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                : actionType === 'reject' || actionType === 'delete'
                ? 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
                : 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
            }`}
          >
            {actionType === 'approve' && 'تأكيد الموافقة'}
            {actionType === 'reject' && 'تأكيد الرفض'}
            {actionType === 'delete' && 'تأكيد الحذف'}
          </button>
        </div>
      </div>
    </div>
  );

  const PremiumModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
          <Crown className="tw-w-6 tw-h-6 tw-text-amber-400" />
          <h3 className="tw-text-xl tw-font-bold tw-text-white">
            {selectedPost?.isPremium ? 'إلغاء المحتوى المميز' : 'تعيين كمحتوى مميز'}
          </h3>
        </div>
        <p className="tw-text-gray-300 tw-mb-6">
          {selectedPost?.isPremium 
            ? 'هل أنت متأكد من إلغاء المحتوى المميز لهذا الإعلان؟'
            : 'هل أنت متأكد من تعيين هذا الإعلان كمحتوى مميز؟'
          }
        </p>
        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowPremiumModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className="tw-px-4 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg"
          >
            {selectedPost?.isPremium ? 'إلغاء المميز' : 'تعيين مميز'}
          </button>
        </div>
      </div>
    </div>
  );

  const LockModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
          {selectedPost?.isLocked ? (
            <Unlock className="tw-w-6 tw-h-6 tw-text-green-400" />
          ) : (
            <Lock className="tw-w-6 tw-h-6 tw-text-red-400" />
          )}
          <h3 className="tw-text-xl tw-font-bold tw-text-white">
            {selectedPost?.isLocked ? 'فتح الإعلان' : 'قفل الإعلان'}
          </h3>
        </div>
        <p className="tw-text-gray-300 tw-mb-6">
          {selectedPost?.isLocked 
            ? 'هل أنت متأكد من فتح هذا الإعلان؟'
            : 'هل أنت متأكد من قفل هذا الإعلان؟'
          }
        </p>
        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowLockModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className={`tw-px-4 tw-py-2 tw-rounded-lg ${
              selectedPost?.isLocked
                ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                : 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
            }`}
          >
            {selectedPost?.isLocked ? 'فتح' : 'قفل'}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة الإعلانات"
        subtitle="إدارة وتنظيم جميع الإعلانات"
      />

      {/* Search and Filters */}
      <div className="tw-flex tw-items-center tw-gap-4">
        <div className="tw-relative tw-flex-1">
          <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
          <input
            type="text"
            placeholder="البحث في الإعلانات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="tw-w-full tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
          />
        </div>
        
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
        >
          <option value="all">جميع الأنواع</option>
          <option value="property">عقارات</option>
          <option value="vehicle">سيارات</option>
        </select>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
        >
          <option value="all">جميع الحالات</option>
          <option value="active">نشط</option>
          <option value="pending">معلق</option>
          <option value="rejected">مرفوض</option>
        </select>
      </div>

      {/* Posts Table */}
      <div className="tw-bg-neutral-800 tw-rounded-lg tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-700">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإعلان</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">النوع</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">السعر</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الحالة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">المعلن</th>
              <th className="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {posts.map((post) => (
              <tr key={post.id} className="hover:tw-bg-neutral-700/50">
                <td className="tw-px-6 tw-py-4">
                  <div className="tw-flex tw-items-center tw-gap-4">
                    <div className="tw-w-16 tw-h-16 tw-rounded-lg tw-overflow-hidden">
                      <img 
                        src={post.image}
                        alt={post.title}
                        className="tw-w-full tw-h-full tw-object-cover"
                      />
                    </div>
                    <div>
                      <div className="tw-text-sm tw-font-medium tw-text-white">{post.title}</div>
                      <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-text-sm">
                        <MapPin className="tw-w-4 tw-h-4" />
                        <span>{post.location}</span>
                      </div>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                    post.type === 'property'
                      ? 'tw-bg-amber-400/10 tw-text-amber-400'
                      : 'tw-bg-purple-400/10 tw-text-purple-400'
                  }`}>
                    {post.category}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-white">
                  ${post.price}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div className="tw-flex tw-items-center tw-gap-2">
                    {post.isPremium && (
                      <span className="tw-px-2 tw-py-1 tw-bg-amber-400/10 tw-text-amber-400 tw-rounded-full tw-text-xs">
                        مميز
                      </span>
                    )}
                    {post.isLocked && (
                      <span className="tw-px-2 tw-py-1 tw-bg-red-400/10 tw-text-red-400 tw-rounded-full tw-text-xs">
                        مقفل
                      </span>
                    )}
                    <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                      post.status === 'active' 
                        ? 'tw-bg-green-400/10 tw-text-green-400' 
                        : 'tw-bg-yellow-400/10 tw-text-yellow-400'
                    }`}>
                      {post.status === 'active' ? 'نشط' : 'معلق'}
                    </span>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div>
                    <div className="tw-text-sm tw-font-medium tw-text-white">
                      {post.user.accountType === 'business' ? post.user.businessName : post.user.name}
                    </div>
                    <div className="tw-text-sm tw-text-gray-400">
                      {post.user.accountType === 'business' ? 'حساب تجاري' : 'حساب شخصي'}
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                  <div className="tw-flex tw-justify-end tw-gap-2">
                    <button 
                      onClick={() => handleAction(post, 'premium')}
                      className={`tw-p-2 ${
                        post.isPremium 
                          ? 'tw-text-amber-400 hover:tw-bg-neutral-700' 
                          : 'tw-text-gray-400 hover:tw-text-amber-400 hover:tw-bg-neutral-700'
                      } tw-rounded-lg tw-transition-colors`}
                      title={post.isPremium ? 'إلغاء المميز' : 'تعيين مميز'}
                    >
                      <Crown className="tw-w-4 tw-h-4" />
                    </button>

                    <button 
                      onClick={() => handleAction(post, 'lock')}
                      className={`tw-p-2 ${
                        post.isLocked 
                          ? 'tw-text-red-400 hover:tw-bg-neutral-700' 
                          : 'tw-text-gray-400 hover:tw-text-red-400 hover:tw-bg-neutral-700'
                      } tw-rounded-lg tw-transition-colors`}
                      title={post.isLocked ? 'فتح' : 'قفل'}
                    >
                      {post.isLocked ? (
                        <Lock className="tw-w-4 tw-h-4" />
                      ) : (
                        <Unlock className="tw-w-4 tw-h-4" />
                      )}
                    </button>

                    {post.status === 'pending' && (
                      <>
                        <button 
                          onClick={() => handleAction(post, 'approve')}
                          className="tw-p-2 tw-text-green-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="موافقة"
                        >
                          <CheckCircle className="tw-w-4 tw-h-4" />
                        </button>
                        <button 
                          onClick={() => handleAction(post, 'reject')}
                          className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                          title="رفض"
                        >
                          <XCircle className="tw-w-4 tw-h-4" />
                        </button>
                      </>
                    )}
                    <button 
                      onClick={() => handleAction(post, 'edit')}
                      className="tw-p-2 tw-text-amber-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="تعديل"
                    >
                      <Edit2 className="tw-w-4 tw-h-4" />
                    </button>
                    <button 
                      onClick={() => handleAction(post, 'delete')}
                      className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="tw-w-4 tw-h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Modals */}
      {showActionModal && <ActionModal />}
      {showPremiumModal && <PremiumModal />}
      {showLockModal && <LockModal />}
    </div>
  );
};

export default AdminPosts;