import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Building2,
  Car,
  Settings,
  Shield,
  Database,
  Bell,
  FileText,
  CreditCard,
  Search,
  MessageSquareText,
  Crown,
} from 'lucide-react';

export const AdminSidebar = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const menuItems = [
    {
      title: 'عام',
      items: [
        { path: '/admin', icon: LayoutDashboard, label: 'لوحة التحكم' },
        { path: '/admin/users', icon: Users, label: 'المستخدمين' },
        { path: '/admin/posts', icon: MessageSquareText, label: 'المقالات' },
      ],
    },
    {
      title: 'العقارات',
      items: [
        { path: '/admin/properties', icon: Building2, label: 'العقارات' },
        {
          path: '/admin/property-requests',
          icon: Search,
          label: 'طلبات العقارات',
        },
      ],
    },
    {
      title: 'السيارات',
      items: [
        { path: '/admin/vehicles', icon: Car, label: 'السيارات' },
        {
          path: '/admin/vehicle-requests',
          icon: Search,
          label: 'طلبات السيارات',
        },
      ],
    },
    {
      title: 'النظام',
      items: [
        { path: '/admin/subscriptions', icon: Crown, label: 'الاشتراكات' },
        { path: '/admin/settings', icon: Settings, label: 'الإعدادات' },
        { path: '/admin/logs', icon: FileText, label: 'السجلات' },
      ],
    },
  ];

  return (
    <aside className="tw-w-64 tw-bg-[#0a0a0a] tw-min-h-screen tw-border-l tw-border-[#1a1a1a]">
      <div className="tw-p-6">
        <div className="tw-mb-8">
          <img
            src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png"
            alt="Aqari Pro"
            className="tw-h-12 tw-w-auto"
          />
        </div>

        <nav className="tw-space-y-8">
          {menuItems.map((section, index) => (
            <div key={index}>
              <h3 className="tw-text-xs tw-font-medium tw-text-gray-400 tw-uppercase tw-mb-4">
                {section.title}
              </h3>

              <div className="tw-space-y-1">
                {section.items.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-rounded-xl tw-transition-colors ${
                      isActive(item.path)
                        ? 'tw-bg-amber-400/10 tw-text-amber-400'
                        : 'tw-text-gray-400 hover:tw-text-white hover:tw-bg-[#1a1a1a]'
                    }`}
                  >
                    <item.icon className="tw-w-5 tw-h-5" />
                    <span>{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default AdminSidebar;
