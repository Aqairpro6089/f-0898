import React, { useState } from 'react';
import { Search, UserPlus, Edit2, Trash2, Briefcase, User } from 'lucide-react';
import { BackButton } from '../common/BackButton';
import { PageTitle } from '../common/PageTitle';

export const AdminUsers = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const users = [
    { 
      id: 1, 
      username: 'ahmed123',
      name: 'Ahmed',
      email: 'ahmed@example.com', 
      role: 'Business', 
      status: 'Active',
      accountType: 'business',
      businessName: 'Ahmed Real Estate',
      createdAt: '2024-03-15'
    },
    { 
      id: 2, 
      username: 'MOhmedX1',
      name: 'Mohammed',
      email: 'mohammed@example.com', 
      role: 'User', 
      status: 'Active',
      accountType: 'personal',
      createdAt: '2024-03-15'
    }
  ];

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة المستخدمين"
        subtitle="إدارة حسابات المستخدمين وصلاحياتهم"
      />

      <div className="tw-flex tw-items-center tw-justify-between">
        <div>
          <h1 className="tw-text-2xl tw-font-bold tw-text-white">إدارة المستخدمين</h1>
          <p className="tw-text-gray-400">إدارة حسابات المستخدمين وصلاحياتهم</p>
        </div>
        
        <button className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg tw-font-medium tw-transition-colors">
          <UserPlus className="tw-w-4 tw-h-4" />
          إضافة مستخدم
        </button>
      </div>

      {/* Search and Filters */}
      <div className="tw-flex tw-items-center tw-gap-4">
        <div className="tw-relative tw-flex-1">
          <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
          <input
            type="text"
            placeholder="البحث عن المستخدمين..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="tw-w-full tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
          />
        </div>
        
        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
          <option value="all">جميع الأنواع</option>
          <option value="business">حساب تجاري</option>
          <option value="personal">حساب شخصي</option>
        </select>

        <select className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
          <option value="all">جميع الحالات</option>
          <option value="active">نشط</option>
          <option value="inactive">غير نشط</option>
        </select>
      </div>

      {/* Users Table */}
      <div className="tw-bg-neutral-800 tw-rounded-lg tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-700">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">المستخدم</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">نوع الحساب</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الحالة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">تاريخ التسجيل</th>
              <th className="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {users.map((user) => (
              <tr key={user.id} className="hover:tw-bg-neutral-700/50">
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div className="tw-flex tw-items-center">
                    <div className="tw-h-10 tw-w-10 tw-rounded-full tw-bg-neutral-600 tw-flex tw-items-center tw-justify-center">
                      {user.accountType === 'business' ? (
                        <Briefcase className="tw-w-5 tw-h-5 tw-text-amber-400" />
                      ) : (
                        <User className="tw-w-5 tw-h-5 tw-text-purple-400" />
                      )}
                    </div>
                    <div className="tw-ml-4">
                      <div className="tw-text-sm tw-font-medium tw-text-white">
                        {user.accountType === 'business' ? user.businessName : user.name}
                      </div>
                      <div className="tw-text-sm tw-text-gray-400">@{user.username}</div>
                      <div className="tw-text-sm tw-text-gray-400">{user.email}</div>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                    user.accountType === 'business'
                      ? 'tw-bg-amber-400/10 tw-text-amber-400'
                      : 'tw-bg-purple-400/10 tw-text-purple-400'
                  }`}>
                    {user.accountType === 'business' ? 'تجاري' : 'شخصي'}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                    user.status === 'Active' 
                      ? 'tw-bg-green-400/10 tw-text-green-400' 
                      : 'tw-bg-red-400/10 tw-text-red-400'
                  }`}>
                    {user.status === 'Active' ? 'نشط' : 'غير نشط'}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-gray-400">
                  {user.createdAt}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                  <button className="tw-text-amber-400 hover:tw-text-amber-500 tw-mr-3">
                    <Edit2 className="tw-w-4 tw-h-4" />
                  </button>
                  <button className="tw-text-red-400 hover:tw-text-red-500">
                    <Trash2 className="tw-w-4 tw-h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminUsers;