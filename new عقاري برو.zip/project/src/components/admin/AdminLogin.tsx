import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { User, Lock, Eye, EyeOff } from 'lucide-react';

export const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      const success = await login(username, password);
      if (success) {
        navigate('/admin'); // Redirect to internal admin dashboard instead of external URL
      } else {
        setError('اسم المستخدم أو كلمة المرور غير صحيحة');
      }
    } catch (err) {
      setError('حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-flex tw-items-center tw-justify-center tw-px-4">
      <div className="tw-w-full tw-max-w-md">
        <div className="tw-text-center tw-mb-8">
          <img 
            src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png"
            alt="Aqari Pro"
            className="tw-h-16 tw-w-auto tw-mx-auto tw-mb-6"
          />
          <h1 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-2">
            دخول الإدارة
          </h1>
          <p className="tw-text-gray-400">
            تسجيل الدخول إلى لوحة التحكم
          </p>
        </div>

        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8">
          <form onSubmit={handleSubmit} className="tw-space-y-6">
            {error && (
              <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-text-center">
                {error}
              </div>
            )}
            
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-text-right tw-mb-2">
                اسم المستخدم
              </label>
              <div className="tw-relative tw-group">
                <User className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400 group-focus-within:tw-text-amber-400 tw-transition-colors" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-text-right tw-mb-2">
                كلمة المرور
              </label>
              <div className="tw-relative tw-group">
                <Lock className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400 group-focus-within:tw-text-amber-400 tw-transition-colors" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-12 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 hover:tw-text-white tw-transition-colors focus:tw-outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="tw-w-5 tw-h-5" />
                  ) : (
                    <Eye className="tw-w-5 tw-h-5" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="tw-w-full tw-bg-gradient-to-r tw-from-amber-400 tw-to-amber-500 hover:tw-from-amber-500 hover:tw-to-amber-600 tw-text-black tw-font-medium tw-py-3 tw-px-4 tw-rounded-xl tw-transition-all tw-duration-300 tw-relative tw-overflow-hidden tw-group disabled:tw-opacity-50"
            >
              <div className="tw-absolute tw-inset-0 tw-bg-white/10 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
              <span className="tw-relative tw-z-10">
                {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
              </span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;