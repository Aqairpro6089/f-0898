import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Download } from 'lucide-react';

export const AdminLogs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('all');
  
  const logs = [
    { id: 1, level: 'error', message: 'Failed login attempt from IP 192.168.1.1', timestamp: '14:23:45 2024-03-15', user: 'system' },
    { id: 2, level: 'warning', message: 'High CPU usage detected', timestamp: '14:22:30 2024-03-15', user: 'system' },
    { id: 3, level: 'info', message: 'User "john_doe" logged in successfully', timestamp: '14:20:15 2024-03-15', user: 'john_doe' },
    { id: 4, level: 'error', message: 'Database connection timeout', timestamp: '14:18:00 2024-03-15', user: 'system' }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'error': return 'tw-text-red-400';
      case 'warning': return 'tw-text-yellow-400';
      case 'info': return 'tw-text-blue-400';
      default: return 'tw-text-gray-400';
    }
  };

  const getLevelBadgeColor = (level: string) => {
    switch (level) {
      case 'error': return 'tw-bg-red-400/10 tw-text-red-400';
      case 'warning': return 'tw-bg-yellow-400/10 tw-text-yellow-400';
      case 'info': return 'tw-bg-blue-400/10 tw-text-blue-400';
      default: return 'tw-bg-gray-400/10 tw-text-gray-400';
    }
  };

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="سجلات النظام"
        subtitle="عرض وتحليل نشاطات النظام"
      />

      {/* Header Actions */}
      <div className="tw-flex tw-items-center tw-justify-between">
        <div className="tw-flex tw-items-center tw-gap-4">
          <select
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value)}
            className="tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-4 tw-py-2 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
          >
            <option value="all">All Levels</option>
            <option value="error">Error</option>
            <option value="warning">Warning</option>
            <option value="info">Info</option>
          </select>

          <div className="tw-relative">
            <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="tw-w-64 tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>
        </div>

        <button className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg tw-font-medium tw-transition-colors">
          <Download className="tw-w-4 tw-h-4" />
          Export Logs
        </button>
      </div>

      {/* Logs Table */}
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-800">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-400 tw-uppercase">User</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-400 tw-uppercase">Message</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-400 tw-uppercase">Level</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-400 tw-uppercase">Timestamp</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {logs.map((log) => (
              <tr key={log.id} className="hover:tw-bg-neutral-800/50">
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-gray-300">
                  {log.user}
                </td>
                <td className="tw-px-6 tw-py-4 tw-text-sm tw-text-white">
                  {log.message}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-py-1 tw-text-xs tw-font-medium tw-rounded-full ${getLevelBadgeColor(log.level)}`}>
                    {log.level.toUpperCase()}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-gray-300">
                  {log.timestamp}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminLogs;