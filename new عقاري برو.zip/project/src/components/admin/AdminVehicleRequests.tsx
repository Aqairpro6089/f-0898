import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Filter, CheckCircle, XCircle, Edit2, Trash2, MapPin, Car, DollarSign, Calendar } from 'lucide-react';

export const AdminVehicleRequests = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | 'edit' | 'delete' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Mock vehicle requests data
  const vehicleRequests = [
    {
      id: 1,
      title: 'مطلوب سيارة عائلية',
      location: 'صنعاء',
      description: 'أبحث عن سيارة عائلية اقتصادية',
      type: 'سيدان',
      status: 'pending',
      year: {
        min: 2020,
        max: 2024
      },
      budget: {
        min: 15000,
        max: 25000
      },
      requestType: 'شراء',
      user: {
        name: 'أحمد محمد',
        avatar: 'https://i.pravatar.cc/150?img=1',
        email: 'ahmed@example.com',
        phone: '+967 xxx xxx xxx'
      },
      createdAt: '2024-03-15'
    }
  ];

  const handleAction = (request: any, action: 'approve' | 'reject' | 'edit' | 'delete') => {
    setSelectedRequest(request);
    setActionType(action);
    setShowActionModal(true);
  };

  const handleConfirmAction = () => {
    // Here you would implement the actual action logic
    switch (actionType) {
      case 'approve':
        console.log('Approving request:', selectedRequest.id);
        break;
      case 'reject':
        console.log('Rejecting request:', selectedRequest.id, 'Reason:', rejectionReason);
        break;
      case 'edit':
        console.log('Updating request:', selectedRequest.id);
        break;
      case 'delete':
        console.log('Deleting request:', selectedRequest.id);
        break;
    }
    setShowActionModal(false);
    setSelectedRequest(null);
    setActionType(null);
    setRejectionReason('');
  };

  const ActionModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        {actionType === 'approve' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <CheckCircle className="tw-w-6 tw-h-6 tw-text-green-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">تأكيد الموافقة</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من الموافقة على هذا الطلب؟
            </p>
          </>
        )}

        {actionType === 'reject' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <XCircle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">رفض الطلب</h3>
            </div>
            <div className="tw-mb-6">
              <label className="tw-block tw-text-gray-300 tw-mb-2">سبب الرفض</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-lg tw-p-3 tw-text-white"
                rows={4}
                placeholder="اذكر سبب رفض الطلب..."
              />
            </div>
          </>
        )}

        {actionType === 'delete' && (
          <>
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
              <AlertTriangle className="tw-w-6 tw-h-6 tw-text-red-400" />
              <h3 className="tw-text-xl tw-font-bold tw-text-white">حذف الطلب</h3>
            </div>
            <p className="tw-text-gray-300 tw-mb-6">
              هل أنت متأكد من حذف هذا الطلب؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
          </>
        )}

        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowActionModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={handleConfirmAction}
            className={`tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium ${
              actionType === 'approve'
                ? 'tw-bg-green-500 hover:tw-bg-green-600 tw-text-white'
                : actionType === 'reject' || actionType === 'delete'
                ? 'tw-bg-red-500 hover:tw-bg-red-600 tw-text-white'
                : 'tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white'
            }`}
          >
            {actionType === 'approve' && 'تأكيد الموافقة'}
            {actionType === 'reject' && 'تأكيد الرفض'}
            {actionType === 'delete' && 'تأكيد الحذف'}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      <PageTitle 
        title="إدارة طلبات السيارات"
        subtitle="مراجعة وإدارة طلبات السيارات"
      />

      {/* Search and Filters */}
      <div className="tw-flex tw-items-center tw-gap-4">
        <div className="tw-relative tw-flex-1">
          <Search className="tw-absolute tw-left-3 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
          <input
            type="text"
            placeholder="البحث في الطلبات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="tw-w-full tw-pl-10 tw-pr-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
          />
        </div>
        
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
        >
          <option value="all">جميع الأنواع</option>
          <option value="sedan">سيدان</option>
          <option value="suv">SUV</option>
          <option value="pickup">بيك اب</option>
        </select>

        <select
          value={selectedLocation}
          onChange={(e) => setSelectedLocation(e.target.value)}
          className="tw-px-4 tw-py-2 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
        >
          <option value="all">جميع المناطق</option>
          <option value="sanaa">صنعاء</option>
          <option value="aden">عدن</option>
          <option value="taiz">تعز</option>
        </select>
      </div>

      {/* Requests Table */}
      <div className="tw-bg-neutral-800 tw-rounded-lg tw-overflow-hidden">
        <table className="tw-w-full">
          <thead>
            <tr className="tw-bg-neutral-700">
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الطلب</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">النوع</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الميزانية</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الحالة</th>
              <th className="tw-px-6 tw-py-3 tw-text-left tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">المستخدم</th>
              <th className="tw-px-6 tw-py-3 tw-text-right tw-text-xs tw-font-medium tw-text-gray-300 tw-uppercase tw-tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="tw-divide-y tw-divide-neutral-700">
            {vehicleRequests.map((request) => (
              <tr key={request.id} className="hover:tw-bg-neutral-700/50">
                <td className="tw-px-6 tw-py-4">
                  <div>
                    <div className="tw-text-sm tw-font-medium tw-text-white">{request.title}</div>
                    <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-text-sm">
                      <MapPin className="tw-w-4 tw-h-4" />
                      <span>{request.location}</span>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className="tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full tw-bg-purple-400/10 tw-text-purple-400">
                    {request.type}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-sm tw-text-white">
                  ${request.budget.min} - ${request.budget.max}
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <span className={`tw-px-2 tw-inline-flex tw-text-xs tw-leading-5 tw-font-semibold tw-rounded-full ${
                    request.status === 'active' 
                      ? 'tw-bg-green-400/10 tw-text-green-400' 
                      : 'tw-bg-yellow-400/10 tw-text-yellow-400'
                  }`}>
                    {request.status === 'active' ? 'نشط' : 'معلق'}
                  </span>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap">
                  <div className="tw-flex tw-items-center">
                    <img 
                      src={request.user.avatar}
                      alt={request.user.name}
                      className="tw-w-8 tw-h-8 tw-rounded-full"
                    />
                    <div className="tw-ml-4">
                      <div className="tw-text-sm tw-font-medium tw-text-white">{request.user.name}</div>
                      <div className="tw-text-sm tw-text-gray-400">{request.user.email}</div>
                    </div>
                  </div>
                </td>
                <td className="tw-px-6 tw-py-4 tw-whitespace-nowrap tw-text-right tw-text-sm tw-font-medium">
                  <div className="tw-flex tw-justify-end tw-gap-2">
                    <button 
                      onClick={() => handleAction(request, 'approve')}
                      className="tw-p-2 tw-text-green-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="موافقة"
                    >
                      <CheckCircle className="tw-w-4 tw-h-4" />
                    </button>
                    <button 
                      onClick={() => handleAction(request, 'reject')}
                      className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="رفض"
                    >
                      <XCircle className="tw-w-4 tw-h-4" />
                    </button>
                    <button 
                      onClick={() => handleAction(request, 'delete')}
                      className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="tw-w-4 tw-h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Modal */}
      {showActionModal && <ActionModal />}
    </div>
  );
};

export default AdminVehicleRequests;