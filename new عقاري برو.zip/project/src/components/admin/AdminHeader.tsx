import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Bell, Settings, LogOut } from 'lucide-react';

export const AdminHeader = () => {
  const { user, logout } = useAuth();

  return (
    <header className="tw-bg-[#0a0a0a] tw-border-b tw-border-[#1a1a1a]">
      <div className="tw-px-8">
        <div className="tw-h-16 tw-flex tw-items-center tw-justify-between">
          {/* Left Side */}
          <div>
            <h1 className="tw-text-xl tw-font-bold tw-text-white">
              مرحباً بك في لوحة التحكم
            </h1>
          </div>

          {/* Right Side */}
          <div className="tw-flex tw-items-center tw-gap-6">
            {/* Notifications */}
            <button className="tw-relative tw-p-2 tw-text-gray-400 hover:tw-text-white tw-transition-colors">
              <Bell className="tw-w-6 tw-h-6" />
              <span className="tw-absolute tw-top-1 tw-right-1 tw-w-2 tw-h-2 tw-bg-amber-400 tw-rounded-full" />
            </button>

            {/* Settings */}
            <button className="tw-p-2 tw-text-gray-400 hover:tw-text-white tw-transition-colors">
              <Settings className="tw-w-6 tw-h-6" />
            </button>

            {/* Logout */}
            <button 
              onClick={logout}
              className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-red-500/10 hover:tw-bg-red-500/20 tw-text-red-500 tw-rounded-lg tw-transition-colors"
            >
              <LogOut className="tw-w-5 tw-h-5" />
              <span>تسجيل خروج</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};