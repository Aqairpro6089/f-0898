import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AdminHeader } from './AdminHeader';
import { AdminSidebar } from './AdminSidebar';
import { AdminDashboard } from './AdminDashboard';
import { AdminUsers } from './AdminUsers';
import { AdminPosts } from './AdminPosts';
import { AdminSettings } from './AdminSettings';
import { AdminLogs } from './AdminLogs';
import { AdminProperties } from './AdminProperties';
import { AdminVehicles } from './AdminVehicles';
import { AdminPropertyRequests } from './AdminPropertyRequests';
import { AdminVehicleRequests } from './AdminVehicleRequests';
import { AdminSubscriptions } from './AdminSubscriptions';
import { LoadingScreen } from '../common/LoadingScreen';
import { HomeButton } from '../common/HomeButton';

export const AdminLayout = () => {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();

  // Check if user is authenticated AND has admin role
  if (!isAuthenticated || user?.role !== 'admin') {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      {/* Background Pattern */}
      <div className="tw-fixed tw-inset-0">
        <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="tw-absolute tw-w-1 tw-h-1 tw-bg-white/10 tw-rounded-full tw-animate-twinkle"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* Main Layout */}
      <div className="tw-relative tw-flex">
        <AdminSidebar />
        
        <main className="tw-flex-1">
          <AdminHeader />
          
          <div className="tw-p-8">
            <React.Suspense fallback={<LoadingScreen />}>
              <Routes>
                <Route index element={<AdminDashboard />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="posts" element={<AdminPosts />} />
                <Route path="properties" element={<AdminProperties />} />
                <Route path="vehicles" element={<AdminVehicles />} />
                <Route path="property-requests" element={<AdminPropertyRequests />} />
                <Route path="vehicle-requests" element={<AdminVehicleRequests />} />
                <Route path="subscriptions" element={<AdminSubscriptions />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="logs" element={<AdminLogs />} />
                <Route path="*" element={<Navigate to="/admin" replace />} />
              </Routes>
            </React.Suspense>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;