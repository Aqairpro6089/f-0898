import React from 'react';

export const Dashboard = () => {
  return (
    <div className="tw-space-y-6">
      <div className="tw-flex tw-items-center tw-justify-between">
        <h1 className="tw-text-2xl tw-font-bold tw-text-white">Dashboard</h1>
        <div className="tw-flex tw-space-x-4">
          <button className="tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium">
            Add Property
          </button>
          <button className="tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium">
            Add Vehicle
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-6">
        {/* Total Users */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-6">
          <div className="tw-flex tw-items-center tw-justify-between">
            <div>
              <p className="tw-text-gray-400 tw-text-sm">Total Users</p>
              <p className="tw-text-2xl tw-font-bold tw-text-white">2,543</p>
            </div>
            <div className="tw-bg-amber-400/10 tw-p-3 tw-rounded-lg">
              <svg className="tw-w-6 tw-h-6 tw-text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Properties */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-6">
          <div className="tw-flex tw-items-center tw-justify-between">
            <div>
              <p className="tw-text-gray-400 tw-text-sm">Properties</p>
              <p className="tw-text-2xl tw-font-bold tw-text-white">1,234</p>
            </div>
            <div className="tw-bg-amber-400/10 tw-p-3 tw-rounded-lg">
              <svg className="tw-w-6 tw-h-6 tw-text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
            </div>
          </div>
        </div>

        {/* Vehicles */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-6">
          <div className="tw-flex tw-items-center tw-justify-between">
            <div>
              <p className="tw-text-gray-400 tw-text-sm">Vehicles</p>
              <p className="tw-text-2xl tw-font-bold tw-text-white">567</p>
            </div>
            <div className="tw-bg-purple-600/10 tw-p-3 tw-rounded-lg">
              <svg className="tw-w-6 tw-h-6 tw-text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
              </svg>
            </div>
          </div>
        </div>

        {/* Revenue */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-6">
          <div className="tw-flex tw-items-center tw-justify-between">
            <div>
              <p className="tw-text-gray-400 tw-text-sm">Revenue</p>
              <p className="tw-text-2xl tw-font-bold tw-text-white">$12,345</p>
            </div>
            <div className="tw-bg-green-500/10 tw-p-3 tw-rounded-lg">
              <svg className="tw-w-6 tw-h-6 tw-text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-6">
        <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">Recent Activity</h2>
        <div className="tw-space-y-4">
          {/* Activity Items */}
          <div className="tw-flex tw-items-center tw-space-x-4">
            <div className="tw-bg-amber-400/10 tw-p-2 tw-rounded-lg">
              <svg className="tw-w-5 tw-h-5 tw-text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="tw-text-white">New property listed</p>
              <p className="tw-text-gray-400 tw-text-sm">2 minutes ago</p>
            </div>
          </div>
          
          <div className="tw-flex tw-items-center tw-space-x-4">
            <div className="tw-bg-purple-600/10 tw-p-2 tw-rounded-lg">
              <svg className="tw-w-5 tw-h-5 tw-text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="tw-text-white">New vehicle added</p>
              <p className="tw-text-gray-400 tw-text-sm">15 minutes ago</p>
            </div>
          </div>
          
          <div className="tw-flex tw-items-center tw-space-x-4">
            <div className="tw-bg-green-500/10 tw-p-2 tw-rounded-lg">
              <svg className="tw-w-5 tw-h-5 tw-text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="tw-text-white">Payment received</p>
              <p className="tw-text-gray-400 tw-text-sm">1 hour ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};