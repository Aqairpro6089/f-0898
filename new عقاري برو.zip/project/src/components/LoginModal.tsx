import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const success = await login(username, password);
    if (success) {
      onClose();
      window.location.href = '/admin'; // Redirect to admin panel
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="tw-fixed tw-inset-0 tw-bg-black tw-bg-opacity-50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-900 tw-rounded-lg tw-p-8 tw-w-full tw-max-w-md">
        <div className="tw-flex tw-justify-between tw-items-center tw-mb-6">
          <h2 className="tw-text-2xl tw-font-bold tw-text-white">Admin Login</h2>
          <button onClick={onClose} className="tw-text-gray-400 hover:tw-text-white">
            <svg className="tw-w-6 tw-h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="tw-space-y-6">
          {error && (
            <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-3 tw-rounded">
              {error}
            </div>
          )}
          
          <div>
            <label htmlFor="username" className="tw-block tw-text-sm tw-font-medium tw-text-gray-300">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="tw-mt-1 tw-block tw-w-full tw-rounded-md tw-bg-neutral-800 tw-border-neutral-700 tw-text-white"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="tw-block tw-text-sm tw-font-medium tw-text-gray-300">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="tw-mt-1 tw-block tw-w-full tw-rounded-md tw-bg-neutral-800 tw-border-neutral-700 tw-text-white"
              required
            />
          </div>

          <button
            type="submit"
            className="tw-w-full tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-font-bold tw-py-2 tw-px-4 tw-rounded-lg"
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};