import React from 'react';

export const LoadingScreen = () => {
  return (
    <div className="tw-fixed tw-inset-0 tw-bg-[#0a0a0a] tw-flex tw-items-center tw-justify-center tw-z-[9999]">
      <div className="tw-relative tw-w-[300px] tw-h-[300px] tw-flex tw-items-center tw-justify-center">
        {/* Background Stars */}
        <div className="tw-absolute tw-inset-0">
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="tw-absolute tw-w-1 tw-h-1 tw-bg-amber-400/30 tw-rounded-full tw-animate-twinkle"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        {/* Outer Circle - Purple */}
        <div className="tw-absolute tw-w-48 tw-h-48 tw-border-4 tw-border-t-purple-600 tw-border-r-purple-600 tw-border-b-amber-400 tw-border-l-amber-400 tw-rounded-full tw-animate-spin-fast" />
        
        {/* Middle Circle */}
        <div className="tw-absolute tw-w-36 tw-h-36 tw-border-4 tw-border-t-amber-400 tw-border-r-purple-600 tw-border-b-amber-400 tw-border-l-purple-600 tw-rounded-full tw-animate-spin-reverse-fast" />

        {/* Inner Circle */}
        <div className="tw-absolute tw-w-24 tw-h-24 tw-border-4 tw-border-t-purple-600 tw-border-r-amber-400 tw-border-b-purple-600 tw-border-l-amber-400 tw-rounded-full tw-animate-spin-fast" />

        {/* Floating Dots */}
        <div className="tw-absolute tw-w-48 tw-h-48 tw-animate-spin-medium">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="tw-absolute tw-w-2 tw-h-2 tw-bg-purple-500 tw-rounded-full tw-animate-pulse"
              style={{
                transform: `rotate(${i * 45}deg) translateY(-96px)`
              }}
            />
          ))}
        </div>

        {/* Logo */}
        <div className="tw-relative tw-z-10 tw-animate-float">
          <img 
            src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png"
            alt="Loading..."
            className="tw-w-16 tw-h-16 tw-object-contain"
            loading="eager"
            fetchpriority="high"
          />
        </div>

        {/* Glowing Background */}
        <div className="tw-absolute tw-inset-0 tw-animate-pulse">
          <div className="tw-absolute tw-top-1/2 tw-left-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-w-56 tw-h-56 tw-rounded-full tw-bg-gradient-to-br tw-from-amber-400/20 tw-to-purple-600/20 tw-blur-xl" />
        </div>

        {/* Loading Text */}
        <div className="tw-absolute -tw-bottom-16 tw-left-1/2 -tw-translate-x-1/2 tw-text-transparent tw-bg-clip-text tw-bg-gradient-to-r tw-from-amber-400 tw-to-purple-600 tw-text-xl tw-font-bold tw-animate-pulse">
          جاري التحميل...
        </div>
      </div>
    </div>
  );
};