import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, Car, Home, Hotel, Briefcase, Warehouse,
  Building, TreePine, Landmark, Factory, Store, 
  CarFront, Bus, Truck, Ambulance, Crown, Zap, Plane
} from 'lucide-react';

interface Category {
  id: string;
  title: string;
  icon?: string;
}

interface CategoryGridProps {
  type: 'property' | 'vehicle';
  categories: Category[];
  onCategoryClick?: (category: Category) => void;
}

// Icon mapping for property categories
const propertyIcons = {
  'apartments': Building2,
  'houses': Home,
  'villas': Home,
  'chalets': Hotel,
  'resorts': Hotel,
  'hotels': Hotel,
  'shops': Store,
  'offices': Briefcase,
  'agricultural-land': TreePine,
  'residential-land': Landmark,
  'farms': TreePine,
  'warehouses': Warehouse,
  'commercial-buildings': Building,
  'investment-buildings': Building,
  'industrial-land': Factory,
  'factories': Factory
};

// Icon mapping for vehicle categories
const vehicleIcons = {
  'personal': CarFront,
  'rental-office': Car,
  'showroom': Car,
  'public-transport': Bus,
  'company': Car,
  'diesel': Truck,
  'electric-rental': Zap,
  'tourism': Plane,
  'commercial': Truck,
  'luxury': Crown,
  'sports': Car,
  'student': Bus,
  'delivery': Truck,
  'service': Car,
  'ambulance': Ambulance,
  'cargo': Truck,
  'shipping': Truck,
  'wedding': Crown
};

export const CategoryGrid: React.FC<CategoryGridProps> = ({ type, categories, onCategoryClick }) => {
  const isProperty = type === 'property';
  const accentColor = isProperty ? 'amber' : 'purple';
  const icons = isProperty ? propertyIcons : vehicleIcons;

  return (
    <div className="tw-grid tw-grid-cols-2 sm:tw-grid-cols-3 md:tw-grid-cols-4 lg:tw-grid-cols-6 tw-gap-4">
      {categories.map((category) => {
        const Icon = icons[category.id] || (isProperty ? Building2 : Car);
        
        return (
          <Link
            key={category.id}
            to={`/${type === 'property' ? 'properties' : 'vehicles'}/category/${category.id}`}
            onClick={() => onCategoryClick?.(category)}
            className={`tw-group tw-relative tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-4 tw-border tw-border-[#2a2a2a] hover:tw-border-${accentColor}-400/50 tw-transition-all tw-overflow-hidden`}
          >
            {/* Hover Effect */}
            <div className={`tw-absolute tw-inset-0 tw-bg-gradient-to-br tw-from-${accentColor}-400/10 tw-via-transparent tw-to-transparent tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity`} />
            
            {/* Content */}
            <div className="tw-flex tw-flex-col tw-items-center tw-text-center">
              {/* Icon */}
              <div className={`tw-relative tw-z-10 tw-w-12 tw-h-12 tw-rounded-full tw-bg-${accentColor}-400/10 tw-flex tw-items-center tw-justify-center tw-mb-3 group-hover:tw-scale-110 tw-transition-transform`}>
                <Icon className={`tw-w-6 tw-h-6 tw-text-${accentColor}-400`} />
              </div>

              {/* Title */}
              <h3 className="tw-text-sm tw-font-medium tw-text-gray-300 group-hover:tw-text-white tw-transition-colors">
                {category.title}
              </h3>
            </div>

            {/* Animated Border */}
            <div className="tw-absolute tw-inset-0 tw-rounded-2xl tw-border tw-border-transparent group-hover:tw-border-[#2a2a2a] tw-transition-all tw-duration-300" />
          </Link>
        );
      })}
    </div>
  );
};