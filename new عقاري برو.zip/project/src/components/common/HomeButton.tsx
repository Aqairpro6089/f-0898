import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home } from 'lucide-react';

export const HomeButton = () => {
  const navigate = useNavigate();

  return (
    <div className="tw-fixed tw-top-[120px] tw-left-8 tw-z-[999] tw-flex tw-gap-4">
      <button
        onClick={() => navigate('/properties')}
        className={`tw-group tw-relative tw-overflow-hidden tw-flex tw-items-center tw-gap-2 tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-all tw-duration-300`}
      >
        <div className="tw-absolute tw-inset-0 tw-bg-white/10 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
        <Home className="tw-w-5 tw-h-5" />
        <span className="tw-relative tw-z-10">عقارات</span>
      </button>

      <button
        onClick={() => navigate('/vehicles')}
        className={`tw-group tw-relative tw-overflow-hidden tw-flex tw-items-center tw-gap-2 tw-px-8 tw-py-3 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-xl tw-font-medium tw-transition-all tw-duration-300`}
      >
        <div className="tw-absolute tw-inset-0 tw-bg-white/10 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
        <Home className="tw-w-5 tw-h-5" />
        <span className="tw-relative tw-z-10">سيارات</span>
      </button>
    </div>
  );
};