import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';

interface PricingPlan {
  id: string;
  title: string;
  price: string;
  period: string;
  features: string[];
  color: 'purple' | 'neutral';
}

interface PricingPlansProps {
  plans: PricingPlan[];
  selectedPlan?: string;
  onSelectPlan?: (planId: string) => void;
  showTitle?: boolean;
  compact?: boolean;
}

export const PricingPlans: React.FC<PricingPlansProps> = ({
  plans,
  selectedPlan,
  onSelectPlan,
  showTitle = true,
  compact = false
}) => {
  const navigate = useNavigate();

  const handleSubscribe = (planId: string) => {
    if (onSelectPlan) {
      onSelectPlan(planId);
    } else {
      navigate('/register');
    }
  };

  return (
    <div className="tw-w-full">
      {showTitle && (
        <div className="tw-text-center tw-mb-12">
          <h2 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-4">
            اختر باقة الاشتراك
          </h2>
        </div>
      )}

      <div className={`tw-grid ${compact ? 'tw-grid-cols-3' : 'tw-grid-cols-1 md:tw-grid-cols-3'} tw-gap-8`}>
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-[#1a1a1a] tw-p-8 ${
              plan.id === selectedPlan
                ? 'tw-border-2 tw-border-purple-400'
                : 'tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50'
            } tw-transition-all tw-duration-300`}
          >
            {/* Hover Effect */}
            <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-br tw-from-purple-400/10 tw-via-transparent tw-to-transparent tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />

            {/* Content */}
            <div className="tw-relative tw-z-10">
              <div className="tw-text-center tw-mb-8">
                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">
                  {plan.title}
                </h3>
                <div className="tw-flex tw-items-baseline tw-justify-center tw-gap-2 tw-mb-2">
                  <span className="tw-text-3xl tw-font-bold tw-text-purple-400">
                    {plan.price}
                  </span>
                </div>
                <div className="tw-text-gray-400">
                  {plan.period}
                </div>
              </div>

              {/* Features List */}
              <ul className="tw-space-y-4 tw-mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="tw-flex tw-items-start tw-gap-3">
                    <CheckCircle className="tw-w-5 tw-h-5 tw-text-purple-400 tw-mt-0.5 tw-shrink-0" />
                    <span className="tw-text-gray-300">
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button
                onClick={() => handleSubscribe(plan.id)}
                className="tw-w-full tw-bg-gradient-to-r tw-from-purple-600 tw-to-purple-700 hover:tw-from-purple-700 hover:tw-to-purple-800 tw-text-white tw-font-medium tw-py-3 tw-rounded-xl tw-transition-all tw-duration-300 tw-relative tw-overflow-hidden"
              >
                <div className="tw-absolute tw-inset-0 tw-bg-white/10 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
                <span className="tw-relative tw-z-10">اشترك الآن</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};