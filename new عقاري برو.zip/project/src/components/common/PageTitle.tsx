import React from 'react';

interface PageTitleProps {
  title: string;
  subtitle?: string;
}

export const PageTitle: React.FC<PageTitleProps> = ({ title, subtitle }) => {
  return (
    <div className="tw-relative tw-bg-[#1a1a1a] tw-border-b tw-border-[#2a2a2a] tw-py-8">
      <div className="tw-container tw-mx-auto tw-px-4">
        <div className="tw-relative">
          {/* Title */}
          <h1 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-2">
            {title}
          </h1>
          
          {/* Animated Underline */}
          <div className="tw-absolute -tw-bottom-1 tw-right-0 tw-w-1/2 tw-h-0.5 tw-bg-gradient-to-l tw-from-amber-400 tw-to-purple-600 tw-animate-pulse" />
          <div className="tw-absolute -tw-bottom-1 tw-right-0 tw-w-1/2 tw-h-0.5 tw-bg-gradient-to-l tw-from-amber-400 tw-to-purple-600 tw-blur-sm" />

          {/* Subtitle */}
          {subtitle && (
            <p className="tw-text-gray-400 tw-mt-4">
              {subtitle}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};