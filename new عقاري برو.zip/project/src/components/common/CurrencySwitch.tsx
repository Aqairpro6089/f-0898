import React, { useState } from 'react';
import { DollarSign } from 'lucide-react';

export const CurrencySwitch = () => {
  const [currency, setCurrency] = useState<'USD' | 'SAR' | 'YER'>('USD');
  const [isOpen, setIsOpen] = useState(false);

  const currencies = {
    USD: {
      name: 'USD',
      symbol: '$',
      flag: '🇺🇸'
    },
    SAR: {
      name: 'SAR',
      symbol: '﷼',
      flag: '🇸🇦'
    },
    YER: {
      name: 'YER',
      symbol: '﷼',
      flag: '🇾🇪'
    }
  };

  const handleCurrencyChange = (curr: 'USD' | 'SAR' | 'YER') => {
    setCurrency(curr);
    setIsOpen(false);
  };

  return (
    <div className="tw-relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1.5 tw-rounded-lg tw-bg-neutral-800/50 hover:tw-bg-neutral-700/50 tw-transition-all tw-duration-300 tw-text-white tw-backdrop-blur-sm"
      >
        <DollarSign className="tw-w-4 tw-h-4" />
        <span className="tw-text-sm tw-font-medium">{currencies[currency].name}</span>
        <svg
          className={`tw-w-4 tw-h-4 tw-transition-transform tw-duration-300 ${isOpen ? 'tw-rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="tw-absolute tw-z-50 tw-mt-2 tw-w-full tw-min-w-[120px] tw-rounded-lg tw-bg-neutral-800/95 tw-backdrop-blur-lg tw-shadow-lg tw-ring-1 tw-ring-white/10 tw-transition-all tw-duration-300 tw-animate-fadeIn">
          {Object.entries(currencies).map(([code, { name, flag }]) => (
            <button
              key={code}
              onClick={() => handleCurrencyChange(code as 'USD' | 'SAR' | 'YER')}
              className={`tw-flex tw-items-center tw-gap-2 tw-w-full tw-px-4 tw-py-2.5 tw-text-left hover:tw-bg-neutral-700/50 tw-transition-colors ${
                currency === code ? 'tw-text-amber-400' : 'tw-text-white'
              } ${
                code === 'YER' 
                  ? 'tw-rounded-b-lg' 
                  : code === 'USD' 
                    ? 'tw-rounded-t-lg' 
                    : ''
              }`}
            >
              <span className="tw-text-lg">{flag}</span>
              <span className="tw-text-sm tw-font-medium">{name}</span>
              {currency === code && (
                <svg className="tw-w-4 tw-h-4 tw-ml-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};