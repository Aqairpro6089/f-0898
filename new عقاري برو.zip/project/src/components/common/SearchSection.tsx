import React, { useState } from 'react';
import { Search, ChevronDown, MapPin } from 'lucide-react';

interface SearchSectionProps {
  type: 'property' | 'vehicle';
  onSearch: (filters: any) => void;
}

export const SearchSection: React.FC<SearchSectionProps> = ({ type, onSearch }) => {
  const [listingType, setListingType] = useState<'rent' | 'sale'>('rent');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [filters, setFilters] = useState({
    keyword: '',
    location: '',
    category: ''
  });

  const isProperty = type === 'property';
  const accentColor = isProperty ? 'amber' : 'purple';

  return (
    <div className="tw-relative tw-py-8 tw-bg-[#0a0a0a]">
      <div className="tw-absolute tw-inset-0">
        <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
      </div>

      <div className="tw-container tw-mx-auto tw-px-4">
        {/* Title */}
        <div className="tw-text-center tw-mb-6">
          <h1 className="tw-text-2xl md:tw-text-3xl tw-font-bold tw-text-white tw-mb-2">
            هل تبحث عن {type === 'property' ? 'عقار' : 'سيارة'}؟
          </h1>
          <p className="tw-text-base tw-text-gray-400">
            {type === 'property' 
              ? 'ابحث عن العقار المناسب من خلال خيارات البحث المتقدمة'
              : 'ابحث عن السيارة المناسبة من خلال خيارات البحث المتقدمة'
            }
          </p>
        </div>

        {/* Search Box */}
        <div className="tw-max-w-4xl tw-mx-auto">
          <div className="tw-relative">
            {/* Glowing Effect */}
            <div className={`tw-absolute -tw-inset-0.5 tw-bg-gradient-to-r tw-from-${accentColor}-400/20 tw-via-${accentColor}-400/10 tw-to-${accentColor}-400/20 tw-rounded-2xl tw-blur-sm tw-animate-pulse`} />
            
            <div className="tw-relative tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden">
              {/* Listing Type Tabs */}
              <div className="tw-flex tw-gap-1 tw-p-1">
                <button 
                  onClick={() => setListingType('rent')}
                  className={`tw-flex-1 tw-py-2.5 tw-text-center tw-rounded-xl tw-font-medium tw-transition-colors ${
                    listingType === 'rent'
                      ? `tw-bg-${accentColor}-400 tw-text-${isProperty ? 'black' : 'white'}`
                      : 'tw-text-white hover:tw-bg-neutral-800'
                  }`}
                >
                  للإيجار
                </button>
                <button 
                  onClick={() => setListingType('sale')}
                  className={`tw-flex-1 tw-py-2.5 tw-text-center tw-rounded-xl tw-font-medium tw-transition-colors ${
                    listingType === 'sale'
                      ? `tw-bg-${accentColor}-400 tw-text-${isProperty ? 'black' : 'white'}`
                      : 'tw-text-white hover:tw-bg-neutral-800'
                  }`}
                >
                  للبيع
                </button>
              </div>

              {/* Search Fields */}
              <div className="tw-p-4">
                <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-4">
                  {/* Keyword Search */}
                  <div className="tw-relative">
                    <Search className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                    <input
                      type="text"
                      placeholder="ابحث هنا..."
                      value={filters.keyword}
                      onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
                      className={`tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-2.5 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-${accentColor}-400`}
                    />
                  </div>

                  {/* Location */}
                  <div className="tw-relative">
                    <MapPin className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                    <select
                      value={filters.location}
                      onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                      className={`tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-2.5 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-${accentColor}-400 tw-appearance-none`}
                    >
                      <option value="">اختر الموقع</option>
                      <option value="sanaa">صنعاء</option>
                      <option value="aden">عدن</option>
                      <option value="taiz">تعز</option>
                    </select>
                  </div>

                  {/* Search Button */}
                  <button
                    onClick={() => onSearch(filters)}
                    className={`tw-relative tw-overflow-hidden tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-8 tw-py-2.5 tw-rounded-xl tw-font-medium tw-transition-all tw-duration-300 ${
                      type === 'property'
                        ? 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
                        : 'tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white'
                    }`}
                  >
                    {/* Button Glow Effect */}
                    <div className={`tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-${accentColor}-400/0 tw-via-${accentColor}-400/30 tw-to-${accentColor}-400/0 tw-opacity-0 hover:tw-opacity-100 tw-transition-opacity`} />
                    
                    {/* Button Content */}
                    <div className="tw-relative tw-z-10 tw-flex tw-items-center tw-gap-2">
                      <Search className="tw-w-5 tw-h-5" />
                      <span>بحث</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};