import React from 'react';
import { Search } from 'lucide-react';

interface SearchBarProps {
  type: 'property' | 'vehicle';
  onSearch: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ type, onSearch }) => {
  const isProperty = type === 'property';
  const accentColor = isProperty ? 'amber' : 'purple';
  
  return (
    <div className="tw-w-full tw-max-w-[1320px] tw-mx-auto">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-shadow-lg">
        {/* Listing Type Tabs */}
        <div className="tw-flex tw-gap-1 tw-p-1">
          <button className={`tw-flex-1 tw-py-3 tw-text-center tw-rounded-xl tw-font-medium tw-transition-colors ${
            isProperty 
              ? 'tw-bg-amber-400 tw-text-black' 
              : 'tw-bg-purple-600 tw-text-white'
          }`}>
            للبيع
          </button>
          <button className="tw-flex-1 tw-py-3 tw-text-white tw-text-center tw-rounded-xl hover:tw-bg-neutral-800 tw-transition-colors">
            للإيجار
          </button>
        </div>

        {/* Search Fields */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-1 tw-p-1">
          {/* Category/Brand */}
          <div className="tw-relative tw-bg-neutral-800 tw-rounded-xl tw-px-4 tw-py-3">
            <label className="tw-block tw-text-xs tw-text-gray-400 tw-mb-1">
              {isProperty ? 'الفئة' : 'الماركة'}
            </label>
            <select className="tw-w-full tw-bg-transparent tw-text-white tw-border-none tw-outline-none tw-appearance-none">
              <option value="">{isProperty ? 'اختر الفئة' : 'اختر الماركة'}</option>
              {isProperty ? (
                <>
                  <option value="apartment">شقق</option>
                  <option value="villa">فلل</option>
                  <option value="land">أراضي</option>
                </>
              ) : (
                <>
                  <option value="toyota">تويوتا</option>
                  <option value="honda">هوندا</option>
                  <option value="nissan">نيسان</option>
                </>
              )}
            </select>
          </div>

          {/* Location */}
          <div className="tw-relative tw-bg-neutral-800 tw-rounded-xl tw-px-4 tw-py-3">
            <label className="tw-block tw-text-xs tw-text-gray-400 tw-mb-1">
              {isProperty ? 'المنطقة' : 'المدينة'}
            </label>
            <select className="tw-w-full tw-bg-transparent tw-text-white tw-border-none tw-outline-none tw-appearance-none">
              <option value="">اختر المدينة</option>
              <option value="sanaa">صنعاء</option>
              <option value="aden">عدن</option>
              <option value="taiz">تعز</option>
            </select>
          </div>

          {/* Search Input */}
          <div className="tw-relative tw-bg-neutral-800 tw-rounded-xl tw-px-4 tw-py-3">
            <label className="tw-block tw-text-xs tw-text-gray-400 tw-mb-1">
              البحث في الموقع
            </label>
            <div className="tw-flex tw-items-center">
              <Search className="tw-w-4 tw-h-4 tw-text-gray-400" />
              <input
                type="text"
                placeholder="ابحث هنا..."
                className="tw-w-full tw-bg-transparent tw-text-white tw-border-none tw-outline-none tw-pr-2"
              />
            </div>
          </div>

          {/* Search Button */}
          <button
            onClick={onSearch}
            className={`tw-h-full tw-rounded-xl tw-font-medium tw-transition-colors ${
              isProperty
                ? 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
                : 'tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white'
            }`}
          >
            بحث
          </button>
        </div>
      </div>
    </div>
  );
};