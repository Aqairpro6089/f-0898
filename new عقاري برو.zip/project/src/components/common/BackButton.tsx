import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export const BackButton = () => {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(-1)}
      className="tw-group tw-fixed tw-right-8 tw-top-[120px] tw-z-[999] tw-flex tw-items-center tw-gap-2 tw-bg-[#1a1a1a]/80 tw-backdrop-blur-sm hover:tw-bg-purple-600/20 tw-px-4 tw-py-3 tw-rounded-xl tw-transition-all tw-duration-300"
    >
      {/* Glowing Effect */}
      <div className="tw-absolute tw-inset-0 tw-bg-purple-600/20 tw-rounded-xl tw-opacity-0 group-hover:tw-opacity-100 tw-blur-xl tw-transition-opacity" />
      
      {/* Arrow Icon */}
      <ArrowRight className="tw-w-6 tw-h-6 tw-text-purple-400 group-hover:tw-text-purple-300 tw-transition-colors tw-relative tw-z-10" />
      
      {/* Text */}
      <span className="tw-text-white tw-font-medium tw-relative tw-z-10">
        رجوع
      </span>
    </button>
  );
};