import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Globe, Shield, FileText, HelpCircle } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="tw-relative tw-bg-[#0a0a0a] tw-border-t tw-border-[#1a1a1a]">
      {/* Background Effects */}
      <div className="tw-absolute tw-inset-0">
        <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-t tw-from-purple-900/20 tw-via-transparent tw-to-transparent" />
        <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
      </div>

      <div className="tw-container tw-mx-auto tw-px-4 tw-relative tw-z-10">
        {/* Main Footer Content */}
        <div className="tw-py-16 tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-4 tw-gap-8">
          {/* Company Info */}
          <div>
            <Link to="/" className="tw-block tw-mb-6">
              <img 
                src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png"
                alt="Aqari Pro"
                className="tw-h-16 tw-w-auto"
              />
            </Link>
            <p className="tw-text-gray-400 tw-mb-6">
              منصة رائدة في مجال العقارات والسيارات في اليمن، نوفر خدمات متكاملة للبيع والشراء والتأجير
            </p>
            <div className="tw-space-y-3">
              <div className="tw-flex tw-items-center tw-gap-3 tw-text-gray-400">
                <MapPin className="tw-w-5 tw-h-5 tw-text-purple-400" />
                <span>صنعاء - بيت بوس</span>
              </div>
              <div className="tw-flex tw-items-center tw-gap-3 tw-text-gray-400">
                <Phone className="tw-w-5 tw-h-5 tw-text-purple-400" />
                <span>+967-782-654-018</span>
              </div>
              <div className="tw-flex tw-items-center tw-gap-3 tw-text-gray-400">
                <Mail className="tw-w-5 tw-h-5 tw-text-purple-400" />
                <span>info@aqaripro.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-6">روابط سريعة</h3>
            <ul className="tw-space-y-3">
              <li>
                <Link to="/properties" className="tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">العقارات</Link>
              </li>
              <li>
                <Link to="/vehicles" className="tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">السيارات</Link>
              </li>
              <li>
                <Link to="/blog" className="tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">المدونة</Link>
              </li>
              <li>
                <Link to="/contact" className="tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">اتصل بنا</Link>
              </li>
              <li>
                <Link to="/admin-login" className="tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">دخول الإدارة</Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-6">الدعم</h3>
            <ul className="tw-space-y-3">
              <li>
                <Link to="/help" className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">
                  <HelpCircle className="tw-w-4 tw-h-4" />
                  <span>مركز المساعدة</span>
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">
                  <Shield className="tw-w-4 tw-h-4" />
                  <span>سياسة الخصوصية</span>
                </Link>
              </li>
              <li>
                <Link to="/terms" className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-purple-400 tw-transition-colors">
                  <FileText className="tw-w-4 tw-h-4" />
                  <span>الشروط والأحكام</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-6">النشرة البريدية</h3>
            <p className="tw-text-gray-400 tw-mb-4">
              اشترك في نشرتنا البريدية للحصول على آخر الأخبار والعروض
            </p>
            <form className="tw-space-y-4">
              <div className="tw-relative">
                <input
                  type="email"
                  placeholder="البريد الإلكتروني"
                  className="tw-w-full tw-bg-[#1a1a1a] tw-border tw-border-[#2a2a2a] tw-rounded-lg tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
                />
              </div>
              <button
                type="submit"
                className="tw-w-full tw-bg-gradient-to-r tw-from-purple-600 tw-to-purple-700 hover:tw-from-purple-700 hover:tw-to-purple-800 tw-text-white tw-font-medium tw-py-3 tw-px-4 tw-rounded-lg tw-transition-colors"
              >
                اشتراك
              </button>
            </form>
          </div>
        </div>

        {/* Social Links */}
        <div className="tw-py-8 tw-border-t tw-border-[#1a1a1a]">
          <div className="tw-flex tw-flex-col md:tw-flex-row tw-items-center tw-justify-between tw-gap-4">
            <div className="tw-flex tw-items-center tw-gap-4">
              <a 
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="tw-p-2 tw-bg-[#1a1a1a] hover:tw-bg-purple-400/10 tw-rounded-lg tw-transition-colors group"
              >
                <Facebook className="tw-w-5 tw-h-5 tw-text-gray-400 group-hover:tw-text-purple-400" />
              </a>
              <a 
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="tw-p-2 tw-bg-[#1a1a1a] hover:tw-bg-purple-400/10 tw-rounded-lg tw-transition-colors group"
              >
                <Instagram className="tw-w-5 tw-h-5 tw-text-gray-400 group-hover:tw-text-purple-400" />
              </a>
              <a 
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="tw-p-2 tw-bg-[#1a1a1a] hover:tw-bg-purple-400/10 tw-rounded-lg tw-transition-colors group"
              >
                <Twitter className="tw-w-5 tw-h-5 tw-text-gray-400 group-hover:tw-text-purple-400" />
              </a>
              <a 
                href="https://aqaripro.com"
                target="_blank"
                rel="noopener noreferrer"
                className="tw-p-2 tw-bg-[#1a1a1a] hover:tw-bg-purple-400/10 tw-rounded-lg tw-transition-colors group"
              >
                <Globe className="tw-w-5 tw-h-5 tw-text-gray-400 group-hover:tw-text-purple-400" />
              </a>
            </div>
            <p className="tw-text-gray-400 tw-text-sm">
              © {new Date().getFullYear()} عقاري برو. جميع الحقوق محفوظة
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;