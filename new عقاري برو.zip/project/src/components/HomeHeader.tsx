import React, { useState } from 'react';
import { TopHeader } from './TopHeader';
import { useNavigate } from 'react-router-dom';
import { UserPlus, LogIn, Menu, ChevronDown, Building2, Car, Search, FileText, MessageCircle, HelpCircle } from 'lucide-react';

export const HomeHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const navigate = useNavigate();

  const menuItems = {
    'العقارات': [
      { label: 'جميع العقارات', href: '/properties' },
      { label: 'شقق', href: '/properties/category/apartments' },
      { label: 'فلل', href: '/properties/category/villas' },
      { label: 'أراضي', href: '/properties/category/lands' },
      { label: 'محلات تجارية', href: '/properties/category/shops' }
    ],
    'الخدمات': [
      { label: 'خدمات العقارات', href: '/property/services' },
      { label: 'خدمات السيارات', href: '/vehicle/services' },
      { label: 'الاستشارات', href: '/services/consulting' },
      { label: 'التقييم العقاري', href: '/services/valuation' }
    ],
    'المدونة': [
      { label: 'جميع المقالات', href: '/blog' },
      { label: 'نصائح عقارية', href: '/blog/category/property-tips' },
      { label: 'نصائح السيارات', href: '/blog/category/vehicle-tips' },
      { label: 'أخبار السوق', href: '/blog/category/market-news' }
    ]
  };

  return (
    <>
      <TopHeader />
      <header className="tw-sticky tw-top-[48px] tw-z-[999] tw-px-4 tw-py-3">
        <div className="tw-max-w-[1320px] tw-mx-auto">
          <div className="tw-relative tw-overflow-hidden tw-rounded-xl tw-border tw-border-[#2a2a2a] tw-h-[80px]">
            {/* Background Effects */}
            <div className="tw-absolute tw-inset-0">
              {/* Dark Background with Purple Gradient */}
              <div className="tw-absolute tw-inset-0 tw-bg-black/95 tw-backdrop-blur-xl" />
              <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-purple-900/90 tw-to-black/90 tw-backdrop-blur-xl" />
              <div className="tw-absolute tw-inset-0 tw-rounded-xl tw-border tw-border-purple-900/20 tw-animate-pulse" />
            </div>

            {/* Content */}
            <div className="tw-relative tw-flex tw-items-center tw-justify-between tw-h-full tw-px-6">
              {/* Logo */}
              <div className="tw-flex tw-items-center tw-gap-12">
                <a href="/" className="tw-block">
                  <img 
                    className="tw-h-[50px] tw-w-auto" 
                    src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png" 
                    alt="Aqari Pro" 
                  />
                </a>

                {/* Navigation Menu */}
                <nav className="tw-hidden lg:tw-flex tw-items-center tw-gap-8">
                  {Object.entries(menuItems).map(([category, items]) => (
                    <div 
                      key={category}
                      className="tw-relative"
                      onMouseEnter={() => setActiveDropdown(category)}
                      onMouseLeave={() => setActiveDropdown(null)}
                    >
                      <button className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-white tw-transition-colors">
                        <span>{category}</span>
                        <ChevronDown className={`tw-w-4 tw-h-4 tw-transition-transform ${activeDropdown === category ? 'tw-rotate-180' : ''}`} />
                      </button>

                      {/* Dropdown Menu */}
                      {activeDropdown === category && (
                        <div className="tw-absolute tw-top-full tw-right-0 tw-mt-2 tw-w-56 tw-rounded-xl tw-bg-black/95 tw-border tw-border-purple-900/20 tw-shadow-xl">
                          <div className="tw-py-2">
                            {items.map((item, index) => (
                              <a
                                key={index}
                                href={item.href}
                                className="tw-flex tw-items-center tw-px-4 tw-py-2 tw-text-gray-400 hover:tw-text-white hover:tw-bg-purple-900/20 tw-transition-colors"
                              >
                                {item.label}
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </nav>
              </div>

              {/* Auth Buttons */}
              <div className="tw-flex tw-items-center tw-gap-4">
                <div className="tw-hidden md:tw-flex tw-items-center tw-gap-3">
                  <a 
                    href="/register"
                    className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-[#2a2a2a] hover:tw-bg-[#3a3a3a] tw-text-white tw-rounded-lg tw-font-medium tw-transition-colors"
                  >
                    <UserPlus className="tw-w-4 tw-h-4" />
                    <span>التسجيل</span>
                  </a>
                  <a 
                    href="/login"
                    className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-gradient-to-r tw-from-emerald-500 tw-to-emerald-600 hover:tw-from-emerald-600 hover:tw-to-emerald-700 tw-text-white tw-rounded-lg tw-font-medium tw-transition-colors tw-shadow-lg tw-shadow-emerald-500/20"
                  >
                    <LogIn className="tw-w-4 tw-h-4" />
                    <span>تسجيل الدخول</span>
                  </a>
                </div>

                {/* Mobile Menu Button */}
                <button 
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="tw-block md:tw-hidden tw-p-2 tw-rounded-lg hover:tw-bg-purple-900/20 tw-transition-colors"
                >
                  <Menu className="tw-w-5 tw-h-5 tw-text-white" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="tw-fixed tw-inset-0 tw-z-[1000] tw-bg-black/95 tw-backdrop-blur-xl md:tw-hidden">
          <div className="tw-h-full tw-overflow-y-auto tw-pt-20 tw-pb-8 tw-px-6">
            {/* Close Button */}
            <button 
              onClick={() => setIsMenuOpen(false)}
              className="tw-absolute tw-top-6 tw-right-6 tw-p-2 tw-rounded-lg hover:tw-bg-purple-900/20"
            >
              <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Mobile Navigation */}
            <div className="tw-space-y-6">
              {Object.entries(menuItems).map(([category, items]) => (
                <div key={category} className="tw-space-y-4">
                  <h3 className="tw-text-lg tw-font-bold tw-text-white">{category}</h3>
                  <div className="tw-space-y-2">
                    {items.map((item, index) => (
                      <a
                        key={index}
                        href={item.href}
                        className="tw-block tw-px-4 tw-py-2 tw-text-gray-400 hover:tw-text-white hover:tw-bg-purple-900/20 tw-rounded-lg tw-transition-colors"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Mobile Auth Buttons */}
            <div className="tw-fixed tw-bottom-0 tw-left-0 tw-right-0 tw-p-6 tw-bg-gradient-to-t tw-from-black tw-to-transparent">
              <div className="tw-flex tw-flex-col tw-gap-4">
                <a 
                  href="/register"
                  className="tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-[#2a2a2a] hover:tw-bg-[#3a3a3a] tw-text-white tw-rounded-xl tw-font-medium"
                >
                  <UserPlus className="tw-w-5 tw-h-5" />
                  <span>التسجيل</span>
                </a>
                <a 
                  href="/login"
                  className="tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-gradient-to-r tw-from-emerald-500 tw-to-emerald-600 hover:tw-from-emerald-600 hover:tw-to-emerald-700 tw-text-white tw-rounded-xl tw-font-medium"
                >
                  <LogIn className="tw-w-5 tw-h-5" />
                  <span>تسجيل الدخول</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default HomeHeader;