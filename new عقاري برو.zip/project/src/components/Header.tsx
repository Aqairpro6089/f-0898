import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Crown, LogOut, User, ChevronDown, 
  Settings, Bell, Heart, FileText,
  Building2, Car, Search, Menu
} from 'lucide-react';
import { CurrencySwitch } from './common/CurrencySwitch';

interface HeaderProps {
  defaultSection?: 'real-estate' | 'cars';
}

export const Header: React.FC<HeaderProps> = ({ defaultSection = 'real-estate' }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user, logout } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const handleSectionChange = (section: 'real-estate' | 'cars') => {
    if (section === 'real-estate') {
      navigate('/properties');
    } else {
      navigate('/vehicles');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  // Get navigation items based on section
  const getNavItems = () => {
    if (defaultSection === 'cars') {
      return [
        { path: '/vehicles', label: 'السيارات' },
        { path: '/vehicle-requests', label: 'السيارات المطلوبة' },
        { path: '/vehicle/subscriptions', label: 'الاشتراكات' },
        { path: '/vehicle/blog', label: 'المدونة' },
        { path: '/vehicle/services', label: 'خدماتنا' },
        { path: '/vehicle/contact', label: 'تواصل معنا' },
        { path: '/vehicle/about', label: 'عنا' }
      ];
    }
    return [
      { path: '/properties', label: 'العقارات' },
      { path: '/property-requests', label: 'العقارات المطلوبة' },
      { path: '/property/subscriptions', label: 'الاشتراكات' },
      { path: '/property/blog', label: 'المدونة' },
      { path: '/property/services', label: 'خدماتنا' },
      { path: '/property/contact', label: 'تواصل معنا' },
      { path: '/property/about', label: 'عنا' }
    ];
  };

  const navItems = getNavItems();
  const accentColor = defaultSection === 'cars' ? 'purple' : 'amber';

  return (
    <header className="tw-sticky tw-top-0 tw-z-[999] tw-bg-gradient-to-b tw-from-black/95 tw-to-black/90 tw-backdrop-blur-xl">
      {/* Top Bar with User Info */}
      {isAuthenticated && (
        <div className="tw-bg-[#1a1a1a] tw-border-b tw-border-[#2a2a2a]">
          <div className="tw-max-w-[1320px] tw-mx-auto tw-px-6">
            <div className="tw-h-16 tw-flex tw-items-center tw-justify-end">
              <div className="tw-flex tw-items-center tw-gap-6">
                {/* Notifications */}
                <button className="tw-relative tw-p-2 tw-text-gray-400 hover:tw-text-white tw-transition-colors">
                  <Bell className="tw-w-6 tw-h-6" />
                  <span className={`tw-absolute tw-top-1 tw-right-1 tw-w-2 tw-h-2 tw-bg-${accentColor}-400 tw-rounded-full`} />
                </button>

                {/* Profile Menu */}
                <div className="tw-relative">
                  <button 
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="tw-flex tw-items-center tw-gap-4 tw-py-2 tw-px-4 tw-rounded-xl hover:tw-bg-[#2a2a2a] tw-transition-colors"
                  >
                    {/* Profile Icon */}
                    <div className="tw-relative">
                      <div className={`tw-absolute tw-inset-0 tw-rounded-full tw-bg-gradient-to-r tw-from-${accentColor}-400 tw-to-${accentColor}-600 tw-animate-pulse tw-blur`} />
                      <div className={`tw-relative tw-w-10 tw-h-10 tw-bg-[#1a1a1a] tw-rounded-full tw-flex tw-items-center tw-justify-center tw-border-2 tw-border-transparent hover:tw-border-${accentColor}-400 tw-transition-colors`}>
                        <User className={`tw-w-6 tw-h-6 tw-text-${accentColor}-400`} />
                      </div>
                    </div>
                    
                    <div className="tw-text-right">
                      <div className="tw-text-base tw-font-medium tw-text-white">
                        {user?.username}
                      </div>
                      <div className="tw-text-sm tw-text-gray-400">
                        {user?.role === 'admin' ? 'مدير النظام' : 'عضو'}
                      </div>
                    </div>
                    
                    <ChevronDown className={`tw-w-5 tw-h-5 tw-text-gray-400 tw-transition-transform ${showProfileMenu ? 'tw-rotate-180' : ''}`} />
                  </button>

                  {/* Profile Dropdown */}
                  {showProfileMenu && (
                    <div className="tw-absolute tw-left-0 tw-mt-2 tw-w-64 tw-rounded-2xl tw-bg-[#1a1a1a] tw-border tw-border-[#2a2a2a] tw-shadow-xl">
                      <div className="tw-p-4">
                        <div className="tw-flex tw-items-center tw-gap-3 tw-mb-4 tw-pb-4 tw-border-b tw-border-[#2a2a2a]">
                          <div className="tw-w-12 tw-h-12 tw-bg-[#2a2a2a] tw-rounded-xl tw-flex tw-items-center tw-justify-center">
                            <User className={`tw-w-6 tw-h-6 tw-text-${accentColor}-400`} />
                          </div>
                          <div>
                            <div className="tw-font-medium tw-text-white">{user?.username}</div>
                            <div className="tw-text-sm tw-text-gray-400">{user?.email}</div>
                          </div>
                        </div>

                        <div className="tw-space-y-2">
                          <Link 
                            to="/profile" 
                            className="tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-text-gray-300 hover:tw-text-white hover:tw-bg-[#2a2a2a] tw-rounded-xl tw-transition-colors"
                          >
                            <User className="tw-w-5 tw-h-5" />
                            <span>الملف الشخصي</span>
                          </Link>
                          <Link 
                            to="/settings" 
                            className="tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-text-gray-300 hover:tw-text-white hover:tw-bg-[#2a2a2a] tw-rounded-xl tw-transition-colors"
                          >
                            <Settings className="tw-w-5 tw-h-5" />
                            <span>الإعدادات</span>
                          </Link>
                          {user?.role === 'admin' && (
                            <Link 
                              to="/admin" 
                              className={`tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-text-${accentColor}-400 hover:tw-text-${accentColor}-300 hover:tw-bg-[#2a2a2a] tw-rounded-xl tw-transition-colors`}
                            >
                              <Crown className="tw-w-5 tw-h-5" />
                              <span>لوحة التحكم</span>
                            </Link>
                          )}
                          <button 
                            onClick={handleLogout}
                            className="tw-w-full tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-text-red-400 hover:tw-text-red-300 hover:tw-bg-[#2a2a2a] tw-rounded-xl tw-transition-colors"
                          >
                            <LogOut className="tw-w-5 tw-h-5" />
                            <span>تسجيل خروج</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Header */}
      <div className="tw-max-w-[1320px] tw-mx-auto tw-px-6">
        <div className="tw-flex tw-items-center tw-justify-between tw-h-24">
          {/* Logo */}
          <div className="tw-flex tw-items-center tw-gap-8">
            <Link to="/" className="tw-block">
              <img 
                src="https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png"
                alt="Aqari Pro"
                className="tw-h-16 tw-w-auto"
              />
            </Link>
            <CurrencySwitch />
          </div>

          {/* Main Navigation */}
          <nav className="tw-hidden lg:tw-flex tw-items-center tw-gap-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`tw-text-lg tw-text-white hover:tw-text-${accentColor}-400 tw-transition-colors`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Section Switch */}
          <div className="tw-hidden md:tw-flex tw-items-center tw-gap-3">
            <button
              onClick={() => handleSectionChange('real-estate')}
              className={`tw-px-8 tw-py-3 tw-rounded-xl tw-font-medium tw-text-lg tw-transition-all ${
                defaultSection === 'real-estate'
                  ? 'tw-bg-amber-400 tw-text-black tw-shadow-lg tw-shadow-amber-400/20'
                  : 'tw-text-white hover:tw-text-amber-400'
              }`}
            >
              عقارات
            </button>
            <button
              onClick={() => handleSectionChange('cars')}
              className={`tw-px-8 tw-py-3 tw-rounded-xl tw-font-medium tw-text-lg tw-transition-all ${
                defaultSection === 'cars'
                  ? 'tw-bg-purple-600 tw-text-white tw-shadow-lg tw-shadow-purple-600/20'
                  : 'tw-text-white hover:tw-text-purple-400'
              }`}
            >
              سيارات
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="tw-block lg:tw-hidden tw-p-3 tw-rounded-xl hover:tw-bg-[#2a2a2a] tw-transition-colors"
          >
            <Menu className="tw-w-6 tw-h-6 tw-text-white" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="tw-lg:hidden tw-fixed tw-inset-0 tw-z-50 tw-bg-black/95 tw-backdrop-blur-xl">
          <div className="tw-h-full tw-overflow-y-auto">
            <div className="tw-p-6">
              {/* Close Button */}
              <button 
                onClick={() => setShowMobileMenu(false)}
                className="tw-absolute tw-top-6 tw-right-6 tw-p-2 tw-rounded-lg hover:tw-bg-[#2a2a2a] tw-transition-colors"
              >
                <svg className="tw-w-6 tw-h-6 tw-text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

              {/* Mobile Navigation */}
              <nav className="tw-mt-16 tw-space-y-4">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`tw-block tw-text-xl tw-text-white hover:tw-text-${accentColor}-400 tw-transition-colors tw-py-3`}
                    onClick={() => setShowMobileMenu(false)}
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>

              {/* Mobile Section Switch */}
              <div className="tw-mt-8 tw-flex tw-flex-col tw-gap-4">
                <button
                  onClick={() => {
                    handleSectionChange('real-estate');
                    setShowMobileMenu(false);
                  }}
                  className={`tw-w-full tw-px-8 tw-py-4 tw-rounded-xl tw-font-medium tw-text-xl tw-transition-all ${
                    defaultSection === 'real-estate'
                      ? 'tw-bg-amber-400 tw-text-black'
                      : 'tw-bg-[#2a2a2a] tw-text-white'
                  }`}
                >
                  عقارات
                </button>
                <button
                  onClick={() => {
                    handleSectionChange('cars');
                    setShowMobileMenu(false);
                  }}
                  className={`tw-w-full tw-px-8 tw-py-4 tw-rounded-xl tw-font-medium tw-text-xl tw-transition-all ${
                    defaultSection === 'cars'
                      ? 'tw-bg-purple-600 tw-text-white'
                      : 'tw-bg-[#2a2a2a] tw-text-white'
                  }`}
                >
                  سيارات
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;