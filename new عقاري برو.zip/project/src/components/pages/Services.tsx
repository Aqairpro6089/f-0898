import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Building2, Car, Search, FileText, MessageCircle, Camera } from 'lucide-react';

export const Services = () => {
  const services = [
    {
      icon: Building2,
      title: 'خدمات العقارات',
      description: 'نقدم خدمات شاملة في مجال العقارات تشمل البيع والشراء والتأجير',
      features: [
        'عرض وتسويق العقارات',
        'تقييم العقارات',
        'استشارات عقارية',
        'خدمات الوساطة العقارية'
      ]
    },
    {
      icon: Car,
      title: 'خدمات السيارات',
      description: 'خدمات متكاملة في مجال السيارات تلبي جميع احتياجاتكم',
      features: [
        'بيع وشراء السيارات',
        'تقييم السيارات',
        'خدمات الوساطة',
        'استشارات فنية'
      ]
    },
    {
      icon: Search,
      title: 'خدمات البحث',
      description: 'نساعدك في العثور على ما تبحث عنه بسهولة وسرعة',
      features: [
        'بحث مخصص',
        'تصفية متقدمة',
        'إشعارات مباشرة',
        'مقارنة العروض'
      ]
    },
    {
      icon: FileText,
      title: 'الخدمات القانونية',
      description: 'نقدم خدمات قانونية شاملة لضمان سلامة معاملاتكم',
      features: [
        'صياغة العقود',
        'مراجعة المستندات',
        'استشارات قانونية',
        'توثيق المعاملات'
      ]
    },
    {
      icon: MessageCircle,
      title: 'خدمة العملاء',
      description: 'فريق متخصص لخدمتكم والإجابة على استفساراتكم',
      features: [
        'دعم على مدار الساعة',
        'مساعدة مباشرة',
        'متابعة الطلبات',
        'حل المشكلات'
      ]
    },
    {
      icon: Camera,
      title: 'خدمات التصوير',
      description: 'خدمات تصوير احترافية لعقاراتكم وسياراتكم',
      features: [
        'تصوير فوتوغرافي',
        'تصوير فيديو',
        'تصوير جوي',
        'جولات افتراضية'
      ]
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="خدماتنا"
        subtitle="نقدم مجموعة متكاملة من الخدمات لتلبية احتياجاتكم"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
            >
              {/* Icon */}
              <div className="tw-bg-amber-400/10 tw-w-16 tw-h-16 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-6">
                <service.icon className="tw-w-8 tw-h-8 tw-text-amber-400" />
              </div>

              {/* Title & Description */}
              <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">{service.title}</h3>
              <p className="tw-text-gray-400 tw-mb-6">{service.description}</p>

              {/* Features List */}
              <ul className="tw-space-y-3">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="tw-flex tw-items-center tw-gap-2 tw-text-gray-300">
                    <span className="tw-w-1.5 tw-h-1.5 tw-bg-amber-400 tw-rounded-full" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;