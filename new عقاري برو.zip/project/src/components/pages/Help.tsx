import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Book, MessageCircle, Mail, Phone, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Help = () => {
  const helpCategories = [
    {
      title: 'دليل المستخدم',
      icon: Book,
      description: 'تعرف على كيفية استخدام منصة عقاري برو',
      link: '/help/guide'
    },
    {
      title: 'الأسئلة الشائعة',
      icon: HelpCircle,
      description: 'إجابات على الأسئلة الأكثر شيوعاً',
      link: '/faq'
    },
    {
      title: 'الدعم الفني',
      icon: MessageCircle,
      description: 'تواصل مع فريق الدعم الفني',
      link: '/contact'
    }
  ];

  const commonQuestions = [
    {
      question: 'كيف يمكنني إضافة إعلان؟',
      answer: 'يمكنك إضافة إعلان بسهولة من خلال الضغط على زر "إضافة إعلان" في الصفحة الرئيسية أو من خلال لوحة التحكم الخاصة بك.'
    },
    {
      question: 'كيف يمكنني تعديل إعلاناتي؟',
      answer: 'يمكنك تعديل إعلاناتك من خلال الذهاب إلى "إعلاناتي" في لوحة التحكم الخاصة بك والضغط على زر "تعديل" بجانب الإعلان المراد تعديله.'
    },
    {
      question: 'ما هي مميزات الحساب المميز؟',
      answer: 'يتمتع الحساب المميز بالعديد من المميزات مثل عدد أكبر من الإعلانات، وإمكانية إضافة المزيد من الصور، وظهور الإعلانات في الأعلى.'
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="مركز المساعدة"
        subtitle="نحن هنا لمساعدتك في كل ما تحتاجه"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Search Section */}
        <div className="tw-max-w-2xl tw-mx-auto tw-mb-16">
          <div className="tw-relative">
            <Search className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
            <input
              type="text"
              placeholder="ابحث عن المساعدة..."
              className="tw-w-full tw-bg-[#1a1a1a] tw-border tw-border-[#2a2a2a] tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-4 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>
        </div>

        {/* Help Categories */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-8 tw-mb-16">
          {helpCategories.map((category, index) => (
            <Link
              key={index}
              to={category.link}
              className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
            >
              <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                <category.icon className="tw-w-6 tw-h-6 tw-text-amber-400" />
              </div>
              <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">
                {category.title}
              </h3>
              <p className="tw-text-gray-400">
                {category.description}
              </p>
            </Link>
          ))}
        </div>

        {/* Common Questions */}
        <div className="tw-max-w-3xl tw-mx-auto">
          <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-8 tw-text-center">
            الأسئلة الشائعة
          </h2>
          <div className="tw-space-y-4">
            {commonQuestions.map((item, index) => (
              <details
                key={index}
                className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden"
              >
                <summary className="tw-flex tw-items-center tw-justify-between tw-p-6 tw-cursor-pointer tw-select-none">
                  <h3 className="tw-text-lg tw-font-medium tw-text-white">
                    {item.question}
                  </h3>
                  <div className="tw-relative tw-w-5 tw-h-5">
                    <div className="tw-absolute tw-top-1/2 tw-left-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-w-0.5 tw-h-5 tw-bg-amber-400 group-open:tw-rotate-90 tw-transition-transform" />
                    <div className="tw-absolute tw-top-1/2 tw-left-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-0.5 tw-bg-amber-400" />
                  </div>
                </summary>
                <div className="tw-p-6 tw-pt-0">
                  <p className="tw-text-gray-400">
                    {item.answer}
                  </p>
                </div>
              </details>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <div className="tw-mt-16 tw-text-center">
          <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-4">
            لم تجد ما تبحث عنه؟
          </h2>
          <p className="tw-text-gray-400 tw-mb-8">
            فريق الدعم الفني متواجد على مدار الساعة لمساعدتك
          </p>
          <div className="tw-flex tw-flex-wrap tw-justify-center tw-gap-4">
            <a 
              href="mailto:support@aqaripro.com"
              className="tw-flex tw-items-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-[#1a1a1a] hover:tw-bg-[#2a2a2a] tw-text-white tw-rounded-xl tw-transition-colors"
            >
              <Mail className="tw-w-5 tw-h-5" />
              <span>support@aqaripro.com</span>
            </a>
            <a 
              href="tel:+967782654018"
              className="tw-flex tw-items-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-[#1a1a1a] hover:tw-bg-[#2a2a2a] tw-text-white tw-rounded-xl tw-transition-colors"
            >
              <Phone className="tw-w-5 tw-h-5" />
              <span>+967-782-654-018</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Help;