import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { useNavigate } from 'react-router-dom';
import { 
  Building2, Car, DollarSign, Shield, 
  Plus, ArrowRight, Crown, Star,
  CreditCard, Wallet
} from 'lucide-react';

export const AddListings = () => {
  const navigate = useNavigate();
  const [amount, setAmount] = useState(5);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');

  // Payment tiers with features
  const tiers = [
    {
      amount: 5,
      features: [
        '3 إعلانات عقارية إضافية',
        '3 إعلانات سيارات إضافية',
        'صور إضافية لكل إعلان'
      ]
    },
    {
      amount: 25,
      features: [
        '10 إعلانات عقارية إضافية',
        '10 إعلانات سيارات إضافية',
        'صور غير محدودة لكل إعلان',
        'ترويج الإعلانات'
      ]
    },
    {
      amount: 50,
      features: [
        '20 إعلان عقاري إضافي',
        '20 إعلان سيارات إضافي',
        'صور وفيديوهات غير محدودة',
        'ترويج مميز للإعلانات'
      ]
    },
    {
      amount: 100,
      features: [
        'إعلانات عقارية غير محدودة',
        'إعلانات سيارات غير محدودة',
        'جميع المميزات المتقدمة',
        'دعم VIP'
      ]
    },
    {
      amount: 200,
      features: [
        'إعلانات غير محدودة للعقارات والسيارات',
        'طلبات غير محدودة',
        'صور وفيديوهات غير محدودة',
        'جميع المميزات المتقدمة',
        'دعم VIP مخصص'
      ]
    }
  ];

  const paymentMethods = {
    ye: [
      { id: 'kuraimi', name: 'بنك الكريمي', icon: Wallet },
      { id: 'jawali', name: 'جوالي', icon: Wallet },
      { id: 'cash', name: 'الدفع نقداً', icon: Wallet }
    ],
    us: [
      { id: 'paypal', name: 'PayPal', icon: Wallet },
      { id: 'card', name: 'Credit/Debit Card', icon: CreditCard }
    ]
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    setAmount(Math.min(Math.max(value, 5), 200)); // Clamp between 5 and 200
  };

  const getCurrentTier = () => {
    return tiers.find(tier => tier.amount <= amount) || tiers[0];
  };

  const PaymentModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-w-full tw-max-w-md">
        <h3 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-6">اختر طريقة الدفع</h3>
        
        <div className="tw-space-y-4">
          {paymentMethods.ye.map((method) => (
            <button
              key={method.id}
              onClick={() => setSelectedPaymentMethod(method.id)}
              className={`tw-w-full tw-flex tw-items-center tw-gap-3 tw-p-4 tw-rounded-xl tw-transition-all ${
                selectedPaymentMethod === method.id
                  ? 'tw-bg-amber-400/20 tw-border-amber-400/50'
                  : 'tw-bg-neutral-800 tw-border-transparent'
              } tw-border hover:tw-border-amber-400/50`}
            >
              <div className="tw-p-3 tw-rounded-lg tw-bg-amber-400/10">
                <method.icon className="tw-w-6 tw-h-6 tw-text-amber-400" />
              </div>
              <div className="tw-flex-1 tw-text-right">
                <div className="tw-font-medium tw-text-white">{method.name}</div>
              </div>
              <div className={`tw-w-4 tw-h-4 tw-rounded-full tw-border-2 ${
                selectedPaymentMethod === method.id
                  ? 'tw-border-amber-400 tw-bg-amber-400'
                  : 'tw-border-gray-400'
              }`} />
            </button>
          ))}
        </div>

        <div className="tw-mt-6 tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowPaymentModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={() => {
              // Handle payment processing
              console.log('Processing payment:', amount, 'with method:', selectedPaymentMethod);
              setShowPaymentModal(false);
            }}
            disabled={!selectedPaymentMethod}
            className={`tw-px-4 tw-py-2 tw-rounded-lg ${
              selectedPaymentMethod
                ? 'tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black'
                : 'tw-bg-neutral-700 tw-text-gray-400 tw-cursor-not-allowed'
            }`}
          >
            متابعة الدفع
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="إضافة إعلانات"
        subtitle="اشترِ إعلانات إضافية لعقاراتك وسياراتك"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Payment Calculator */}
        <div className="tw-max-w-4xl tw-mx-auto">
          <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8">
            {/* Amount Slider */}
            <div className="tw-mb-8">
              <div className="tw-flex tw-items-center tw-justify-between tw-mb-4">
                <label className="tw-text-lg tw-font-medium tw-text-white">المبلغ</label>
                <div className="tw-text-3xl tw-font-bold tw-text-amber-400">
                  ${amount}
                </div>
              </div>
              <input
                type="range"
                min="5"
                max="200"
                step="5"
                value={amount}
                onChange={handleAmountChange}
                className="tw-w-full tw-h-2 tw-bg-neutral-700 tw-rounded-full tw-appearance-none [&::-webkit-slider-thumb]:tw-appearance-none [&::-webkit-slider-thumb]:tw-w-6 [&::-webkit-slider-thumb]:tw-h-6 [&::-webkit-slider-thumb]:tw-rounded-full [&::-webkit-slider-thumb]:tw-bg-amber-400 [&::-webkit-slider-thumb]:tw-cursor-pointer"
              />
              <div className="tw-flex tw-justify-between tw-mt-2">
                <span className="tw-text-sm tw-text-gray-400">$5</span>
                <span className="tw-text-sm tw-text-gray-400">$200</span>
              </div>
            </div>

            {/* Features List */}
            <div className="tw-mb-8">
              <h3 className="tw-text-lg tw-font-medium tw-text-white tw-mb-4">
                المميزات المتاحة
              </h3>
              <ul className="tw-space-y-3">
                {getCurrentTier().features.map((feature, index) => (
                  <li key={index} className="tw-flex tw-items-center tw-gap-3">
                    <div className="tw-p-1 tw-bg-amber-400/10 tw-rounded-lg">
                      <Star className="tw-w-4 tw-h-4 tw-text-amber-400" />
                    </div>
                    <span className="tw-text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Security Notice */}
            <div className="tw-bg-purple-600/10 tw-border tw-border-purple-600/20 tw-rounded-xl tw-p-6 tw-mb-8">
              <div className="tw-flex tw-items-start tw-gap-4">
                <div className="tw-p-2 tw-bg-purple-600/20 tw-rounded-lg">
                  <Shield className="tw-w-6 tw-h-6 tw-text-purple-400" />
                </div>
                <div>
                  <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">
                    دفع آمن 100%
                  </h3>
                  <p className="tw-text-gray-400">
                    جميع المعاملات مشفرة ومؤمنة. نستخدم أحدث تقنيات الأمان لحماية بياناتك.
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Button */}
            <button
              onClick={() => setShowPaymentModal(true)}
              className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-font-medium tw-py-4 tw-rounded-xl tw-transition-colors"
            >
              <Plus className="tw-w-5 tw-h-5" />
              <span>شراء الإعلانات الآن</span>
              <ArrowRight className="tw-w-5 tw-h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && <PaymentModal />}
    </div>
  );
};

export default AddListings;