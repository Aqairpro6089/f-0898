import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Building2, Users, Star, Shield, Clock, Globe } from 'lucide-react';

export const About = () => {
  const features = [
    {
      icon: Building2,
      title: 'خبرة واسعة',
      description: 'أكثر من 10 سنوات في مجال العقارات والسيارات'
    },
    {
      icon: Users,
      title: 'فريق متخصص',
      description: 'فريق من الخبراء المتخصصين في خدمتكم'
    },
    {
      icon: Star,
      title: 'خدمة متميزة',
      description: 'نقدم خدمة عملاء متميزة على مدار الساعة'
    },
    {
      icon: Shield,
      title: 'موثوقية وأمان',
      description: 'نضمن سلامة وأمان جميع المعاملات'
    },
    {
      icon: Clock,
      title: 'سرعة الاستجابة',
      description: 'نستجيب لطلباتكم بأسرع وقت ممكن'
    },
    {
      icon: Globe,
      title: 'تغطية واسعة',
      description: 'نغطي جميع مناطق اليمن'
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="عن عقاري برو"
        subtitle="تعرف على قصتنا ورؤيتنا وقيمنا"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Vision Section */}
        <div className="tw-mb-16">
          <h2 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-6 tw-text-center">رؤيتنا</h2>
          <p className="tw-text-gray-400 tw-text-lg tw-max-w-3xl tw-mx-auto tw-text-center tw-leading-relaxed">
            نسعى لأن نكون المنصة الرائدة في مجال العقارات والسيارات في اليمن، من خلال تقديم خدمات مبتكرة وحلول متكاملة تلبي احتياجات عملائنا وتسهل عليهم عملية البيع والشراء.
          </p>
        </div>

        {/* Features Grid */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8">
          {features.map((feature, index) => (
            <div key={index} className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all">
              <div className="tw-bg-amber-400/10 tw-w-16 tw-h-16 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-6">
                <feature.icon className="tw-w-8 tw-h-8 tw-text-amber-400" />
              </div>
              <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">{feature.title}</h3>
              <p className="tw-text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Values Section */}
        <div className="tw-mt-16">
          <h2 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-6 tw-text-center">قيمنا</h2>
          <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-border tw-border-[#2a2a2a]">
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-8">
              <div>
                <h3 className="tw-text-xl tw-font-bold tw-text-amber-400 tw-mb-4">الشفافية والنزاهة</h3>
                <p className="tw-text-gray-400 tw-leading-relaxed">
                  نؤمن بأهمية الشفافية والنزاهة في جميع تعاملاتنا، ونحرص على تقديم معلومات دقيقة وواضحة لعملائنا.
                </p>
              </div>
              <div>
                <h3 className="tw-text-xl tw-font-bold tw-text-amber-400 tw-mb-4">الجودة والتميز</h3>
                <p className="tw-text-gray-400 tw-leading-relaxed">
                  نسعى دائماً لتقديم أعلى مستويات الجودة في خدماتنا، ونحرص على التميز في كل ما نقدمه.
                </p>
              </div>
              <div>
                <h3 className="tw-text-xl tw-font-bold tw-text-amber-400 tw-mb-4">الابتكار والتطوير</h3>
                <p className="tw-text-gray-400 tw-leading-relaxed">
                  نواكب التطور التكنولوجي ونبتكر حلولاً جديدة لتحسين تجربة عملائنا.
                </p>
              </div>
              <div>
                <h3 className="tw-text-xl tw-font-bold tw-text-amber-400 tw-mb-4">خدمة العملاء</h3>
                <p className="tw-text-gray-400 tw-leading-relaxed">
                  نضع رضا العملاء في مقدمة أولوياتنا ونسعى دائماً لتلبية احتياجاتهم وتوقعاتهم.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;