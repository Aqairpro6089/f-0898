import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Building2, Car, DollarSign, Shield, User, CreditCard, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

export const FAQ = () => {
  const categories = [
    {
      title: 'العقارات',
      icon: Building2,
      questions: [
        {
          question: 'كيف يمكنني إضافة عقار للبيع أو للإيجار؟',
          answer: 'يمكنك إضافة عقار بسهولة من خلال حسابك الشخصي. قم بتسجيل الدخول، ثم اضغط على زر "إضافة عقار" واتبع الخطوات البسيطة لإكمال الإعلان.'
        },
        {
          question: 'ما هي المستندات المطلوبة لإضافة عقار؟',
          answer: 'تحتاج إلى صور واضحة للعقار، ومعلومات دقيقة عن الموقع والمساحة والسعر. في حالة كنت وكيل عقاري، قد تحتاج إلى إثبات تفويضك لبيع العقار.'
        },
        {
          question: 'كم مدة بقاء إعلان العقار نشط؟',
          answer: 'تختلف المدة حسب نوع حسابك. الحسابات المجانية تستمر لمدة 30 يوماً، بينما الحسابات المميزة تستمر لمدة 90 يوماً مع إمكانية التجديد.'
        }
      ]
    },
    {
      title: 'السيارات',
      icon: Car,
      questions: [
        {
          question: 'كيف يمكنني إضافة سيارة للبيع؟',
          answer: 'عملية إضافة سيارة مشابهة للعقارات. قم بتسجيل الدخول، اختر "إضافة سيارة"، وأدخل تفاصيل السيارة وصورها.'
        },
        {
          question: 'ما هي المعلومات المهمة عند إضافة سيارة؟',
          answer: 'يجب ذكر الماركة، الموديل، سنة الصنع، عدد الكيلومترات، نوع الوقود، ناقل الحركة، والسعر المطلوب.'
        }
      ]
    },
    {
      title: 'الحساب والعضوية',
      icon: User,
      questions: [
        {
          question: 'كيف يمكنني إنشاء حساب؟',
          answer: 'يمكنك إنشاء حساب مجاني بسهولة من خلال الضغط على "تسجيل" وإدخال بياناتك الأساسية.'
        },
        {
          question: 'ما الفرق بين الحساب الشخصي والتجاري؟',
          answer: 'الحساب التجاري يوفر مميزات إضافية مثل عدد أكبر من الإعلانات، وإمكانية إضافة معلومات الشركة وشعارها.'
        }
      ]
    },
    {
      title: 'الدفع والاشتراكات',
      icon: CreditCard,
      questions: [
        {
          question: 'ما هي طرق الدفع المتاحة؟',
          answer: 'نقبل الدفع عبر البطاقات الائتمانية، التحويل البنكي، والمحافظ الإلكترونية المحلية.'
        },
        {
          question: 'هل يمكنني إلغاء اشتراكي؟',
          answer: 'نعم، يمكنك إلغاء اشتراكك في أي وقت من خلال إعدادات حسابك.'
        }
      ]
    },
    {
      title: 'الأسعار والعمولات',
      icon: DollarSign,
      questions: [
        {
          question: 'هل هناك عمولة على البيع؟',
          answer: 'لا نفرض أي عمولة على عمليات البيع. الرسوم الوحيدة هي رسوم الاشتراك في الباقات المميزة.'
        },
        {
          question: 'كم تكلفة الإعلان المميز؟',
          answer: 'تختلف تكلفة الإعلان المميز حسب نوع الباقة المختارة. يمكنك الاطلاع على التفاصيل في صفحة الاشتراكات.'
        }
      ]
    },
    {
      title: 'الأمان والخصوصية',
      icon: Shield,
      questions: [
        {
          question: 'كيف تحمون بيانات المستخدمين؟',
          answer: 'نستخدم أحدث تقنيات التشفير لحماية بياناتك الشخصية ونلتزم بسياسة خصوصية صارمة.'
        },
        {
          question: 'هل يمكن للآخرين رؤية معلوماتي الشخصية؟',
          answer: 'لا، نعرض فقط المعلومات التي تختار مشاركتها في إعلاناتك. معلوماتك الشخصية محمية تماماً.'
        }
      ]
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="الأسئلة الشائعة"
        subtitle="إجابات على الأسئلة الأكثر شيوعاً"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        <div className="tw-max-w-4xl tw-mx-auto">
          {categories.map((category, index) => (
            <div key={index} className="tw-mb-12 tw-last:mb-0">
              <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
                <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
                  <category.icon className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h2 className="tw-text-2xl tw-font-bold tw-text-white">
                  {category.title}
                </h2>
              </div>

              <div className="tw-space-y-4">
                {category.questions.map((item, qIndex) => (
                  <details
                    key={qIndex}
                    className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden"
                  >
                    <summary className="tw-flex tw-items-center tw-justify-between tw-p-6 tw-cursor-pointer tw-select-none">
                      <h3 className="tw-text-lg tw-font-medium tw-text-white">
                        {item.question}
                      </h3>
                      <div className="tw-relative tw-w-5 tw-h-5">
                        <div className="tw-absolute tw-top-1/2 tw-left-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-w-0.5 tw-h-5 tw-bg-amber-400 group-open:tw-rotate-90 tw-transition-transform" />
                        <div className="tw-absolute tw-top-1/2 tw-left-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-0.5 tw-bg-amber-400" />
                      </div>
                    </summary>
                    <div className="tw-p-6 tw-pt-0">
                      <p className="tw-text-gray-400">
                        {item.answer}
                      </p>
                    </div>
                  </details>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Still Have Questions */}
        <div className="tw-mt-16 tw-text-center">
          <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-4">
            لديك المزيد من الأسئلة Continuing exactly where we left off:

```typescript
            لديك المزيد من الأسئلة؟
          </h2>
          <p className="tw-text-gray-400 tw-mb-8">
            فريق الدعم الفني متواجد على مدار الساعة لمساعدتك
          </p>
          <Link
            to="/contact"
            className="tw-inline-flex tw-items-center tw-gap-2 tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-colors"
          >
            <Mail className="tw-w-5 tw-h-5" />
            <span>تواصل معنا</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default FAQ;