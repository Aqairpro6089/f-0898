import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Shield, Lock, Eye, Database, Bell, Trash2 } from 'lucide-react';

export const Privacy = () => {
  const sections = [
    {
      title: 'جمع البيانات',
      icon: Database,
      content: [
        'المعلومات الشخصية (الاسم، البريد الإلكتروني، رقم الهاتف)',
        'معلومات الحساب (اسم المستخدم، كلمة المرور المشفرة)',
        'بيانات الإعلانات (الصور، الأوصاف، الأسعار)',
        'بيانات التصفح (عنوان IP، نوع المتصفح، الموقع)'
      ]
    },
    {
      title: 'استخدام البيانات',
      icon: Eye,
      content: [
        'تقديم وتحسين خدماتنا',
        'التواصل معك بخصوص حسابك وإعلاناتك',
        'إرسال تحديثات وإشعارات مهمة',
        'تحليل وتحسين أداء الموقع'
      ]
    },
    {
      title: 'حماية البيانات',
      icon: Shield,
      content: [
        'تشفير جميع البيانات الحساسة',
        'مراقبة مستمرة لأمن النظام',
        'تحديثات أمنية دورية',
        'فريق أمن متخصص لحماية البيانات'
      ]
    },
    {
      title: 'حقوق المستخدم',
      icon: Lock,
      content: [
        'الوصول إلى بياناتك الشخصية',
        'تصحيح أو تحديث معلوماتك',
        'طلب حذف حسابك وبياناتك',
        'الاعتراض على معالجة بياناتك'
      ]
    },
    {
      title: 'الإشعارات والتواصل',
      icon: Bell,
      content: [
        'إشعارات حول الإعلانات والعروض',
        'تحديثات مهمة حول الخدمة',
        'رسائل الدعم الفني',
        'إمكانية إلغاء الاشتراك في أي وقت'
      ]
    },
    {
      title: 'حذف البيانات',
      icon: Trash2,
      content: [
        'إمكانية حذف حسابك في أي وقت',
        'حذف جميع بياناتك الشخصية',
        'الاحتفاظ بالبيانات القانونية المطلوبة فقط',
        'تأكيد حذف البيانات بشكل نهائي'
      ]
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="سياسة الخصوصية"
        subtitle="نلتزم بحماية خصوصيتك وبياناتك الشخصية"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Introduction */}
        <div className="tw-max-w-3xl tw-mx-auto tw-text-center tw-mb-16">
          <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8">
            <div className="tw-flex tw-justify-center tw-mb-6">
              <div className="tw-p-3 tw-bg-amber-400/10 tw-rounded-xl">
                <Shield className="tw-w-8 tw-h-8 tw-text-amber-400" />
              </div>
            </div>
            <p className="tw-text-gray-400 tw-leading-relaxed">
              نحن في عقاري برو نقدر خصوصيتك ونلتزم بحماية بياناتك الشخصية. تشرح هذه السياسة كيفية جمع واستخدام وحماية معلوماتك عند استخدام منصتنا.
            </p>
          </div>
        </div>

        {/* Privacy Sections */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-8">
          {sections.map((section, index) => (
            <div key={index} className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
              <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
                <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
                  <section.icon className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h2 className="tw-text-xl tw-font-bold tw-text-white">
                  {section.title}
                </h2>
              </div>
              <ul className="tw-space-y-4">
                {section.content.map((item, itemIndex) => (
                  <li key={itemIndex} className="tw-flex tw-items-start tw-gap-3">
                    <div className="tw-w-2 tw-h-2 tw-bg-amber-400 tw-rounded-full tw-mt-2" />
                    <p className="tw-text-gray-400">{item}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Privacy;