import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { MapPin, Phone, Mail, MessageCircle, Send } from 'lucide-react';

export const Contact = () => {
  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="تواصل معنا"
        subtitle="نحن هنا لمساعدتك والإجابة على استفساراتك"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        <div className="tw-grid tw-grid-cols-1 lg:tw-grid-cols-2 tw-gap-8">
          {/* Contact Form */}
          <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-border tw-border-[#2a2a2a]">
            <h2 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-6">أرسل رسالة</h2>
            <form className="tw-space-y-6">
              <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    الاسم
                  </label>
                  <input
                    type="text"
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                    placeholder="أدخل اسمك"
                  />
                </div>
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    البريد الإلكتروني
                  </label>
                  <input
                    type="email"
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                    placeholder="بريدك الإلكتروني"
                  />
                </div>
              </div>

              <div>
                <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                  الموضوع
                </label>
                <input
                  type="text"
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  placeholder="موضوع الرسالة"
                />
              </div>

              <div>
                <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                  الرسالة
                </label>
                <textarea
                  rows={6}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  placeholder="اكتب رسالتك هنا..."
                />
              </div>

              <button
                type="submit"
                className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-font-medium tw-py-3 tw-px-6 tw-rounded-xl tw-transition-colors"
              >
                <Send className="tw-w-4 tw-h-4" />
                <span>إرسال الرسالة</span>
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="tw-space-y-8">
            {/* Info Cards */}
            <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
              <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                  <MapPin className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">العنوان</h3>
                <p className="tw-text-gray-400">صنعاء - بيت بوس</p>
              </div>

              <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                  <Phone className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">الهاتف</h3>
                <p className="tw-text-gray-400">+967-782-654-018</p>
              </div>

              <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                  <Mail className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">البريد الإلكتروني</h3>
                <p className="tw-text-gray-400">info@aqaripro.com</p>
              </div>

              <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                  <MessageCircle className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">الدعم الفني</h3>
                <p className="tw-text-gray-400">support@aqaripro.com</p>
              </div>
            </div>

            {/* Map */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
              <div className="tw-aspect-[16/9] tw-rounded-lg tw-overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15334.514391917!2d44.2066673!3d15.3067649!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1603db4eaaab3cf3%3A0x939bf7c7ae6be926!2sBait%20Baws%2C%20Yemen!5e0!3m2!1sen!2s!4v1710561547749!5m2!1sen!2s"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;