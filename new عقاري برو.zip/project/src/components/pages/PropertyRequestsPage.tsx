import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { Search, Filter, Plus, MapPin, Bed, Bath, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export const PropertyRequestsPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('الكل');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Mock property requests data
  const propertyRequests = [
    {
      id: 1,
      title: 'شقة عائلة من اربعة افراد',
      location: 'صنعاء, صنعاء',
      description: 'نبحث عن شقة لأربعة افراد في وسط المدينة',
      type: 'شقة',
      status: ['مميز', 'ايجار', 'Request'],
      beds: 4,
      baths: 2,
      budget: {
        min: 170,
        max: 226
      },
      user: {
        name: 'معاذ علي',
        avatar: 'https://i.pravatar.cc/150?img=1'
      }
    },
    {
      id: 2,
      title: 'شقة عزوبي',
      location: 'صنعاء, صنعاء',
      description: 'شقة عزوبي لطالب جامعة',
      type: 'شقة',
      status: ['ايجار', 'Request'],
      beds: 5,
      baths: 2,
      budget: {
        min: 75,
        max: 113
      },
      user: {
        name: 'محمد عبدالله',
        avatar: 'https://i.pravatar.cc/150?img=2'
      }
    },
    {
      id: 3,
      title: 'محل فتحتين',
      location: 'صنعاء, صنعاء',
      description: 'نبحث عن محل فتحتين',
      type: 'محل',
      status: ['ايجار', 'Request'],
      beds: 1,
      budget: {
        min: 283,
        max: 377
      },
      user: {
        name: 'عمار عبدالرحمن',
        avatar: 'https://i.pravatar.cc/150?img=3'
      }
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <div className="tw-relative">
        <div className="tw-absolute tw-inset-0">
          <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="tw-absolute tw-w-1 tw-h-1 tw-bg-white/10 tw-rounded-full tw-animate-twinkle"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`
              }}
            />
          ))}
        </div>

        <div className="tw-relative tw-py-16">
          <div className="tw-container tw-mx-auto tw-px-4">
            {/* Page Title */}
            <div className="tw-text-center tw-mb-12">
              <div className="tw-text-amber-400 tw-mb-2">الرئيسية</div>
              <h1 className="tw-text-4xl tw-font-bold tw-text-white">طلبات العقارات</h1>
            </div>

            {/* Search Box */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
              <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-4 tw-gap-4">
                {/* Keyword Search */}
                <div className="tw-col-span-2">
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">
                    الكلمة المفتاحية
                  </label>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="البحث عن الطلبات..."
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">
                    الموقع
                  </label>
                  <select
                    value={selectedLocation}
                    onChange={(e) => setSelectedLocation(e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  >
                    <option value="">البحث عن الموقع</option>
                    <option value="sanaa">صنعاء</option>
                    <option value="aden">عدن</option>
                    <option value="taiz">تعز</option>
                  </select>
                </div>

                {/* Type */}
                <div>
                  <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">
                    الفئة
                  </label>
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  >
                    <option value="الكل">الكل</option>
                    <option value="شقة">شقة</option>
                    <option value="فيلا">فيلا</option>
                    <option value="محل">محل تجاري</option>
                  </select>
                </div>
              </div>

              {/* Advanced Search Toggle */}
              <div className="tw-mt-4">
                <button
                  onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
                  className="tw-flex tw-items-center tw-gap-2 tw-text-amber-400 hover:tw-text-amber-500 tw-transition-colors"
                >
                  <Filter className="tw-w-4 tw-h-4" />
                  <span>خيارات متقدمة</span>
                  <ArrowLeft className={`tw-w-4 tw-h-4 tw-transition-transform ${showAdvancedSearch ? 'tw-rotate-90' : ''}`} />
                </button>
              </div>

              {/* Advanced Search Options */}
              {showAdvancedSearch && (
                <div className="tw-mt-6 tw-pt-6 tw-border-t tw-border-neutral-700">
                  <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
                    {/* Price Range */}
                    <div className="tw-space-y-4">
                      <label className="tw-block tw-text-sm tw-text-gray-400">
                        نطاق السعر
                      </label>
                      <div className="tw-flex tw-gap-4">
                        <input
                          type="number"
                          placeholder="من"
                          className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                        />
                        <input
                          type="number"
                          placeholder="إلى"
                          className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                        />
                      </div>
                    </div>

                    {/* Bedrooms */}
                    <div>
                      <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">
                        غرف النوم
                      </label>
                      <select className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
                        <option value="">الكل</option>
                        {[1,2,3,4,5,6].map(num => (
                          <option key={num} value={num}>{num}+</option>
                        ))}
                      </select>
                    </div>

                    {/* Bathrooms */}
                    <div>
                      <label className="tw-block tw-text-sm tw-text-gray-400 tw-mb-2">
                        الحمامات
                      </label>
                      <select className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400">
                        <option value="">الكل</option>
                        {[1,2,3,4].map(num => (
                          <option key={num} value={num}>{num}+</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Search Button */}
              <div className="tw-mt-6 tw-flex tw-justify-between tw-items-center">
                <button className="tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-colors">
                  بحث
                </button>
                <Link
                  to="/property-requests/new"
                  className="tw-flex tw-items-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-xl tw-transition-colors"
                >
                  <Plus className="tw-w-4 tw-h-4" />
                  <span>إضافة طلب</span>
                </Link>
              </div>
            </div>

            {/* Results Grid */}
            <div className="tw-mt-12 tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-6">
              {propertyRequests.map((request) => (
                <div 
                  key={request.id}
                  className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
                >
                  <div className="tw-p-6">
                    {/* Status Tags */}
                    <div className="tw-flex tw-flex-wrap tw-gap-2 tw-mb-4">
                      {request.status.includes('مميز') && (
                        <span className="tw-px-3 tw-py-1 tw-bg-amber-400 tw-text-black tw-rounded-full tw-text-sm tw-font-medium">
                          مميز
                        </span>
                      )}
                      {request.status.includes('ايجار') && (
                        <span className="tw-px-3 tw-py-1 tw-bg-purple-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                          ايجار
                        </span>
                      )}
                      {request.status.includes('Request') && (
                        <span className="tw-px-3 tw-py-1 tw-bg-emerald-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                          Request
                        </span>
                      )}
                    </div>

                    {/* Location */}
                    <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-mb-3">
                      <MapPin className="tw-w-4 tw-h-4" />
                      <span className="tw-text-sm">{request.location}</span>
                    </div>

                    {/* Title */}
                    <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">
                      {request.title}
                    </h3>

                    {/* Description */}
                    <p className="tw-text-gray-400 tw-mb-6">
                      {request.description}
                    </p>

                    {/* Property Details */}
                    <div className="tw-flex tw-items-center tw-gap-6 tw-mb-6">
                      {request.beds && (
                        <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                          <Bed className="tw-w-4 tw-h-4" />
                          <span>{request.beds} غرف</span>
                        </div>
                      )}
                      {request.baths && (
                        <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                          <Bath className="tw-w-4 tw-h-4" />
                          <span>{request.baths} حمامات</span>
                        </div>
                      )}
                    </div>

                    {/* User Info and Budget */}
                    <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
                      <div className="tw-flex tw-items-center tw-gap-3">
                        <img 
                          src={request.user.avatar} 
                          alt={request.user.name}
                          className="tw-w-10 tw-h-10 tw-rounded-full tw-object-cover"
                        />
                        <div>
                          <div className="tw-text-white tw-font-medium">{request.user.name}</div>
                          <div className="tw-text-sm tw-text-gray-400">صاحب الطلب</div>
                        </div>
                      </div>
                      <div className="tw-text-xl tw-font-bold tw-text-amber-400">
                        ${request.budget.min} - ${request.budget.max}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyRequestsPage;