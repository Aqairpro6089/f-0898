import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Calendar, User, ArrowLeft } from 'lucide-react';

export const Blog = () => {
  const blogPosts = [
    {
      id: 1,
      title: 'نصائح مهمة عند شراء منزل جديد',
      excerpt: 'تعرف على أهم النصائح التي يجب مراعاتها عند شراء منزل جديد...',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&auto=format&fit=crop&q=60',
      date: '15 مارس 2024',
      author: 'أحمد محمد',
      category: 'عقارات'
    },
    {
      id: 2,
      title: 'كيف تختار السيارة المناسبة لك',
      excerpt: 'دليلك الشامل لاختيار السيارة التي تناسب احتياجاتك وميزانيتك...',
      image: 'https://images.unsplash.com/photo-1630990325544-58e7ed0d18ea?w=800&auto=format&fit=crop&q=60',
      date: '14 مارس 2024',
      author: 'محمد علي',
      category: 'سيارات'
    },
    {
      id: 3,
      title: 'استثمار العقارات في اليمن',
      excerpt: 'تعرف على فرص الاستثمار العقاري في اليمن وأفضل المناطق للاستثمار...',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&auto=format&fit=crop&q=60',
      date: '13 مارس 2024',
      author: 'عمر أحمد',
      category: 'استثمار'
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="المدونة"
        subtitle="آخر الأخبار والمقالات في عالم العقارات والسيارات"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8">
          {blogPosts.map((post) => (
            <article 
              key={post.id}
              className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
            >
              {/* Image */}
              <div className="tw-relative tw-aspect-[16/9] tw-overflow-hidden">
                <img 
                  src={post.image}
                  alt={post.title}
                  className="tw-w-full tw-h-full tw-object-cover tw-transition-transform tw-duration-300 group-hover:tw-scale-110"
                />
                <div className="tw-absolute tw-top-4 tw-right-4">
                  <span className="tw-px-3 tw-py-1 tw-bg-amber-400 tw-text-black tw-rounded-full tw-text-sm tw-font-medium">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="tw-p-6">
                {/* Meta */}
                <div className="tw-flex tw-items-center tw-gap-4 tw-mb-4">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm">{post.date}</span>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <User className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm">{post.author}</span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4 group-hover:tw-text-amber-400 tw-transition-colors">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="tw-text-gray-400 tw-mb-6">
                  {post.excerpt}
                </p>

                {/* Read More */}
                <button className="tw-flex tw-items-center tw-gap-2 tw-text-amber-400 group-hover:tw-text-amber-500 tw-transition-colors">
                  <span>اقرأ المزيد</span>
                  <ArrowLeft className="tw-w-4 tw-h-4" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;