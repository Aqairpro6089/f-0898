import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { PricingPlans } from '../common/PricingPlans';
import { useSubscription } from '../../context/SubscriptionContext';
import { CheckCircle, Shield, Star, Clock } from 'lucide-react';

export const Subscriptions = () => {
  const { plans } = useSubscription();

  const benefits = [
    {
      icon: Shield,
      title: 'حماية متكاملة',
      description: 'نظام حماية متطور لضمان أمان معاملاتك وبياناتك الشخصية'
    },
    {
      icon: Star,
      title: 'مميزات حصرية',
      description: 'مجموعة من المميزات الحصرية للمشتركين في باقاتنا المدفوعة'
    },
    {
      icon: Clock,
      title: 'دعم على مدار الساعة',
      description: 'فريق دعم فني متخصص لمساعدتك في أي وقت'
    },
    {
      icon: CheckCircle,
      title: 'ضمان الجودة',
      description: 'نضمن لك أفضل تجربة استخدام وأعلى معايير الجودة'
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="خطط الاشتراك"
        subtitle="اختر الباقة المناسبة لاحتياجاتك"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Benefits Section */}
        <div className="tw-mb-16">
          <h2 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-8 tw-text-center">مميزات الاشتراك</h2>
          <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-4 tw-gap-8">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
              >
                <div className="tw-bg-amber-400/10 tw-w-12 tw-h-12 tw-rounded-xl tw-flex tw-items-center tw-justify-center tw-mb-4">
                  <benefit.icon className="tw-w-6 tw-h-6 tw-text-amber-400" />
                </div>
                <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">{benefit.title}</h3>
                <p className="tw-text-gray-400 tw-text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing Plans */}
        <PricingPlans plans={plans} />

        {/* FAQ Section */}
        <div className="tw-mt-16">
          <h2 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-8 tw-text-center">الأسئلة الشائعة</h2>
          <div className="tw-max-w-3xl tw-mx-auto">
            <div className="tw-space-y-4">
              <details className="tw-group tw-bg-[#1a1a1a] tw-rounde d-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <summary className="tw-flex tw-items-center tw-justify-between tw-cursor-pointer">
                  <h3 className="tw-text-lg tw-font-medium tw-text-white">كيف يمكنني الاشتراك في الباقات المدفوعة؟</h3>
                  <span className="tw-transform group-open:tw-rotate-180 tw-transition-transform">
                    <svg className="tw-w-5 tw-h-5 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <p className="tw-mt-4 tw-text-gray-400">
                  يمكنك الاشتراك في الباقات المدفوعة بسهولة من خلال اختيار الباقة المناسبة والضغط على زر "اشترك الآن". سيتم توجيهك لصفحة الدفع لإتمام عملية الاشتراك.
                </p>
              </details>

              <details className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <summary className="tw-flex tw-items-center tw-justify-between tw-cursor-pointer">
                  <h3 className="tw-text-lg tw-font-medium tw-text-white">هل يمكنني تغيير باقتي في أي وقت؟</h3>
                  <span className="tw-transform group-open:tw-rotate-180 tw-transition-transform">
                    <svg className="tw-w-5 tw-h-5 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <p className="tw-mt-4 tw-text-gray-400">
                  نعم، يمكنك ترقية أو تغيير باقتك في أي وقت. سيتم احتساب الفرق في السعر بشكل تناسبي مع المدة المتبقية من اشتراكك الحالي.
                </p>
              </details>

              <details className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <summary className="tw-flex tw-items-center tw-justify-between tw-cursor-pointer">
                  <h3 className="tw-text-lg tw-font-medium tw-text-white">ما هي طرق الدفع المتاحة؟</h3>
                  <span className="tw-transform group-open:tw-rotate-180 tw-transition-transform">
                    <svg className="tw-w-5 tw-h-5 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <p className="tw-mt-4 tw-text-gray-400">
                  نوفر العديد من طرق الدفع المختلفة بما في ذلك البطاقات الائتمانية، التحويل البنكي، والدفع عبر المحافظ الإلكترونية المحلية.
                </p>
              </details>

              <details className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a]">
                <summary className="tw-flex tw-items-center tw-justify-between tw-cursor-pointer">
                  <h3 className="tw-text-lg tw-font-medium tw-text-white">هل هناك فترة تجريبية مجانية؟</h3>
                  <span className="tw-transform group-open:tw-rotate-180 tw-transition-transform">
                    <svg className="tw-w-5 tw-h-5 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </span>
                </summary>
                <p className="tw-mt-4 tw-text-gray-400">
                  نعم، نوفر باقة مجانية يمكنك تجربتها للتعرف على خدماتنا الأساسية قبل الاشتراك في الباقات المدفوعة.
                </p>
              </details>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Subscriptions;