import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { Shield, FileText, AlertTriangle } from 'lucide-react';

export const Terms = () => {
  const sections = [
    {
      title: 'شروط الاستخدام العامة',
      content: [
        'يجب أن يكون عمر المستخدم 18 عاماً أو أكثر.',
        'يجب تقديم معلومات دقيقة وصحيحة عند التسجيل.',
        'يحظر استخدام المنصة لأي أغراض غير مشروعة.',
        'يحق لنا تعليق أو إنهاء الحساب في حالة مخالفة الشروط.'
      ]
    },
    {
      title: 'شروط نشر الإعلانات',
      content: [
        'يجب أن تكون جميع المعلومات في الإعلان دقيقة وصحيحة.',
        'يحظر نشر إعلانات مكررة أو وهمية.',
        'يجب أن تكون الصور حقيقية وحديثة للعقار أو السيارة المعلن عنها.',
        'يحق لنا رفض أو إزالة أي إعلان مخالف للشروط.'
      ]
    },
    {
      title: 'حقوق الملكية الفكرية',
      content: [
        'جميع المحتويات والتصاميم في الموقع محمية بحقوق الملكية الفكرية.',
        'يحظر نسخ أو استخدام أي محتوى من الموقع دون إذن كتابي.',
        'العلامات التجارية المعروضة هي ملك لأصحابها.',
        'يحتفظ الموقع بحق الملكية الفكرية لجميع الخدمات والمميزات.'
      ]
    },
    {
      title: 'سياسة الدفع والاشتراكات',
      content: [
        'جميع الأسعار المعروضة بالدولار الأمريكي ما لم يذكر خلاف ذلك.',
        'يتم تجديد الاشتراكات تلقائياً ما لم يتم إلغاؤها قبل 24 ساعة من موعد التجديد.',
        'لا يتم استرداد رسوم الاشتراك بعد تفعيل الخدمة.',
        'نحتفظ بحق تغيير الأسعار مع إشعار مسبق للمستخدمين.'
      ]
    },
    {
      title: 'الخصوصية وحماية البيانات',
      content: [
        'نلتزم بحماية بيانات المستخدمين وفقاً لسياسة الخصوصية.',
        'لا نشارك البيانات الشخصية مع أي طرف ثالث دون موافقة صريحة.',
        'يتم تشفير جميع البيانات الحساسة باستخدام أحدث تقنيات التشفير.',
        'للمستخدمين الحق في طلب حذف بياناتهم الشخصية.'
      ]
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="الشروط والأحكام"
        subtitle="يرجى قراءة الشروط والأحكام بعناية قبل استخدام الموقع"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Important Notice */}
        <div className="tw-bg-amber-400/10 tw-border tw-border-amber-400/20 tw-rounded-2xl tw-p-6 tw-mb-12">
          <div className="tw-flex tw-items-start tw-gap-4">
            <div className="tw-p-2 tw-bg-amber-400/20 tw-rounded-lg">
              <AlertTriangle className="tw-w-6 tw-h-6 tw-text-amber-400" />
            </div>
            <div>
              <h3 className="tw-text-lg tw-font-bold tw-text-white tw-mb-2">
                ملاحظة هامة
              </h3>
              <p className="tw-text-gray-400">
                باستخدامك لموقع عقاري برو، فإنك توافق على الالتزام بجميع الشروط والأحكام المذكورة أدناه. يرجى قراءتها بعناية.
              </p>
            </div>
          </div>
        </div>

        {/* Terms Sections */}
        <div className="tw-space-y-12">
          {sections.map((section, index) => (
            <div key={index} className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8">
              <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-6">
                {section.title}
              </h2>
              <ul className="tw-space-y-4">
                {section.content.map((item, itemIndex) => (
                  <li key={itemIndex} className="tw-flex tw-items-start tw-gap-3">
                    <div className="tw-w-2 tw-h-2 tw-bg-amber-400 tw-rounded-full tw-mt-2" />
                    <p className="tw-text-gray-400">{item}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Last Update */}
        <div className="tw-mt-12 tw-text-center tw-text-gray-400">
          <p>آخر تحديث: {new Date().toLocaleDateString('ar-YE')}</p>
        </div>
      </div>
    </div>
  );
};

export default Terms;