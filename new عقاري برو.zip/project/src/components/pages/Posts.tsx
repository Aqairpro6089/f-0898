import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { 
  Search, Filter, Plus, MapPin, Calendar, MessageCircle, 
  Heart, Share2, Eye, ArrowLeft, Building2, Car, Crown
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Posts = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  // Mock posts data - all posts from admin
  const posts = [
    {
      id: 1,
      title: 'نصائح مهمة عند شراء منزل جديد',
      excerpt: 'تعرف على أهم النصائح التي يجب مراعاتها عند شراء منزل جديد...',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&auto=format&fit=crop&q=60',
      date: '15 مارس 2024',
      author: {
        name: 'عقاري برو',
        avatar: 'https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png',
        role: 'مدير النظام'
      },
      category: 'عقارات',
      views: 245,
      likes: 56,
      comments: 12
    },
    {
      id: 2,
      title: 'كيف تختار السيارة المناسبة لك',
      excerpt: 'دليلك الشامل لاختيار السيارة التي تناسب احتياجاتك وميزانيتك...',
      image: 'https://images.unsplash.com/photo-1630990325544-58e7ed0d18ea?w=800&auto=format&fit=crop&q=60',
      date: '14 مارس 2024',
      author: {
        name: 'عقاري برو',
        avatar: 'https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png',
        role: 'مدير النظام'
      },
      category: 'سيارات',
      views: 180,
      likes: 34,
      comments: 8
    },
    {
      id: 3,
      title: 'استثمار العقارات في اليمن',
      excerpt: 'تعرف على فرص الاستثمار العقاري في اليمن وأفضل المناطق للاستثمار...',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&auto=format&fit=crop&q=60',
      date: '13 مارس 2024',
      author: {
        name: 'عقاري برو',
        avatar: 'https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png',
        role: 'مدير النظام'
      },
      category: 'استثمار',
      views: 156,
      likes: 42,
      comments: 15
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="المدونة"
        subtitle="آخر الأخبار والمقالات في عالم العقارات والسيارات"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Search and Filters */}
        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-mb-12">
          <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-4">
            {/* Search Input */}
            <div className="tw-col-span-2">
              <div className="tw-relative">
                <Search className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type="text"
                  placeholder="البحث في المقالات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              >
                <option value="all">جميع الأقسام</option>
                <option value="real-estate">عقارات</option>
                <option value="vehicles">سيارات</option>
                <option value="tips">نصائح وإرشادات</option>
                <option value="news">أخبار</option>
              </select>
            </div>
          </div>
        </div>

        {/* Posts Grid */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8">
          {posts.map((post) => (
            <article 
              key={post.id}
              className="tw-group tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/20 tw-transition-all"
            >
              {/* Image */}
              <div className="tw-relative tw-aspect-[16/9] tw-overflow-hidden">
                <img 
                  src={post.image}
                  alt={post.title}
                  className="tw-w-full tw-h-full tw-object-cover"
                />
                <div className="tw-absolute tw-top-4 tw-right-4">
                  <span className={`tw-px-3 tw-py-1 tw-rounded-full tw-text-sm tw-font-medium ${
                    post.category === 'عقارات'
                      ? 'tw-bg-amber-400 tw-text-black'
                      : 'tw-bg-purple-600 tw-text-white'
                  }`}>
                    {post.category}
                  </span>
                </div>
                <button className="tw-absolute tw-top-4 tw-left-4 tw-p-2 tw-bg-black/40 tw-rounded-full hover:tw-bg-amber-400/20">
                  <Heart className="tw-w-5 tw-h-5 tw-text-white" />
                </button>
              </div>

              {/* Content */}
              <div className="tw-p-6">
                {/* Meta */}
                <div className="tw-flex tw-items-center tw-gap-4 tw-mb-4">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm">{post.date}</span>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Eye className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm">{post.views}</span>
                  </div>
                </div>

                {/* Title */}
                <Link to={`/blog/${post.id}`}>
                  <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4 group-hover:tw-text-amber-400 tw-transition-colors">
                    {post.title}
                  </h3>
                </Link>

                {/* Excerpt */}
                <p className="tw-text-gray-400 tw-mb-6">
                  {post.excerpt}
                </p>

                {/* Author and Actions */}
                <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
                  <div className="tw-flex tw-items-center tw-gap-3">
                    <img 
                      src={post.author.avatar}
                      alt={post.author.name}
                      className="tw-w-10 tw-h-10 tw-rounded-full tw-object-contain"
                    />
                    <div>
                      <div className="tw-flex tw-items-center tw-gap-2">
                        <span className="tw-text-white tw-font-medium">{post.author.name}</span>
                        <Crown className="tw-w-4 tw-h-4 tw-text-amber-400" />
                      </div>
                      <div className="tw-text-sm tw-text-gray-400">{post.author.role}</div>
                    </div>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-4">
                    <button className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-white">
                      <MessageCircle className="tw-w-4 tw-h-4" />
                      <span>{post.comments}</span>
                    </button>
                    <button className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 hover:tw-text-white">
                      <Share2 className="tw-w-4 tw-h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Posts;