import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BackButton } from '../common/BackButton';
import { 
  MapPin, Car, Calendar, Gauge, Fuel,
  Phone, Mail, Share2, Shield, User,
  Briefcase, Star, Settings, Check
} from 'lucide-react';

export const VehicleDetails = () => {
  const { id } = useParams();
  const [showContactModal, setShowContactModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const navigate = useNavigate();

  // Mock vehicle data - replace with real data fetch
  const vehicle = {
    id: 1,
    title: 'تويوتا كامري 2023',
    price: '25,000',
    location: 'صنعاء',
    make: 'تويوتا',
    model: 'كامري',
    year: 2023,
    mileage: '15,000',
    fuel: 'بنزين',
    transmission: 'أوتوماتيك',
    features: [
      'تكييف',
      'نظام ABS',
      'وسائد هوائية',
      'بلوتوث',
      'كاميرا خلفية',
      'مثبت سرعة',
      'فتحة سقف',
      'حساسات'
    ],
    description: 'تويوتا كامري 2023 بحالة ممتازة',
    images: [
      'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=60'
    ],
    seller: {
      id: 1,
      name: 'محمد علي',
      username: 'mohammed123',
      accountType: 'business',
      businessName: 'اوتو برو للسيارات',
      businessType: 'معرض سيارات',
      avatar: 'https://i.pravatar.cc/150?img=2',
      rating: 4.8,
      reviews: 106,
      listings: 4,
      verified: true,
      joinDate: '2023-01-15'
    },
    views: 90,
    createdAt: '2024-03-17'
  };

  // If vehicle not found, show error and back button
  if (!vehicle) {
    return (
      <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-flex tw-items-center tw-justify-center">
        <div className="tw-text-center">
          <h1 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-4">السيارة غير موجودة</h1>
          <button
            onClick={() => navigate(-1)}
            className="tw-px-6 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl"
          >
            العودة للخلف
          </button>
        </div>
      </div>
    );
  }

  const ContactModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-w-full tw-max-w-md">
        <h3 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-6">تواصل مع البائع</h3>
        
        <div className="tw-space-y-6">
          {/* Seller Info */}
          <div className="tw-flex tw-items-center tw-gap-4 tw-pb-6 tw-border-b tw-border-neutral-700">
            <img 
              src={vehicle.seller.avatar}
              alt={vehicle.seller.name}
              className="tw-w-16 tw-h-16 tw-rounded-xl tw-object-cover"
            />
            <div>
              <h4 className="tw-text-lg tw-font-bold tw-text-white">{vehicle.seller.name}</h4>
              {vehicle.seller.accountType === 'business' ? (
                <>
                  <p className="tw-text-purple-400">{vehicle.seller.businessName}</p>
                  <p className="tw-text-gray-400 tw-text-sm">{vehicle.seller.businessType}</p>
                </>
              ) : (
                <p className="tw-text-gray-400">حساب شخصي</p>
              )}
            </div>
          </div>

          {/* Contact Form */}
          <form className="tw-space-y-4">
            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                الاسم
              </label>
              <input
                type="text"
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              />
            </div>

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                رقم الهاتف
              </label>
              <input
                type="tel"
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline- none focus:tw-ring-2 focus:tw-ring-purple-400"
              />
            </div>

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              />
            </div>

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                الرسالة
              </label>
              <textarea
                rows={4}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
                defaultValue={`مرحباً، أنا مهتم بالسيارة "${vehicle.title}"`}
              />
            </div>

            <div className="tw-flex tw-justify-end tw-gap-4">
              <button
                type="button"
                onClick={() => setShowContactModal(false)}
                className="tw-px-6 tw-py-3 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-xl"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="tw-px-6 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl"
              >
                إرسال
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  const ShareModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8 tw-w-full tw-max-w-md">
        <h3 className="tw-text-2xl tw-font-bold tw-text-white tw-mb-6">مشاركة السيارة</h3>
        
        <div className="tw-space-y-6">
          {/* Share Link */}
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              رابط المشاركة
            </label>
            <div className="tw-flex tw-gap-2">
              <input
                type="text"
                value={window.location.href}
                readOnly
                className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
              />
              <button className="tw-px-6 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl">
                نسخ
              </button>
            </div>
          </div>

          {/* Social Share */}
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
              مشاركة على
            </label>
            <div className="tw-grid tw-grid-cols-3 tw-gap-4">
              <button className="tw-flex tw-flex-col tw-items-center tw-gap-2 tw-p-4 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-rounded-xl">
                <svg className="tw-w-6 tw-h-6 tw-text-[#1877F2]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span className="tw-text-sm tw-text-gray-300">فيسبوك</span>
              </button>
              <button className="tw-flex tw-flex-col tw-items-center tw-gap-2 tw-p-4 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-rounded-xl">
                <svg className="tw-w-6 tw-h-6 tw-text-[#1DA1F2]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                </svg>
                <span className="tw-text-sm tw-text-gray-300">تويتر</span>
              </button>
              <button className="tw-flex tw-flex-col tw-items-center tw-gap-2 tw-p-4 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-rounded-xl">
                <svg className="tw-w-6 tw-h-6 tw-text-[#25D366]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                <span className="tw-text-sm tw-text-gray-300">واتساب</span>
              </button>
            </div>
          </div>

          <div className="tw-flex tw-justify-end">
            <button
              onClick={() => setShowShareModal(false)}
              className="tw-px-6 tw-py-3 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-xl"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-py-8">
      <BackButton />

      <div className="tw-container tw-mx-auto tw-px-4">
        {/* Main Image */}
        <div className="tw-relative tw-aspect-video tw-rounded-2xl tw-overflow-hidden tw-mb-8">
          <img 
            src={vehicle.images[0]}
            alt={vehicle.title}
            className="tw-w-full tw-h-full tw-object-cover"
          />
        </div>

        {/* Content Grid */}
        <div className="tw-grid tw-grid-cols-1 lg:tw-grid-cols-3 tw-gap-8">
          {/* Main Content */}
          <div className="tw-col-span-2">
            {/* Title Section */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-mb-8">
              <div className="tw-flex tw-items-start tw-justify-between tw-mb-4">
                <div>
                  <h1 className="tw-text-3xl tw-font-bold tw-text-white tw-mb-2">{vehicle.title}</h1>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <MapPin className="tw-w-4 tw-h-4" />
                    <span>{vehicle.location}</span>
                  </div>
                </div>
                <div className="tw-text-3xl tw-font-bold tw-text-purple-400">
                  ${vehicle.price}
                </div>
              </div>

              <div className="tw-flex tw-flex-wrap tw-gap-4">
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                  <Calendar className="tw-w-4 tw-h-4" />
                  <span>{vehicle.year}</span>
                </div>
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                  <Gauge className="tw-w-4 tw-h-4" />
                  <span>{vehicle.mileage} كم</span>
                </div>
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                  <Fuel className="tw-w-4 tw-h-4" />
                  <span>{vehicle.fuel}</span>
                </div>
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                  <Settings className="tw-w-4 tw-h-4" />
                  <span>{vehicle.transmission}</span>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-mb-8">
              <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">الوصف</h2>
              <p className="tw-text-gray-400 tw-leading-relaxed">
                {vehicle.description}
              </p>
            </div>

            {/* Features */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
              <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">المواصفات والميزات</h2>
              <div className="tw-grid tw-grid-cols-2 md:tw-grid-cols-3 tw-gap-4">
                {vehicle.features.map((feature, index) => (
                  <div key={index} className="tw-flex tw-items-center tw-gap-2">
                    <Check className="tw-w-4 tw-h-4 tw-text-purple-400" />
                    <span className="tw-text-gray-400">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="tw-space-y-8">
            {/* Seller Card */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
              {/* Account Type Badge */}
              <div className="tw-flex tw-justify-end tw-mb-4">
                {vehicle.seller.accountType === 'business' ? (
                  <div className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1 tw-bg-purple-400/10 tw-text-purple-400 tw-rounded-full">
                    <Briefcase className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm tw-font-medium">حساب تجاري</span>
                  </div>
                ) : (
                  <div className="tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1 tw-bg-purple-400/10 tw-text-purple-400 tw-rounded-full">
                    <User className="tw-w-4 tw-h-4" />
                    <span className="tw-text-sm tw-font-medium">حساب شخصي</span>
                  </div>
                )}
              </div>

              <div className="tw-flex tw-items-center tw-gap-4 tw-mb-6">
                <img 
                  src={vehicle.seller.avatar}
                  alt={vehicle.seller.name}
                  className="tw-w-16 tw-h-16 tw-rounded-xl tw-object-cover"
                />
                <div>
                  <div className="tw-flex tw-items-center tw-gap-2">
                    <h3 className="tw-text-lg tw-font-bold tw-text-white">{vehicle.seller.name}</h3>
                    {vehicle.seller.verified && (
                      <Shield className="tw-w-4 tw-h-4 tw-text-purple-400" />
                    )}
                  </div>
                  {vehicle.seller.accountType === 'business' && (
                    <>
                      <p className="tw-text-purple-400">{vehicle.seller.businessName}</p>
                      <p className="tw-text-gray-400 tw-text-sm">{vehicle.seller.businessType}</p>
                    </>
                  )}
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-text-sm tw-mt-1">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span>عضو منذ {new Date(vehicle.seller.joinDate).toLocaleDateString('ar-YE')}</span>
                  </div>
                </div>
              </div>

              <div className="tw-grid tw-grid-cols-3 tw-gap-4 tw-mb-6">
                <div className="tw-text-center">
                  <div className="tw-text-2xl tw-font-bold tw-text-white">{vehicle.seller.rating}</div>
                  <div className="tw-text-sm tw-text-gray-400">التقييم</div>
                </div>
                <div className="tw-text-center">
                  <div className="tw-text-2xl tw-font-bold tw-text-white">{vehicle.seller.reviews}</div>
                  <div className="tw-text-sm tw-text-gray-400">التقييمات</div>
                </div>
                <div className="tw-text-center">
                  <div className="tw-text-2xl tw-font-bold tw-text-white">{vehicle.seller.listings}</div>
                  <div className="tw-text-sm tw-text-gray-400">الإعلانات</div>
                </div>
              </div>

              <div className="tw-space-y-4">
                <button
                  onClick={() => setShowContactModal(true)}
                  className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl"
                >
                  <Phone className="tw-w-4 tw-h-4" />
                  <span>اتصل بالبائع</span>
                </button>
                <button
                  onClick={() => setShowShareModal(true)}
                  className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-xl"
                >
                  <Share2 className="tw-w-4 tw-h-4" />
                  <span>مشاركة</span>
                </button>
              </div>
            </div>

            {/* Vehicle Stats */}
            <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
              <div className="tw-space-y-4">
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span>تاريخ النشر</span>
                  </div>
                  <span className="tw-text-white">{vehicle.createdAt}</span>
                </div>
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Star className="tw-w-4 tw-h-4" />
                    <span>المشاهدات</span>
                  </div>
                  <span className="tw-text-white">{vehicle.views}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showContactModal && <ContactModal />}
      {showShareModal && <ShareModal />}
    </div>
  );
};

export default VehicleDetails;