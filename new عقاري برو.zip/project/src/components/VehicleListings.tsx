import React from 'react';
import { SearchSection } from './common/SearchSection';
import { CategoryGrid } from './common/CategoryGrid';
import { vehicleCategories } from '../data/categories';
import { Link } from 'react-router-dom';
import { Car, MapPin, Calendar, Gauge, Fuel, Star, Heart, Search, Plus, Crown } from 'lucide-react';

export const VehicleListings = () => {
  const handleSearch = (filters: any) => {
    console.log('Vehicle search filters:', filters);
  };

  // Featured vehicle by admin
  const featuredVehicle = {
    id: 1,
    title: 'تويوتا كامري 2023',
    location: 'صنعاء',
    price: '25,000',
    year: 2023,
    mileage: '15,000',
    fuel: 'بنزين',
    type: 'سيدان',
    image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=60',
    seller: {
      name: 'عقاري برو',
      avatar: 'https://aqaripro.com/storage/visual-identity-of-aqari-pro-company-31.png',
      role: 'مدير النظام'
    }
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <SearchSection type="vehicle" onSearch={handleSearch} />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Categories Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Car className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">تصفح حسب الفئة</h2>
            </div>
          </div>

          <CategoryGrid 
            type="vehicle"
            categories={vehicleCategories}
          />
        </div>

        {/* Featured Vehicles Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Star className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">السيارات المميزة</h2>
            </div>
          </div>

          {/* Featured Vehicle Card */}
          <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-6">
            <div className="tw-group tw-relative tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50 tw-transition-all">
              {/* Vehicle Image */}
              <div className="tw-relative tw-aspect-[16/9] tw-overflow-hidden">
                <img 
                  src={featuredVehicle.image}
                  alt={featuredVehicle.title}
                  className="tw-w-full tw-h-full tw-object-cover"
                />
                <div className="tw-absolute tw-top-4 tw-right-4">
                  <span className="tw-px-3 tw-py-1 tw-bg-purple-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                    {featuredVehicle.type}
                  </span>
                </div>
                <button className="tw-absolute tw-top-4 tw-left-4 tw-p-2 tw-bg-black/40 tw-rounded-full hover:tw-bg-purple-400/20">
                  <Heart className="tw-w-5 tw-h-5 tw-text-white" />
                </button>
              </div>

              {/* Vehicle Details */}
              <div className="tw-p-6">
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-mb-3">
                  <MapPin className="tw-w-4 tw-h-4" />
                  <span className="tw-text-sm">{featuredVehicle.location}</span>
                </div>

                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4 group-hover:tw-text-purple-400 tw-transition-colors">
                  {featuredVehicle.title}
                </h3>

                <div className="tw-flex tw-items-center tw-gap-6 tw-mb-6">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span>{featuredVehicle.year}</span>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Gauge className="tw-w-4 tw-h-4" />
                    <span>{featuredVehicle.mileage} كم</span>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Fuel className="tw-w-4 tw-h-4" />
                    <span>{featuredVehicle.fuel}</span>
                  </div>
                </div>

                <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
                  <div className="tw-flex tw-items-center tw-gap-3">
                    <img 
                      src={featuredVehicle.seller.avatar}
                      alt={featuredVehicle.seller.name}
                      className="tw-w-10 tw-h-10 tw-rounded-full tw-object-contain"
                    />
                    <div>
                      <div className="tw-flex tw-items-center tw-gap-2">
                        <span className="tw-text-white tw-font-medium">{featuredVehicle.seller.name}</span>
                        <Crown className="tw-w-4 tw-h-4 tw-text-purple-400" />
                      </div>
                      <div className="tw-text-sm tw-text-gray-400">{featuredVehicle.seller.role}</div>
                    </div>
                  </div>
                  <div className="tw-text-xl tw-font-bold tw-text-purple-400">
                    ${featuredVehicle.price}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Vehicle Requests Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Search className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">السيارات المطلوبة</h2>
            </div>
            <div className="tw-flex tw-items-center tw-gap-4">
              <Link 
                to="/vehicle-requests/new"
                className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-lg tw-font-medium tw-transition-colors"
              >
                <Plus className="tw-w-4 tw-h-4" />
                إضافة طلب
              </Link>
              <Link 
                to="/vehicle-requests"
                className="tw-text-purple-400 hover:tw-text-purple-500 tw-transition-colors"
              >
                عرض الكل
              </Link>
            </div>
          </div>
        </div>

        {/* Personal Vehicles Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Car className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">سيارات شخصية</h2>
            </div>
          </div>
        </div>

        {/* Rental Office Vehicles Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Car className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">سيارات مكتب للإيجار</h2>
            </div>
          </div>
        </div>

        {/* Showroom Vehicles Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Car className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">سيارات معارض</h2>
            </div>
          </div>
        </div>

        {/* Commercial Vehicles Section */}
        <div className="tw-mb-16">
          <div className="tw-flex tw-items-center tw-justify-between tw-mb-8">
            <div className="tw-flex tw-items-center tw-gap-3">
              <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
                <Car className="tw-w-6 tw-h-6 tw-text-purple-400" />
              </div>
              <h2 className="tw-text-2xl tw-font-bold tw-text-white">سيارات تجارية</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VehicleListings;