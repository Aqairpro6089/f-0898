import React, { useState } from 'react';
import { PageTitle } from './common/PageTitle';
import { Search, Filter, Plus, MapPin, Calendar, Gauge } from 'lucide-react';
import { Link } from 'react-router-dom';

export const VehicleRequests = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');

  // Mock vehicle requests data
  const vehicleRequests = [
    {
      id: 1,
      title: 'مطلوب سيارة عائلية',
      location: 'صنعاء',
      description: 'أبحث عن سيارة عائلية اقتصادية',
      type: 'سيدان',
      status: 'مميز',
      year: {
        min: 2020,
        max: 2024
      },
      budget: {
        min: 15000,
        max: 25000
      },
      requestType: 'شراء',
      user: {
        name: 'أحمد محمد',
        avatar: 'https://i.pravatar.cc/150?img=1'
      }
    }
  ];

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title="طلبات السيارات"
        subtitle="تصفح طلبات السيارات أو أضف طلبك الخاص"
      />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-16">
        {/* Search and Filters */}
        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-mb-8">
          <div className="tw-flex tw-flex-col md:tw-flex-row tw-gap-4">
            {/* Search Input */}
            <div className="tw-flex-1">
              <div className="tw-relative">
                <Search className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type="text"
                  placeholder="البحث في الطلبات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                />
              </div>
            </div>

            {/* Type Filter */}
            <div className="tw-w-full md:tw-w-48">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
              >
                <option value="all">جميع الأنواع</option>
                <option value="sedan">سيدان</option>
                <option value="suv">SUV</option>
                <option value="coupe">كوبيه</option>
              </select>
            </div>

            {/* Location Filter */}
            <div className="tw-w-full md:tw-w-48">
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
              >
                <option value="all">جميع المناطق</option>
                <option value="sanaa">صنعاء</option>
                <option value="aden">عدن</option>
                <option value="taiz">تعز</option>
              </select>
            </div>

            {/* Add Request Button */}
            <Link
              to="/vehicle-requests/new"
              className="tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl tw-font-medium tw-transition-colors"
            >
              <Plus className="tw-w-4 tw-h-4" />
              <span>إضافة طلب</span>
            </Link>
          </div>
        </div>

        {/* Requests Grid */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-6">
          {vehicleRequests.map((request) => (
            <div 
              key={request.id}
              className="tw-group tw-relative tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50 tw-transition-all"
            >
              <div className="tw-p-6">
                {/* Request Status Tags */}
                <div className="tw-flex tw-gap-2 tw-mb-4">
                  {request.status === 'مميز' && (
                    <span className="tw-px-3 tw-py-1 tw-bg-purple-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                      مميز
                    </span>
                  )}
                  <span className="tw-px-3 tw-py-1 tw-bg-purple-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                    {request.requestType}
                  </span>
                  <span className="tw-px-3 tw-py-1 tw-bg-emerald-600 tw-text-white tw-rounded-full tw-text-sm tw-font-medium">
                    Request
                  </span>
                </div>

                {/* Location */}
                <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-mb-3">
                  <MapPin className="tw-w-4 tw-h-4" />
                  <span className="tw-text-sm">{request.location}</span>
                </div>

                {/* Title */}
                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4 group-hover:tw-text-purple-400 tw-transition-colors">
                  {request.title}
                </h3>

                {/* Description */}
                <p className="tw-text-gray-400 tw-mb-6">
                  {request.description}
                </p>

                {/* Vehicle Details */}
                <div className="tw-flex tw-items-center tw-gap-6 tw-mb-6">
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <Calendar className="tw-w-4 tw-h-4" />
                    <span>{request.year.min} - {request.year.max}</span>
                  </div>
                  <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                    <span className="tw-bg-purple-400/10 tw-px-2 tw-py-1 tw-rounded-lg tw-text-purple-400">
                      {request.type}
                    </span>
                  </div>
                </div>

                {/* User Info and Budget */}
                <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
                  <div className="tw-flex tw-items-center tw-gap-3">
                    <img 
                      src={request.user.avatar} 
                      alt={request.user.name}
                      className="tw-w-10 tw-h-10 tw-rounded-full tw-object-cover"
                    />
                    <div>
                      <div className="tw-text-white tw-font-medium">{request.user.name}</div>
                      <div className="tw-text-sm tw-text-gray-400">صاحب الطلب</div>
                    </div>
                  </div>
                  <div className="tw-text-xl tw-font-bold tw-text-purple-400">
                    ${request.budget.min} - ${request.budget.max}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VehicleRequests;