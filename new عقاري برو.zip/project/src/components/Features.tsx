import React from 'react';
import { useSubscription } from '../context/SubscriptionContext';
import { PricingPlans } from './common/PricingPlans';
import { 
  Building2, Car, Megaphone, LineChart, Users, Facebook,
  CheckCircle, XCircle
} from 'lucide-react';

export const Features = () => {
  const { plans } = useSubscription();
  
  const features = [
    {
      icon: Building2,
      title: 'ترويج العقارات',
      description: 'نشر وترويج العقارات بشكل احترافي',
      color: 'purple'
    },
    {
      icon: Car,
      title: 'ترويج السيارات',
      description: 'عرض وترويج السيارات بكفاءة عالية',
      color: 'purple'
    },
    {
      icon: Megaphone,
      title: 'التسويق الرقمي',
      description: 'حلول تسويقية متكاملة ومبتكرة',
      color: 'purple'
    },
    {
      icon: LineChart,
      title: 'تحليل عقار',
      description: 'تحليل شامل لسوق العقارات',
      color: 'purple'
    },
    {
      icon: Users,
      title: 'إدارة العملاء',
      description: 'نظام متكامل لإدارة العملاء',
      color: 'purple'
    },
    {
      icon: Facebook,
      title: 'التسويق عبر السوشيال ميديا',
      description: 'حضور قوي على منصات التواصل',
      color: 'purple'
    }
  ];

  return (
    <>
      {/* Features Section */}
      <section className="tw-relative tw-py-24 tw-bg-[#0a0a0a]">
        {/* Background Effects */}
        <div className="tw-absolute tw-inset-0">
          {/* Reduced Purple Gradient Overlay */}
          <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-b tw-from-purple-900/10 tw-via-transparent tw-to-black/50" />
          
          {/* Animated Stars - Reduced Opacity */}
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="tw-absolute tw-w-1 tw-h-1 tw-bg-purple-400/20 tw-rounded-full tw-animate-twinkle"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`
              }}
            />
          ))}

          {/* Pattern Overlay */}
          <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        </div>

        <div className="tw-container tw-mx-auto tw-px-4">
          {/* Section Header */}
          <div className="tw-text-center tw-mb-16 tw-relative tw-z-10">
            <h2 className="tw-text-4xl tw-font-bold tw-text-white tw-mb-4">
              ما الذي ستحصل عليه؟
            </h2>
            <p className="tw-text-gray-400 tw-text-lg tw-max-w-3xl tw-mx-auto">
              اكتشف إمكانياتك مع حسابك الشخصي على عقاري برو كل ما تحتاجها للترويج، التسويق، وتحليل عقارك في منصة عقاري برو.
            </p>
          </div>

          {/* Features Grid */}
          <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 lg:tw-grid-cols-3 tw-gap-8 tw-relative tw-z-10">
            {features.map((feature, index) => (
              <div
                key={index}
                className="tw-group tw-relative tw-overflow-hidden tw-rounded-2xl tw-bg-[#1a1a1a] tw-p-8 tw-border tw-border-[#2a2a2a] hover:tw-border-purple-400/50 tw-transition-all tw-duration-300"
              >
                {/* Hover Effect */}
                <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-br tw-from-purple-400/10 tw-via-transparent tw-to-transparent tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
                
                {/* Icon */}
                <div className="tw-relative tw-z-10 tw-w-16 tw-h-16 tw-rounded-xl tw-bg-purple-400/10 tw-flex tw-items-center tw-justify-center tw-mb-6 group-hover:tw-scale-110 tw-transition-transform">
                  <feature.icon className="tw-w-8 tw-h-8 tw-text-purple-400" />
                </div>

                {/* Content */}
                <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-3">
                  {feature.title}
                </h3>
                <p className="tw-text-gray-400">
                  {feature.description}
                </p>

                {/* Animated Border */}
                <div className="tw-absolute tw-inset-0 tw-rounded-2xl tw-border tw-border-transparent group-hover:tw-border-purple-400/20 tw-transition-all tw-duration-300" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="tw-relative tw-py-24 tw-bg-[#0a0a0a]">
        <div className="tw-container tw-mx-auto tw-px-4">
          <PricingPlans plans={plans} />
        </div>
      </section>
    </>
  );
};

export default Features;