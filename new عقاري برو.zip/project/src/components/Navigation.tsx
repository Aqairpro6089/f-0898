import React from 'react';

export const Navigation = () => {
  return (
    <nav className="bg-black text-white">
      <ul className="flex justify-center space-x-6 py-4">
        <li><a href="#home" className="text-white hover:text-[#ffd966] transition-colors">Home</a></li>
        <li><a href="#about" className="text-white hover:text-[#ffd966] transition-colors">About Us</a></li>
        <li><a href="#services" className="text-white hover:text-[#ffd966] transition-colors">Our Services</a></li>
        <li><a href="#pricing" className="text-white hover:text-[#ffd966] transition-colors">Pricing Plans</a></li>
        <li><a href="#properties" className="text-white hover:text-[#ffd966] transition-colors">Properties</a></li>
        <li><a href="#contact" className="text-white hover:text-[#ffd966] transition-colors">Contact Us</a></li>
        <li><a href="#cookie-policy" className="text-white hover:text-[#ffd966] transition-colors">Cookie Policy</a></li>
      </ul>
    </nav>
  );
};