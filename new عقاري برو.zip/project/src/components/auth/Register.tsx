import React, { useState } from 'react';
import { useSubscription } from '../../context/SubscriptionContext';
import { PricingPlans } from '../common/PricingPlans';
import { PageTitle } from '../common/PageTitle';
import { useNavigate } from 'react-router-dom';
import { 
  User, Mail, Phone, Lock, Eye, EyeOff, Briefcase, AtSign, Flag, 
  CreditCard, Wallet, Building2, ArrowLeft 
} from 'lucide-react';

export const Register = () => {
  const { plans } = useSubscription();
  const [accountType, setAccountType] = useState<'personal' | 'business'>('personal');
  const [formData, setFormData] = useState({
    fullName: '',
    username: '',
    email: '',
    phone: '',
    password: '',
    country: 'ye',
    selectedPlan: 'free',
    // Business fields
    businessName: '',
    businessType: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');

  const navigate = useNavigate();

  // Business types based on language
  const businessTypes = {
    ar: [
      'مكاتب عقارات',
      'مكاتب سيارات',
      'مكاتب شاليهات',
      'مكاتب منتجعات',
      'مكاتب فنادق',
      'مكاتب فنادق سياحية',
      'مكاتب تأجير سيارات',
      'مكاتب لبيع السيارات',
      'مكاتب معرض سيارات'
    ],
    en: [
      'Real Estate Offices',
      'Car Offices',
      'Chalet Offices',
      'Resort Offices',
      'Hotel Offices',
      'Tourist Hotel Offices',
      'Car Rental Offices',
      'Car Sales Offices',
      'Car Showroom Offices'
    ]
  };

  const countries = [
    { code: 'ye', name: 'اليمن', flag: '🇾🇪', phoneCode: '+967' },
    { code: 'us', name: 'الولايات المتحدة', flag: '🇺🇸', phoneCode: '+1' }
  ];

  const paymentMethods = {
    ye: [
      { id: 'kuraimi', name: 'بنك الكريمي', icon: Wallet },
      { id: 'jawali', name: 'جوالي', icon: Wallet },
      { id: 'cash', name: 'الدفع نقداً', icon: Wallet }
    ],
    us: [
      { id: 'paypal', name: 'PayPal', icon: Wallet },
      { id: 'card', name: 'Credit/Debit Card', icon: CreditCard }
    ]
  };

  const PaymentModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6 tw-w-full tw-max-w-md">
        <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-6">اختر طريقة الدفع</h3>
        
        <div className="tw-space-y-4">
          {paymentMethods[formData.country].map((method) => (
            <button
              key={method.id}
              onClick={() => setSelectedPaymentMethod(method.id)}
              className={`tw-w-full tw-flex tw-items-center tw-gap-3 tw-p-4 tw-rounded-lg tw-transition-all ${
                selectedPaymentMethod === method.id
                  ? 'tw-bg-purple-600 tw-text-white'
                  : 'tw-bg-neutral-700 tw-text-gray-300 hover:tw-bg-neutral-600'
              }`}
            >
              <method.icon className="tw-w-5 tw-h-5" />
              <span>{method.name}</span>
            </button>
          ))}
        </div>

        <div className="tw-mt-6 tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowPaymentModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={() => {
              // Handle payment processing
              console.log('Processing payment with:', selectedPaymentMethod);
              setShowPaymentModal(false);
            }}
            disabled={!selectedPaymentMethod}
            className={`tw-px-4 tw-py-2 tw-rounded-lg ${
              selectedPaymentMethod
                ? 'tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white'
                : 'tw-bg-neutral-700 tw-text-gray-400 tw-cursor-not-allowed'
            }`}
          >
            متابعة الدفع
          </button>
        </div>
      </div>
    </div>
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (formData.selectedPlan !== 'free') {
      setShowPaymentModal(true);
    } else {
      // Process free plan registration
      console.log('Creating free account:', formData);
      navigate('/');
    }
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-py-16 tw-px-4">
      <div className="tw-max-w-2xl tw-mx-auto">
        <PageTitle 
          title="إنشاء حساب جديد"
          subtitle="انضم إلينا وابدأ في عرض عقاراتك وسياراتك"
        />

        {/* Account Type Selection */}
        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-2 tw-mb-8">
          <div className="tw-flex tw-gap-4">
            <button
              onClick={() => setAccountType('personal')}
              className={`tw-flex-1 tw-flex tw-flex-col tw-items-center tw-gap-3 tw-p-6 tw-rounded-xl tw-transition-all ${
                accountType === 'personal'
                  ? 'tw-bg-purple-600 tw-text-white'
                  : 'tw-bg-neutral-800 tw-text-gray-400 hover:tw-bg-neutral-700'
              }`}
            >
              <User className="tw-w-8 tw-h-8" />
              <span className="tw-font-medium">حساب شخصي</span>
              <span className="tw-text-sm tw-text-center tw-opacity-80">
                للأفراد والإعلانات المحدودة
              </span>
            </button>
            <button
              onClick={() => setAccountType('business')}
              className={`tw-flex-1 tw-flex tw-flex-col tw-items-center tw-gap-3 tw-p-6 tw-rounded-xl tw-transition-all ${
                accountType === 'business'
                  ? 'tw-bg-purple-600 tw-text-white'
                  : 'tw-bg-neutral-800 tw-text-gray-400 hover:tw-bg-neutral-700'
              }`}
            >
              <Briefcase className="tw-w-8 tw-h-8" />
              <span className="tw-font-medium">حساب تجاري</span>
              <span className="tw-text-sm tw-text-center tw-opacity-80">
                للشركات والمكاتب العقارية
              </span>
            </button>
          </div>
        </div>

        {/* Registration Form */}
        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-8">
          <form onSubmit={handleSubmit} className="tw-space-y-6">
            {error && (
              <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-text-center">
                {error}
              </div>
            )}

            {/* Full Name */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                الاسم الكامل
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <User className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                  placeholder="الاسم كما في الوثائق الرسمية"
                  required
                />
              </div>
            </div>

            {/* Business Fields - Only show for business accounts */}
            {accountType === 'business' && (
              <>
                {/* Business Name */}
                <div>
                  <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                    اسم الشركة/المؤسسة
                    <span className="tw-text-amber-400">*</span>
                  </label>
                  <div className="tw-relative">
                    <Briefcase className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                    <input
                      type="text"
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                      placeholder="أدخل اسم الشركة/المؤسسة"
                      required
                    />
                  </div>
                </div>

                {/* Business Type */}
                <div>
                  <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                    نوع النشاط التجاري
                    <span className="tw-text-amber-400">*</span>
                  </label>
                  <div className="tw-relative">
                    <Building2 className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                    <select
                      value={formData.businessType}
                      onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                      className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500 tw-appearance-none"
                      required
                    >
                      <option value="">اختر نوع النشاط</option>
                      {businessTypes.ar.map((type, index) => (
                        <option key={index} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                    <div className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-pointer-events-none">
                      <svg className="tw-w-4 tw-h-4 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                  <p className="tw-mt-1 tw-text-sm tw-text-gray-400">
                    اختر نوع النشاط الذي يناسب عملك
                  </p>
                </div>
              </>
            )}

            {/* Username */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                اسم المستخدم
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <AtSign className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                  placeholder="اختر اسم مستخدم فريد"
                  required
                  pattern="[a-zA-Z0-9_]{3,20}"
                />
              </div>
              <p className="tw-mt-1 tw-text-sm tw-text-gray-400">
                يمكن استخدام الأحرف الإنجليزية والأرقام والشرطة السفلية (_)
              </p>
            </div>

            {/* Email */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                البريد الإلكتروني
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <Mail className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                  placeholder="بريدك الإلكتروني"
                  required
                />
              </div>
            </div>

            {/* Country Selection */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                الدولة
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <Flag className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <select
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500 tw-appearance-none"
                  required
                >
                  {countries.map((country) => (
                    <option key={country.code} value={country.code}>
                      {country.flag} {country.name}
                    </option>
                  ))}
                </select>
                <div className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-pointer-events-none">
                  <svg className="tw-w-4 tw-h-4 tw-text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Phone */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                رقم الهاتف
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <Phone className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <div className="tw-absolute tw-right-12 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 tw-pointer-events-none">
                  {countries.find(c => c.code === formData.country)?.phoneCode}
                </div>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-24 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                  placeholder="xxx xxx xxx"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-2">
                كلمة المرور
                <span className="tw-text-amber-400">*</span>
              </label>
              <div className="tw-relative">
                <Lock className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-pr-12 tw-pl-12 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500"
                  placeholder="8 أحرف على الأقل"
                  required
                  minLength={8}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 hover:tw-text-white tw-transition-colors focus:tw-outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="tw-w-5 tw-h-5" />
                  ) : (
                    <Eye className="tw-w-5 tw-h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Subscription Plans */}
            <div className="tw-mb-6">
              <label className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-mb-4">
                اختر باقة الاشتراك
                <span className="tw-text-amber-400">*</span>
              </label>
              <PricingPlans 
                plans={plans}
                selectedPlan={formData.selectedPlan}
                onSelectPlan={(planId) => setFormData({ ...formData, selectedPlan: planId })}
                showTitle={false}
                compact={true}
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="tw-w-full tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-font-medium tw-py-3 tw-px-4 tw-rounded-xl tw-transition-all tw-duration-300"
            >
              إنشاء الحساب
            </button>

            {/* Login Link */}
            <div className="tw-text-center tw-text-gray-400">
              لديك حساب بالفعل؟{' '}
              <a 
                href="/login" 
                className="tw-text-purple-400 hover:tw-text-purple-300 tw-font-medium"
              >
                تسجيل الدخول
              </a>
            </div>
          </form>
        </div>
      </div>

      {/* Add Payment Modal */}
      {showPaymentModal && <PaymentModal />}
    </div>
  );
};

export default Register;