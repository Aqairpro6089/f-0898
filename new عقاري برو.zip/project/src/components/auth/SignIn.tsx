import React, { useState } from 'react';
import { PageTitle } from '../common/PageTitle';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { User, Lock, Eye, EyeOff, ArrowLeft, Briefcase } from 'lucide-react';

export const SignIn = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [accountType, setAccountType] = useState<'personal' | 'business'>('personal');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      const success = await login(username, password);
      if (success) {
        navigate('/profile');
      } else {
        setError('بيانات الاعتماد غير صالحة');
      }
    } catch (err) {
      setError('حدث خطأ أثناء تسجيل الدخول');
    }
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-flex tw-flex-col tw-items-center tw-justify-center tw-px-4">
      <div className="tw-absolute tw-inset-0">
        <div className="tw-absolute tw-inset-0 tw-bg-[url('https://aqaripro.com/images/pattern-1.png')] tw-opacity-[0.02]" />
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="tw-absolute tw-w-1 tw-h-1 tw-bg-white/10 tw-rounded-full tw-animate-twinkle"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      <button
        onClick={() => navigate(-1)}
        className="tw-group tw-fixed tw-left-8 tw-top-8 tw-z-50 tw-flex tw-items-center tw-gap-2 tw-bg-[#1a1a1a]/80 tw-backdrop-blur-sm hover:tw-bg-purple-600/20 tw-px-4 tw-py-3 tw-rounded-xl tw-transition-all tw-duration-300"
      >
        <ArrowLeft className="tw-w-5 tw-h-5 tw-text-purple-400 group-hover:tw-text-purple-300" />
        <span className="tw-text-white tw-font-medium">رجوع</span>
      </button>

      <div className="tw-w-full tw-max-w-md tw-relative">
        <PageTitle 
          title="تسجيل الدخول"
          subtitle="مرحباً بك مجدداً! قم بتسجيل الدخول للمتابعة"
        />

        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-2 tw-mb-6 tw-flex tw-gap-2">
          <button
            onClick={() => setAccountType('personal')}
            className={`tw-flex tw-items-center tw-justify-center tw-gap-3 tw-flex-1 tw-px-6 tw-py-3 tw-rounded-xl tw-transition-all tw-duration-300 ${
              accountType === 'personal'
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-bg-neutral-800/50 tw-text-gray-400 hover:tw-text-white hover:tw-bg-neutral-700/50'
            }`}
          >
            <User className="tw-w-5 tw-h-5" />
            <span>حساب شخصي</span>
          </button>
          <button
            onClick={() => setAccountType('business')}
            className={`tw-flex tw-items-center tw-justify-center tw-gap-3 tw-flex-1 tw-px-6 tw-py-3 tw-rounded-xl tw-transition-all tw-duration-300 ${
              accountType === 'business'
                ? 'tw-bg-purple-600 tw-text-white'
                : 'tw-bg-neutral-800/50 tw-text-gray-400 hover:tw-text-white hover:tw-bg-neutral-700/50'
            }`}
          >
            <Briefcase className="tw-w-5 tw-h-5" />
            <span>حساب تجاري</span>
          </button>
        </div>

        <div className="tw-relative">
          <div className="tw-absolute tw-inset-0 tw-bg-gradient-to-r tw-from-amber-400/20 tw-via-purple-600/20 tw-to-amber-400/20 tw-rounded-2xl tw-animate-pulse tw-blur" />
          <div className="tw-absolute tw-inset-0 tw-bg-[#0f0f0f] tw-rounded-2xl tw-m-[1px]" />
          
          <div className="tw-relative tw-bg-[#0f0f0f]/90 tw-backdrop-blur-xl tw-rounded-2xl tw-p-8 tw-shadow-2xl">
            <form onSubmit={handleSubmit} className="tw-space-y-6">
              <div className="tw-space-y-4">
                <div>
                  <label htmlFor="username" className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-text-right tw-mb-2">
                    اسم المستخدم
                  </label>
                  <div className="tw-relative tw-group">
                    <User className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400 group-focus-within:tw-text-purple-500 tw-transition-colors" />
                    <input
                      type="text"
                      id="username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="tw-w-full tw-bg-[#1a1a1a] tw-border tw-border-[#2a2a2a] tw-rounded-xl tw-pr-12 tw-pl-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500 tw-transition-all"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="tw-block tw-text-lg tw-font-medium tw-text-gray-300 tw-text-right tw-mb-2">
                    كلمة المرور
                  </label>
                  <div className="tw-relative tw-group">
                    <Lock className="tw-absolute tw-right-4 tw-top-1/2 -tw-translate-y-1/2 tw-w-5 tw-h-5 tw-text-gray-400 group-focus-within:tw-text-purple-500 tw-transition-colors" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="tw-w-full tw-bg-[#1a1a1a] tw-border tw-border-[#2a2a2a] tw-rounded-xl tw-pr-12 tw-pl-12 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-500 tw-transition-all"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400 hover:tw-text-white tw-transition-colors focus:tw-outline-none"
                    >
                      {showPassword ? (
                        <EyeOff className="tw-w-5 tw-h-5" />
                      ) : (
                        <Eye className="tw-w-5 tw-h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="tw-flex tw-items-center tw-justify-between">
                  <div className="tw-flex tw-items-center">
                    <input
                      type="checkbox"
                      id="remember"
                      className="tw-rounded tw-bg-[#1a1a1a] tw-border-[#2a2a2a] tw-text-purple-500 focus:tw-ring-purple-500"
                    />
                    <label htmlFor="remember" className="tw-mr-2 tw-text-sm tw-text-gray-400">
                      تذكرني
                    </label>
                  </div>
                  <a href="#" className="tw-text-sm tw-text-purple-400 hover:tw-text-purple-300">
                    نسيت كلمة المرور؟
                  </a>
                </div>
              </div>

              {error && (
                <div className="tw-text-red-500 tw-text-right tw-text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={`tw-w-full tw-font-medium tw-py-3 tw-px-4 tw-rounded-xl tw-transition-all tw-duration-300 tw-relative tw-overflow-hidden tw-group ${
                  accountType === 'personal'
                    ? 'tw-bg-gradient-to-r tw-from-amber-400 tw-to-amber-500 hover:tw-from-amber-500 hover:tw-to-amber-600 tw-text-black'
                    : 'tw-bg-gradient-to-r tw-from-purple-600 tw-to-purple-700 hover:tw-from-purple-700 hover:tw-to-purple-800 tw-text-white'
                }`}
              >
                <div className="tw-absolute tw-inset-0 tw-bg-white/10 tw-opacity-0 group-hover:tw-opacity-100 tw-transition-opacity" />
                <span className="tw-relative tw-z-10">تسجيل الدخول</span>
              </button>

              <div className="tw-text-center tw-text-gray-400">
                ليس لديك حساب؟{' '}
                <a 
                  href="/register" 
                  className="tw-text-purple-400 hover:tw-text-purple-300 tw-font-medium"
                >
                  إنشاء حساب جديد
                </a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;