import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { useNavigate, useParams } from 'react-router-dom';
import { BackButton } from '../common/BackButton';

export const EditVehicle = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-py-8">
      <div className="tw-container tw-mx-auto tw-px-4">
        <PageTitle 
          title="تعديل السيارة"
          subtitle="قم بتحديث معلومات سيارتك"
        />
        {/* Edit vehicle form will go here */}
      </div>
    </div>
  );
};

export default EditVehicle;