import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { useNavigate } from 'react-router-dom';
import { BackButton } from '../common/BackButton';
import { Bell } from 'lucide-react';

export const Notifications = () => {
  const navigate = useNavigate();

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-py-8">
      <div className="tw-container tw-mx-auto tw-px-4">
        <PageTitle 
          title="الإشعارات"
          subtitle="تابع آخر التحديثات والإشعارات"
        />
        {/* Notifications list will go here */}
      </div>
    </div>
  );
};

export default Notifications;