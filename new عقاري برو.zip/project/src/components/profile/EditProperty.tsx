import React from 'react';
import { PageTitle } from '../common/PageTitle';
import { useNavigate, useParams } from 'react-router-dom';
import { BackButton } from '../common/BackButton';

export const EditProperty = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a] tw-py-8">
      <div className="tw-container tw-mx-auto tw-px-4">
        <BackButton />
        <PageTitle 
          title="تعديل العقار"
          subtitle="قم بتحديث معلومات عقارك"
        />
        {/* Edit property form will go here */}
      </div>
    </div>
  );
};

export default EditProperty;