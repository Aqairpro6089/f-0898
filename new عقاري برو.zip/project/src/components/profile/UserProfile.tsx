import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { PageTitle } from '../common/PageTitle';
import { HomeButton } from '../common/HomeButton';
import { 
  Building2, Car, User, Settings, Bell, FileText,
  Plus, Edit2, Trash2, Eye, Share2, Heart,
  MessageCircle, BarChart2, Upload, MapPin,
  Phone, Mail, Globe, Facebook, Instagram,
  Calendar, Clock, DollarSign, Users, Shield,
  Briefcase, AtSign, ChevronRight, Filter,
  LayoutGrid, List, ArrowUpRight, Gauge, Fuel,
  Bed, Bath, Square, Crown
} from 'lucide-react';

// Import components
import { AccountSettings } from './sections/AccountSettings';
import { CreateProperty } from './sections/CreateProperty';
import { CreateVehicle } from './sections/CreateVehicle';
import { RequestProperty } from './sections/RequestProperty';
import { RequestVehicle } from './sections/RequestVehicle';
import { BusinessBranding } from './sections/BusinessBranding';
import { MyListings } from './sections/MyListings';
import { MyRequests } from './sections/MyRequests';
import { MyFavorites } from './sections/MyFavorites';
import { MyStats } from './sections/MyStats';

export const UserProfile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('listings');
  const [activeSection, setActiveSection] = useState<string>('listings');

  // Business-specific sections
  const businessSections = [
    { id: 'branding', label: 'الهوية التجارية', icon: Crown },
    { id: 'stats', label: 'الإحصائيات', icon: BarChart2 },
  ];

  // Common sections for both account types
  const commonSections = [
    { id: 'listings', label: 'إعلاناتي', icon: Building2 },
    { id: 'requests', label: 'طلباتي', icon: FileText },
    { id: 'favorites', label: 'المفضلة', icon: Heart },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  // Quick actions based on account type
  const quickActions = [
    { 
      id: 'create-property',
      label: 'إضافة عقار',
      icon: Building2,
      color: 'amber',
      onClick: () => setActiveSection('create-property')
    },
    { 
      id: 'create-vehicle',
      label: 'إضافة سيارة',
      icon: Car,
      color: 'purple',
      onClick: () => setActiveSection('create-vehicle')
    },
    { 
      id: 'request-property',
      label: 'طلب عقار',
      icon: FileText,
      color: 'amber',
      onClick: () => setActiveSection('request-property')
    },
    { 
      id: 'request-vehicle',
      label: 'طلب سيارة',
      icon: FileText,
      color: 'purple',
      onClick: () => setActiveSection('request-vehicle')
    }
  ];

  // Render section content based on active section
  const renderSectionContent = () => {
    switch (activeSection) {
      case 'branding':
        return <BusinessBranding />;
      case 'stats':
        return <MyStats />;
      case 'listings':
        return <MyListings />;
      case 'requests':
        return <MyRequests />;
      case 'favorites':
        return <MyFavorites />;
      case 'settings':
        return <AccountSettings />;
      case 'create-property':
        return <CreateProperty />;
      case 'create-vehicle':
        return <CreateVehicle />;
      case 'request-property':
        return <RequestProperty />;
      case 'request-vehicle':
        return <RequestVehicle />;
      default:
        return <MyListings />;
    }
  };

  return (
    <div className="tw-min-h-screen tw-bg-[#0a0a0a]">
      <PageTitle 
        title={user?.accountType === 'business' ? 'الحساب التجاري' : 'الحساب الشخصي'}
        subtitle="إدارة حسابك وإعلاناتك"
      />
      <HomeButton />

      <div className="tw-container tw-mx-auto tw-px-4 tw-py-8">
        {/* Profile Header */}
        <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-mb-8">
          <div className="tw-flex tw-flex-col md:tw-flex-row tw-items-start tw-gap-8">
            {/* User Info */}
            <div className="tw-flex-1">
              <div className="tw-flex tw-items-center tw-gap-4 tw-mb-4">
                <div className="tw-w-20 tw-h-20 tw-bg-neutral-800 tw-rounded-xl tw-flex tw-items-center tw-justify-center">
                  {user?.accountType === 'business' ? (
                    <Briefcase className="tw-w-10 tw-h-10 tw-text-amber-400" />
                  ) : (
                    <User className="tw-w-10 tw-h-10 tw-text-purple-400" />
                  )}
                </div>
                <div>
                  <h1 className="tw-text-2xl tw-font-bold tw-text-white">
                    {user?.accountType === 'business' ? user?.businessName : user?.fullName}
                  </h1>
                  <p className="tw-text-gray-400">
                    {user?.accountType === 'business' ? user?.businessType : 'حساب شخصي'}
                  </p>
                  <p className="tw-text-sm tw-text-gray-500">@{user?.username}</p>
                </div>
              </div>

              <div className="tw-grid tw-grid-cols-2 md:tw-grid-cols-4 tw-gap-4">
                <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4">
                  <div className="tw-text-2xl tw-font-bold tw-text-amber-400">
                    {user?.stats?.listings || 0}
                  </div>
                  <div className="tw-text-sm tw-text-gray-400">إعلان</div>
                </div>
                <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4">
                  <div className="tw-text-2xl tw-font-bold tw-text-purple-400">
                    {user?.stats?.views || 0}
                  </div>
                  <div className="tw-text-sm tw-text-gray-400">مشاهدة</div>
                </div>
                <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4">
                  <div className="tw-text-2xl tw-font-bold tw-text-emerald-400">
                    {user?.stats?.leads || 0}
                  </div>
                  <div className="tw-text-sm tw-text-gray-400">تواصل</div>
                </div>
                <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-4">
                  <div className="tw-text-2xl tw-font-bold tw-text-amber-400">
                    {user?.stats?.rating || 0}
                  </div>
                  <div className="tw-text-sm tw-text-gray-400">تقييم</div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="tw-flex tw-flex-wrap tw-gap-4">
              {quickActions.map((action) => (
                <button
                  key={action.id}
                  onClick={action.onClick}
                  className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-${action.color}-400/10 hover:tw-bg-${action.color}-400/20 tw-text-${action.color}-400 tw-rounded-lg tw-font-medium tw-transition-colors`}
                >
                  <action.icon className="tw-w-4 tw-h-4" />
                  <span>{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="tw-grid tw-grid-cols-1 lg:tw-grid-cols-4 tw-gap-8">
          {/* Sidebar */}
          <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-4">
            <nav className="tw-space-y-2">
              {/* Business-specific sections */}
              {user?.accountType === 'business' && (
                <>
                  {businessSections.map((section) => (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`tw-w-full tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-rounded-xl tw-transition-colors ${
                        activeSection === section.id
                          ? 'tw-bg-amber-400/10 tw-text-amber-400'
                          : 'tw-text-gray-400 hover:tw-text-white hover:tw-bg-neutral-800'
                      }`}
                    >
                      <section.icon className="tw-w-5 tw-h-5" />
                      <span>{section.label}</span>
                    </button>
                  ))}
                  <hr className="tw-border-neutral-800" />
                </>
              )}

              {/* Common sections */}
              {commonSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`tw-w-full tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-3 tw-rounded-xl tw-transition-colors ${
                    activeSection === section.id
                      ? 'tw-bg-amber-400/10 tw-text-amber-400'
                      : 'tw-text-gray-400 hover:tw-text-white hover:tw-bg-neutral-800'
                  }`}
                >
                  <section.icon className="tw-w-5 tw-h-5" />
                  <span>{section.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Content Area */}
          <div className="lg:tw-col-span-3">
            {renderSectionContent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;