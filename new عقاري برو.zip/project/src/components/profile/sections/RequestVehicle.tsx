import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { requestsApi } from '../../../lib/api';
import { 
  MapPin, Car, Calendar, DollarSign,
  Search
} from 'lucide-react';

export const RequestVehicle = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    make: '',
    model: '',
    minYear: '',
    maxYear: '',
    minPrice: '',
    maxPrice: '',
    location: ''
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const carMakes = [
    'تويوتا',
    'هوندا',
    'نيسان',
    'مرسيدس',
    'بي إم دبليو',
    'لكزس',
    'هيونداي'
  ];

  const locations = [
    'صنعاء',
    'عدن',
    'تعز',
    'الحديدة',
    'إب',
    'ذمار'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await requestsApi.createVehicleRequest({
        ...formData,
        minPrice: formData.minPrice ? parseFloat(formData.minPrice) : undefined,
        maxPrice: formData.maxPrice ? parseFloat(formData.maxPrice) : undefined,
        minYear: formData.minYear ? parseInt(formData.minYear) : undefined,
        maxYear: formData.maxYear ? parseInt(formData.maxYear) : undefined
      });

      if (error) throw error;

      setSuccess(true);
      setFormData({
        title: '',
        description: '',
        make: '',
        model: '',
        minYear: '',
        maxYear: '',
        minPrice: '',
        maxPrice: '',
        location: ''
      });

      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إضافة الطلب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
        <div className="tw-p-2 tw-bg-purple-600/10 tw-rounded-lg">
          <Search className="tw-w-6 tw-h-6 tw-text-purple-400" />
        </div>
        <div>
          <h2 className="tw-text-xl tw-font-bold tw-text-white">طلب سيارة</h2>
          <p className="tw-text-gray-400">أضف طلبك للسيارة المطلوبة</p>
        </div>
      </div>

      {success && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم إضافة الطلب بنجاح
        </div>
      )}

      {error && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-mb-6">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="tw-space-y-6">
        {/* Basic Information */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              عنوان الطلب
              <span className="tw-text-purple-400">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              placeholder="مثال: مطلوب سيارة عائلية"
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموقع
              <span className="tw-text-purple-400">*</span>
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              required
            >
              <option value="">اختر الموقع</option>
              {locations.map((location) => (
                <option key={location} value={location}>{location}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الماركة
            </label>
            <select
              value={formData.make}
              onChange={(e) => setFormData({ ...formData, make: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            >
              <option value="">اختر الماركة</option>
              {carMakes.map((make) => (
                <option key={make} value={make}>{make}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموديل
            </label>
            <input
              type="text"
              value={formData.model}
              onChange={(e) => setFormData({ ...formData, model: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              placeholder="مثال: كامري"
            />
          </div>
        </div>

        {/* Year Range */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              سنة الصنع من
            </label>
            <select
              value={formData.minYear}
              onChange={(e) => setFormData({ ...formData, minYear: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            >
              <option value="">اختر السنة</option>
              {Array.from({ length: 30 }, (_, i) => new Date().getFullYear() - i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              سنة الصنع إلى
            </label>
            <select
              value={formData.maxYear}
              onChange={(e) => setFormData({ ...formData, maxYear: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            >
              <option value="">اختر السنة</option>
              {Array.from({ length: 30 }, (_, i) => new Date().getFullYear() - i).map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Price Range */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر من
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.minPrice}
                onChange={(e) => setFormData({ ...formData, minPrice: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر إلى
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.maxPrice}
                onChange={(e) => setFormData({ ...formData, maxPrice: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            تفاصيل إضافية
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            rows={6}
            placeholder="اكتب أي متطلبات أو تفاصيل إضافية..."
          />
        </div>

        {/* Submit Button */}
        <div className="tw-flex tw-justify-end">
          <button
            type="submit"
            disabled={loading}
            className="tw-px-8 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl tw-font-medium tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
          >
            {loading ? 'جاري الإضافة...' : 'إضافة الطلب'}
          </button>
        </div>
      </form>
    </div>
  );
};