import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { propertiesApi } from '../../../lib/api';
import { 
  MapPin, Building2, Square, Bed, Bath,
  Upload, Plus, X, DollarSign
} from 'lucide-react';

export const CreateProperty = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: '',
    price: '',
    location: '',
    area: '',
    bedrooms: '',
    bathrooms: '',
    features: [''],
    images: []
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const propertyTypes = [
    'شقة',
    'فيلا',
    'عمارة',
    'أرض',
    'محل تجاري',
    'مكتب',
    'مستودع'
  ];

  const locations = [
    'صنعاء',
    'عدن',
    'تعز',
    'الحديدة',
    'إب',
    'ذمار'
  ];

  const handleFeatureAdd = () => {
    setFormData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };

  const handleFeatureRemove = (index: number) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const handleFeatureChange = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.map((feature, i) => 
        i === index ? value : feature
      )
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await propertiesApi.create({
        ...formData,
        price: parseFloat(formData.price),
        area: parseFloat(formData.area),
        bedrooms: parseInt(formData.bedrooms),
        bathrooms: parseInt(formData.bathrooms),
      });

      if (error) throw error;

      setSuccess(true);
      setFormData({
        title: '',
        description: '',
        type: '',
        price: '',
        location: '',
        area: '',
        bedrooms: '',
        bathrooms: '',
        features: [''],
        images: []
      });

      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إضافة العقار');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-6">إضافة عقار جديد</h2>

      {success && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم إضافة العقار بنجاح
        </div>
      )}

      {error && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-mb-6">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="tw-space-y-6">
        {/* Basic Information */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              عنوان العقار
              <span className="tw-text-amber-400">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              نوع العقار
              <span className="tw-text-amber-400">*</span>
            </label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              required
            >
              <option value="">اختر نوع العقار</option>
              {propertyTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر
              <span className="tw-text-amber-400">*</span>
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                required
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموقع
              <span className="tw-text-amber-400">*</span>
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              required
            >
              <option value="">اختر الموقع</option>
              {locations.map((location) => (
                <option key={location} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Property Details */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              المساحة (م²)
            </label>
            <input
              type="number"
              value={formData.area}
              onChange={(e) => setFormData({ ...formData, area: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              غرف النوم
            </label>
            <input
              type="number"
              value={formData.bedrooms}
              onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الحمامات
            </label>
            <input
              type="number"
              value={formData.bathrooms}
              onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            الوصف
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            rows={6}
            required
          />
        </div>

        {/* Features */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
            المميزات
          </label>
          <div className="tw-space-y-4">
            {formData.features.map((feature, index) => (
              <div key={index} className="tw-flex tw-gap-2">
                <input
                  type="text"
                  value={feature}
                  onChange={(e) => handleFeatureChange(index, e.target.value)}
                  className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  placeholder="أضف ميزة"
                />
                <button
                  type="button"
                  onClick={() => handleFeatureRemove(index)}
                  className="tw-p-3 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-xl"
                >
                  <X className="tw-w-5 tw-h-5" />
                </button>
              </div>
            ))}
            
            <button
              type="button"
              onClick={handleFeatureAdd}
              className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-4 tw-py-3 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-xl"
            >
              <Plus className="tw-w-4 tw-h-4" />
              <span>إضافة ميزة</span>
            </button>
          </div>
        </div>

        {/* Images */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
            الصور
          </label>
          <div className="tw-border-2 tw-border-dashed tw-border-neutral-700 tw-rounded-xl tw-p-8">
            <div className="tw-flex tw-flex-col tw-items-center tw-justify-center tw-text-center">
              <Upload className="tw-w-12 tw-h-12 tw-text-gray-400 tw-mb-4" />
              <p className="tw-text-gray-300 tw-mb-2">اسحب وأفلت الصور هنا</p>
              <p className="tw-text-gray-400 tw-text-sm">أو</p>
              <button
                type="button"
                className="tw-mt-4 tw-px-6 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg"
              >
                اختر الصور
              </button>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="tw-flex tw-justify-end">
          <button
            type="submit"
            disabled={loading}
            className="tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
          >
            {loading ? 'جاري الإضافة...' : 'إضافة العقار'}
          </button>
        </div>
      </form>
    </div>
  );
};