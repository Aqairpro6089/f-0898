import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { 
  Building2, Car, MapPin, Calendar, DollarSign,
  Edit2, Trash2, Eye, Share2, Heart,
  LayoutGrid, List, Filter, MessageCircle, AlertTriangle
} from 'lucide-react';

export const MyRequests = () => {
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [requestType, setRequestType] = useState<'properties' | 'vehicles'>('properties');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<any>(null);

  // Mock requests data
  const requests = {
    properties: [
      {
        id: 1,
        title: 'مطلوب شقة عائلية',
        location: 'صنعاء',
        type: 'شقة',
        budget: {
          min: 15000,
          max: 25000
        },
        status: 'active',
        views: 45,
        responses: 3,
        createdAt: '2024-03-15'
      }
    ],
    vehicles: [
      {
        id: 1,
        title: 'مطلوب سيارة عائلية',
        location: 'صنعاء',
        type: 'سيدان',
        budget: {
          min: 10000,
          max: 15000
        },
        status: 'active',
        views: 38,
        responses: 2,
        createdAt: '2024-03-15'
      }
    ]
  };

  const handleDelete = (item: any) => {
    setItemToDelete(item);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    // Implement delete logic here
    console.log('Deleting item:', itemToDelete);
    setShowDeleteModal(false);
    setItemToDelete(null);
  };

  const DeleteModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-w-full tw-max-w-md">
        <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">تأكيد الحذف</h3>
        <p className="tw-text-gray-400 tw-mb-6">
          هل أنت متأكد من حذف "{itemToDelete?.title}"؟ لا يمكن التراجع عن هذا الإجراء.
        </p>
        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowDeleteModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={confirmDelete}
            className="tw-px-4 tw-py-2 tw-bg-red-500 hover:tw-bg-red-600 tw-text-white tw-rounded-lg"
          >
            حذف
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      {/* Filters */}
      <div className="tw-flex tw-items-center tw-justify-between">
        <div className="tw-flex tw-items-center tw-gap-4">
          {/* Request Type Tabs */}
          <div className="tw-bg-[#1a1a1a] tw-rounded-xl tw-p-2 tw-flex tw-gap-2">
            <button
              onClick={() => setRequestType('properties')}
              className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium tw-transition-colors ${
                requestType === 'properties'
                  ? 'tw-bg-amber-400 tw-text-black'
                  : 'tw-text-gray-400 hover:tw-text-white'
              }`}
            >
              <Building2 className="tw-w-4 tw-h-4" />
              <span>طلبات العقارات</span>
            </button>
            <button
              onClick={() => setRequestType('vehicles')}
              className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium tw-transition-colors ${
                requestType === 'vehicles'
                  ? 'tw-bg-purple-600 tw-text-white'
                  : 'tw-text-gray-400 hover:tw-text-white'
              }`}
            >
              <Car className="tw-w-4 tw-h-4" />
              <span>طلبات السيارات</span>
            </button>
          </div>

          {/* Filter Button */}
          <button className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-lg">
            <Filter className="tw-w-4 tw-h-4" />
            <span>تصفية</span>
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-1 tw-flex tw-gap-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`tw-p-2 tw-rounded-lg tw-transition-colors ${
              viewMode === 'grid'
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-text-gray-400 hover:tw-text-white'
            }`}
          >
            <LayoutGrid className="tw-w-4 tw-h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`tw-p-2 tw-rounded-lg tw-transition-colors ${
              viewMode === 'list'
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-text-gray-400 hover:tw-text-white'
            }`}
          >
            <List className="tw-w-4 tw-h-4" />
          </button>
        </div>
      </div>

      {/* Requests Grid */}
      <div className={`tw-grid ${
        viewMode === 'grid' 
          ? 'tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6'
          : 'tw-grid-cols-1 tw-gap-4'
      }`}>
        {requests[requestType].map((request) => (
          <div 
            key={request.id}
            className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/50 tw-transition-all"
          >
            <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-mb-3">
              <MapPin className="tw-w-4 tw-h-4" />
              <span className="tw-text-sm">{request.location}</span>
            </div>

            <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">
              {request.title}
            </h3>

            <div className="tw-flex tw-items-center tw-gap-6 tw-mb-6">
              <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                <Eye className="tw-w-4 tw-h-4" />
                <span>{request.views} مشاهدة</span>
              </div>
              <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                <MessageCircle className="tw-w-4 tw-h-4" />
                <span>{request.responses} رد</span>
              </div>
              <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400">
                <Calendar className="tw-w-4 tw-h-4" />
                <span>{request.createdAt}</span>
              </div>
            </div>

            <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
              <div className="tw-text-xl tw-font-bold tw-text-amber-400">
                ${request.budget.min} - ${request.budget.max}
              </div>
              <div className="tw-flex tw-gap-2">
                <button 
                  onClick={() => {}}
                  className="tw-p-2 tw-text-amber-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                  title="تعديل"
                >
                  <Edit2 className="tw-w-4 tw-h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(request)}
                  className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                  title="حذف"
                >
                  <Trash2 className="tw-w-4 tw-h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && <DeleteModal />}
    </div>
  );
};