import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { vehiclesApi } from '../../../lib/api';
import { 
  MapPin, Car, Calendar, Gauge, Fuel,
  Upload, Plus, X, Settings
} from 'lucide-react';

export const CreateVehicle = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    make: '',
    model: '',
    year: '',
    price: '',
    location: '',
    mileage: '',
    fuelType: '',
    transmission: '',
    features: [''],
    images: []
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const carMakes = [
    'تويوتا',
    'هوندا',
    'نيسان',
    'مرسيدس',
    'بي إم دبليو',
    'لكزس',
    'هيونداي'
  ];

  const locations = [
    'صنعاء',
    'عدن',
    'تعز',
    'الحديدة',
    'إب',
    'ذمار'
  ];

  const fuelTypes = [
    'بنزين',
    'ديزل',
    'هايبرد'
  ];

  const transmissions = [
    'أوتوماتيك',
    'يدوي'
  ];

  const handleFeatureAdd = () => {
    setFormData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };

  const handleFeatureRemove = (index: number) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const handleFeatureChange = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.map((feature, i) => 
        i === index ? value : feature
      )
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await vehiclesApi.create({
        ...formData,
        price: parseFloat(formData.price),
        year: parseInt(formData.year),
        mileage: parseFloat(formData.mileage),
      });

      if (error) throw error;

      setSuccess(true);
      setFormData({
        title: '',
        description: '',
        make: '',
        model: '',
        year: '',
        price: '',
        location: '',
        mileage: '',
        fuelType: '',
        transmission: '',
        features: [''],
        images: []
      });

      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إضافة السيارة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      <h2 className="tw-text-xl tw-font-bold tw-text-white tw-mb-6">إضافة سيارة جديدة</h2>

      {success && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم إضافة السيارة بنجاح
        </div>
      )}

      {error && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-mb-6">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="tw-space-y-6">
        {/* Basic Information */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              عنوان الإعلان
              <span className="tw-text-purple-400">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الماركة
              <span className="tw-text-purple-400">*</span>
            </label>
            <select
              value={formData.make}
              onChange={(e) => setFormData({ ...formData, make: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              required
            >
              <option value="">اختر الماركة</option>
              {carMakes.map((make) => (
                <option key={make} value={make}>{make}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموديل
              <span className="tw-text-purple-400">*</span>
            </label>
            <input
              type="text"
              value={formData.model}
              onChange={(e) => setFormData({ ...formData, model: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              سنة الصنع
              <span className="tw-text-purple-400">*</span>
            </label>
            <input
              type="number"
              value={formData.year}
              onChange={(e) => setFormData({ ...formData, year: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              min="1900"
              max={new Date().getFullYear()}
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر
              <span className="tw-text-purple-400">*</span>
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
                required
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموقع
              <span className="tw-text-purple-400">*</span>
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
              required
            >
              <option value="">اختر الموقع</option>
              {locations.map((location) => (
                <option key={location} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Vehicle Details */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              المسافة المقطوعة (كم)
            </label>
            <input
              type="number"
              value={formData.mileage}
              onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              نوع الوقود
            </label>
            <select
              value={formData.fuelType}
              onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            >
              <option value="">اختر نوع الوقود</option>
              {fuelTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              ناقل الحركة
            </label>
            <select
              value={formData.transmission}
              onChange={(e) => setFormData({ ...formData, transmission: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            >
              <option value="">اختر نوع ناقل الحركة</option>
              {transmissions.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            الوصف
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
            rows={6}
            required
          />
        </div>

        {/* Features */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
            المميزات
          </label>
          <div className="tw-space-y-4">
            {formData.features.map((feature, index) => (
              <div key={index} className="tw-flex tw-gap-2">
                <input
                  type="text"
                  value={feature}
                  onChange={(e) => handleFeatureChange(index, e.target.value)}
                  className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-purple-400"
                  placeholder="أضف ميزة"
                />
                <button
                  type="button"
                  onClick={() => handleFeatureRemove(index)}
                  className="tw-p-3 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-xl"
                >
                  <X className="tw-w-5 tw-h-5" />
                </button>
              </div>
            ))}
            
            <button
              type="button"
              onClick={handleFeatureAdd}
              className="tw-w-full tw-flex tw-items-center tw-justify-center tw-gap-2 tw-px-4 tw-py-3 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-xl"
            >
              <Plus className="tw-w-4 tw-h-4" />
              <span>إضافة ميزة</span>
            </button>
          </div>
        </div>

        {/* Images */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
            الصور
          </label>
          <div className="tw-border-2 tw-border-dashed tw-border-neutral-700 tw-rounded-xl tw-p-8">
            <div className="tw-flex tw-flex-col tw-items-center tw-justify-center tw-text-center">
              <Upload className="tw-w-12 tw-h-12 tw-text-gray-400 tw-mb-4" />
              <p className="tw-text-gray-300 tw-mb-2">اسحب وأفلت الصور هنا</p>
              <p className="tw-text-gray-400 tw-text-sm">أو</p>
              <button
                type="button"
                className="tw-mt-4 tw-px-6 tw-py-2 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-lg"
              >
                اختر الصور
              </button>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="tw-flex tw-justify-end">
          <button
            type="submit"
            disabled={loading}
            className="tw-px-8 tw-py-3 tw-bg-purple-600 hover:tw-bg-purple-700 tw-text-white tw-rounded-xl tw-font-medium tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
          >
            {loading ? 'جاري الإضافة...' : 'إضافة السيارة'}
          </button>
        </div>
      </form>
    </div>
  );
};