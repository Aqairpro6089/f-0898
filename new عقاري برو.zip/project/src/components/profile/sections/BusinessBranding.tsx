import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { Crown, Upload, Globe, Facebook, Instagram } from 'lucide-react';

export const BusinessBranding = () => {
  const { user, updateUserProfile } = useAuth();
  const [formData, setFormData] = useState({
    logo: '',
    coverImage: '',
    businessDescription: '',
    website: '',
    facebook: '',
    instagram: '',
    businessHours: {
      sunday: { open: '09:00', close: '17:00' },
      monday: { open: '09:00', close: '17:00' },
      tuesday: { open: '09:00', close: '17:00' },
      wednesday: { open: '09:00', close: '17:00' },
      thursday: { open: '09:00', close: '17:00' },
      friday: { open: '', close: '' },
      saturday: { open: '', close: '' }
    }
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await updateUserProfile({
        ...user,
        branding: formData
      });
      
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Error updating branding:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
        <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
          <Crown className="tw-w-6 tw-h-6 tw-text-amber-400" />
        </div>
        <div>
          <h2 className="tw-text-xl tw-font-bold tw-text-white">الهوية التجارية</h2>
          <p className="tw-text-gray-400">تخصيص وتحسين ظهور حسابك التجاري</p>
        </div>
      </div>

      {success && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم حفظ التغييرات بنجاح
        </div>
      )}

      <form onSubmit={handleSubmit} className="tw-space-y-6">
        {/* Logo Upload */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            شعار الشركة
          </label>
          <div className="tw-border-2 tw-border-dashed tw-border-neutral-700 tw-rounded-xl tw-p-8">
            <div className="tw-flex tw-flex-col tw-items-center tw-justify-center tw-text-center">
              <Upload className="tw-w-12 tw-h-12 tw-text-gray-400 tw-mb-4" />
              <p className="tw-text-gray-300 tw-mb-2">اسحب وأفلت الشعار هنا</p>
              <p className="tw-text-gray-400 tw-text-sm">أو</p>
              <button
                type="button"
                className="tw-mt-4 tw-px-6 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg"
              >
                اختر الشعار
              </button>
            </div>
          </div>
        </div>

        {/* Cover Image Upload */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            صورة الغلاف
          </label>
          <div className="tw-border-2 tw-border-dashed tw-border-neutral-700 tw-rounded-xl tw-p-8">
            <div className="tw-flex tw-flex-col tw-items-center tw-justify-center tw-text-center">
              <Upload className="tw-w-12 tw-h-12 tw-text-gray-400 tw-mb-4" />
              <p className="tw-text-gray-300 tw-mb-2">اسحب وأفلت صورة الغلاف هنا</p>
              <p className="tw-text-gray-400 tw-text-sm">أو</p>
              <button
                type="button"
                className="tw-mt-4 tw-px-6 tw-py-2 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-lg"
              >
                اختر الصورة
              </button>
            </div>
          </div>
        </div>

        {/* Business Description */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            وصف الشركة
          </label>
          <textarea
            value={formData.businessDescription}
            onChange={(e) => setFormData({ ...formData, businessDescription: e.target.value })}
            className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            rows={4}
            placeholder="اكتب وصفاً مختصراً عن شركتك..."
          />
        </div>

        {/* Social Media Links */}
        <div className="tw-space-y-4">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموقع الإلكتروني
            </label>
            <div className="tw-flex tw-items-center tw-gap-2">
              <Globe className="tw-w-5 tw-h-5 tw-text-gray-400" />
              <input
                type="url"
                value={formData.website}
                onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                placeholder="https://example.com"
              />
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              فيسبوك
            </label>
            <div className="tw-flex tw-items-center tw-gap-2">
              <Facebook className="tw-w-5 tw-h-5 tw-text-gray-400" />
              <input
                type="url"
                value={formData.facebook}
                onChange={(e) => setFormData({ ...formData, facebook: e.target.value })}
                className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                placeholder="https://facebook.com/your-page"
              />
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              انستغرام
            </label>
            <div className="tw-flex tw-items-center tw-gap-2">
              <Instagram className="tw-w-5 tw-h-5 tw-text-gray-400" />
              <input
                type="url"
                value={formData.instagram}
                onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                className="tw-flex-1 tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                placeholder="https://instagram.com/your-account"
              />
            </div>
          </div>
        </div>

        {/* Business Hours */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-4">
            ساعات العمل
          </label>
          <div className="tw-space-y-4">
            {Object.entries(formData.businessHours).map(([day, hours]) => (
              <div key={day} className="tw-flex tw-items-center tw-gap-4">
                <span className="tw-w-24 tw-text-gray-400">
                  {day === 'sunday' && 'الأحد'}
                  {day === 'monday' && 'الإثنين'}
                  {day === 'tuesday' && 'الثلاثاء'}
                  {day === 'wednesday' && 'الأربعاء'}
                  {day === 'thursday' && 'الخميس'}
                  {day === 'friday' && 'الجمعة'}
                  {day === 'saturday' && 'السبت'}
                </span>
                <input
                  type="time"
                  value={hours.open}
                  onChange={(e) => setFormData({
                    ...formData,
                    businessHours: {
                      ...formData.businessHours,
                      [day]: { ...hours, open: e.target.value }
                    }
                  })}
                  className="tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                />
                <span className="tw-text-gray-400">إلى</span>
                <input
                  type="time"
                  value={hours.close}
                  onChange={(e) => setFormData({
                    ...formData,
                    businessHours: {
                      ...formData.businessHours,
                      [day]: { ...hours, close: e.target.value }
                    }
                  })}
                  className="tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-lg tw-px-3 tw-py-2 tw-text-white"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="tw-flex tw-justify-end">
          <button
            type="submit"
            disabled={loading}
            className="tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
          >
            {loading ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </button>
        </div>
      </form>
    </div>
  );
};