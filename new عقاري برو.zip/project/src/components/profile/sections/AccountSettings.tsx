import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { 
  User, Mail, Phone, Globe, Briefcase, 
  Building2, Shield, Lock, Bell, Settings
} from 'lucide-react';

export const AccountSettings = () => {
  const { user, updateUserProfile } = useAuth();
  const [formData, setFormData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    country: user?.country || 'ye',
    // Business specific
    businessName: user?.businessName || '',
    businessType: user?.businessType || '',
    // Preferences
    emailNotifications: true,
    smsNotifications: true,
    language: 'ar',
    currency: 'USD'
  });

  const [currentSection, setCurrentSection] = useState('profile');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateUserProfile(formData);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const sections = [
    { id: 'profile', label: 'الملف الشخصي', icon: User },
    { id: 'security', label: 'الأمان', icon: Shield },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'preferences', label: 'التفضيلات', icon: Settings }
  ];

  const renderSection = () => {
    switch (currentSection) {
      case 'profile':
        return (
          <form onSubmit={handleSubmit} className="tw-space-y-6">
            {user?.accountType === 'business' ? (
              <>
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    اسم الشركة
                  </label>
                  <input
                    type="text"
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  />
                </div>

                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    نوع النشاط
                  </label>
                  <select
                    value={formData.businessType}
                    onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                    className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                  >
                    <option value="">اختر نوع النشاط</option>
                    <option value="real-estate">مكتب عقاري</option>
                    <option value="car-dealer">معرض سيارات</option>
                  </select>
                </div>
              </>
            ) : (
              <div>
                <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                  الاسم الكامل
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
                />
              </div>
            )}

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              />
            </div>

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                رقم الهاتف
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              />
            </div>

            <div>
              <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                الدولة
              </label>
              <select
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              >
                <option value="ye">اليمن</option>
                <option value="sa">السعودية</option>
                <option value="ae">الإمارات</option>
              </select>
            </div>

            <div className="tw-flex tw-justify-end">
              <button
                type="submit"
                className="tw-px-6 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl"
              >
                حفظ التغييرات
              </button>
            </div>
          </form>
        );

      case 'security':
        return (
          <div className="tw-space-y-6">
            <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6">
              <h3 className="tw-text-lg tw-font-medium tw-text-white tw-mb-4">
                تغيير كلمة المرور
              </h3>
              <form className="tw-space-y-4">
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    كلمة المرور الحالية
                  </label>
                  <input
                    type="password"
                    className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
                  />
                </div>
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    كلمة المرور الجديدة
                  </label>
                  <input
                    type="password"
                    className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
                  />
                </div>
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    تأكيد كلمة المرور
                  </label>
                  <input
                    type="password"
                    className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
                  />
                </div>
                <div className="tw-flex tw-justify-end">
                  <button
                    type="submit"
                    className="tw-px-6 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl"
                  >
                    تغيير كلمة المرور
                  </button>
                </div>
              </form>
            </div>

            <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6">
              <h3 className="tw-text-lg tw-font-medium tw-text-white tw-mb-4">
                المصادقة الثنائية
              </h3>
              <div className="tw-flex tw-items-center tw-justify-between">
                <div>
                  <p className="tw-text-gray-300">تفعيل المصادقة الثنائية</p>
                  <p className="tw-text-sm tw-text-gray-400">
                    احمِ حسابك باستخدام رمز إضافي عند تسجيل الدخول
                  </p>
                </div>
                <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                  <input type="checkbox" className="tw-sr-only tw-peer" />
                  <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                </label>
              </div>
            </div>
          </div>
        );

      case 'notifications':
        return (
          <div className="tw-space-y-6">
            <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6">
              <h3 className="tw-text-lg tw-font-medium tw-text-white tw-mb-4">
                إعدادات الإشعارات
              </h3>
              <div className="tw-space-y-4">
                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-gray-300">إشعارات البريد الإلكتروني</p>
                    <p className="tw-text-sm tw-text-gray-400">
                      استلام إشعارات عبر البريد الإلكتروني
                    </p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.emailNotifications}
                      onChange={(e) => setFormData({ ...formData, emailNotifications: e.target.checked })}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>

                <div className="tw-flex tw-items-center tw-justify-between">
                  <div>
                    <p className="tw-text-gray-300">إشعارات الرسائل النصية</p>
                    <p className="tw-text-sm tw-text-gray-400">
                      استلام إشعارات عبر الرسائل النصية
                    </p>
                  </div>
                  <label className="tw-relative tw-inline-flex tw-items-center tw-cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.smsNotifications}
                      onChange={(e) => setFormData({ ...formData, smsNotifications: e.target.checked })}
                      className="tw-sr-only tw-peer"
                    />
                    <div className="tw-w-11 tw-h-6 tw-bg-neutral-700 tw-rounded-full tw-peer peer-checked:tw-bg-amber-400"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        );

      case 'preferences':
        return (
          <div className="tw-space-y-6">
            <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-6">
              <h3 className="tw-text-lg tw-font-medium tw-text-white tw-mb-4">
                تفضيلات العرض
              </h3>
              <div className="tw-space-y-4">
                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    اللغة
                  </label>
                  <select
                    value={formData.language}
                    onChange={(e) => setFormData({ ...formData, language: e.target.value })}
                    className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
                  >
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </div>

                <div>
                  <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
                    العملة
                  </label>
                  <select
                    value={formData.currency}
                    onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                    className="tw-w-full tw-bg-neutral-700 tw-border tw-border-neutral-600 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white"
                  >
                    <option value="USD">USD - دولار أمريكي</option>
                    <option value="YER">YER - ريال يمني</option>
                    <option value="SAR">SAR - ريال سعودي</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      {/* Section Tabs */}
      <div className="tw-flex tw-flex-wrap tw-gap-4 tw-mb-8">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => setCurrentSection(section.id)}
            className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-transition-colors ${
              currentSection === section.id
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-bg-neutral-800 tw-text-gray-400 hover:tw-text-white'
            }`}
          >
            <section.icon className="tw-w-4 tw-h-4" />
            <span>{section.label}</span>
          </button>
        ))}
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم حفظ التغييرات بنجاح
        </div>
      )}

      {/* Section Content */}
      {renderSection()}
    </div>
  );
};