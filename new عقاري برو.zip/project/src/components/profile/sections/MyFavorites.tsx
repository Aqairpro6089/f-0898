import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { 
  Building2, Car, MapPin, Calendar, DollarSign,
  Trash2, Eye, Share2, Heart,
  LayoutGrid, List, Filter
} from 'lucide-react';

export const MyFavorites = () => {
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [favoriteType, setFavoriteType] = useState<'properties' | 'vehicles'>('properties');
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [itemToRemove, setItemToRemove] = useState<any>(null);

  // Mock favorites data
  const favorites = {
    properties: [
      {
        id: 1,
        title: 'فيلا فاخرة في صنعاء',
        location: 'صنعاء - حدة',
        price: '301,887',
        type: 'فيلا',
        image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&auto=format&fit=crop&q=60'
      }
    ],
    vehicles: [
      {
        id: 1,
        title: 'تويوتا كامري 2023',
        location: 'صنعاء',
        price: '25,000',
        type: 'سيدان',
        image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=60'
      }
    ]
  };

  const handleRemove = (item: any) => {
    setItemToRemove(item);
    setShowRemoveModal(true);
  };

  const confirmRemove = () => {
    // Implement remove from favorites logic here
    console.log('Removing item from favorites:', itemToRemove);
    setShowRemoveModal(false);
    setItemToRemove(null);
  };

  const RemoveModal = () => (
    <div className="tw-fixed tw-inset-0 tw-bg-black/50 tw-flex tw-items-center tw-justify-center tw-z-50">
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6 tw-w-full tw-max-w-md">
        <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">إزالة من المفضلة</h3>
        <p className="tw-text-gray-400 tw-mb-6">
          هل أنت متأكد من إزالة "{itemToRemove?.title}" من المفضلة؟
        </p>
        <div className="tw-flex tw-justify-end tw-gap-4">
          <button
            onClick={() => setShowRemoveModal(false)}
            className="tw-px-4 tw-py-2 tw-bg-neutral-700 hover:tw-bg-neutral-600 tw-text-white tw-rounded-lg"
          >
            إلغاء
          </button>
          <button
            onClick={confirmRemove}
            className="tw-px-4 tw-py-2 tw-bg-red-500 hover:tw-bg-red-600 tw-text-white tw-rounded-lg"
          >
            إزالة
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="tw-space-y-6">
      {/* Filters */}
      <div className="tw-flex tw-items-center tw-justify-between">
        <div className="tw-flex tw-items-center tw-gap-4">
          {/* Favorite Type Tabs */}
          <div className="tw-bg-[#1a1a1a] tw-rounded-xl tw-p-2 tw-flex tw-gap-2">
            <button
              onClick={() => setFavoriteType('properties')}
              className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium tw-transition-colors ${
                favoriteType === 'properties'
                  ? 'tw-bg-amber-400 tw-text-black'
                  : 'tw-text-gray-400 hover:tw-text-white'
              }`}
            >
              <Building2 className="tw-w-4 tw-h-4" />
              <span>العقارات</span>
            </button>
            <button
              onClick={() => setFavoriteType('vehicles')}
              className={`tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-rounded-lg tw-font-medium tw-transition-colors ${
                favoriteType === 'vehicles'
                  ? 'tw-bg-purple-600 tw-text-white'
                  : 'tw-text-gray-400 hover:tw-text-white'
              }`}
            >
              <Car className="tw-w-4 tw-h-4" />
              <span>السيارات</span>
            </button>
          </div>

          {/* Filter Button */}
          <button className="tw-flex tw-items-center tw-gap-2 tw-px-4 tw-py-2 tw-bg-neutral-800 hover:tw-bg-neutral-700 tw-text-white tw-rounded-lg">
            <Filter className="tw-w-4 tw-h-4" />
            <span>تصفية</span>
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="tw-bg-neutral-800 tw-rounded-lg tw-p-1 tw-flex tw-gap-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`tw-p-2 tw-rounded-lg tw-transition-colors ${
              viewMode === 'grid'
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-text-gray-400 hover:tw-text-white'
            }`}
          >
            <LayoutGrid className="tw-w-4 tw-h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`tw-p-2 tw-rounded-lg tw-transition-colors ${
              viewMode === 'list'
                ? 'tw-bg-amber-400 tw-text-black'
                : 'tw-text-gray-400 hover:tw-text-white'
            }`}
          >
            <List className="tw-w-4 tw-h-4" />
          </button>
        </div>
      </div>

      {/* Favorites Grid */}
      <div className={`tw-grid ${
        viewMode === 'grid' 
          ? 'tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6'
          : 'tw-grid-cols-1 tw-gap-4'
      }`}>
        {favorites[favoriteType].map((item) => (
          <div 
            key={item.id}
            className={`tw-bg-[#1a1a1a] tw-rounded-2xl tw-overflow-hidden tw-border tw-border-[#2a2a2a] hover:tw-border-amber-400/50 tw-transition-all ${
              viewMode === 'list' ? 'tw-flex' : ''
            }`}
          >
            {/* Image */}
            <div className={`tw-relative ${viewMode === 'list' ? 'tw-w-48' : 'tw-aspect-[16/9]'}`}>
              <img 
                src={item.image}
                alt={item.title}
                className="tw-w-full tw-h-full tw-object-cover"
              />
              <div className="tw-absolute tw-top-4 tw-right-4">
                <span className={`tw-px-2 tw-py-1 tw-rounded-full tw-text-xs tw-font-medium ${
                  favoriteType === 'properties'
                    ? 'tw-bg-amber-400 tw-text-black'
                    : 'tw-bg-purple-600 tw-text-white'
                }`}>
                  {item.type}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="tw-p-6">
              <div className="tw-flex tw-items-center tw-gap-2 tw-text-gray-400 tw-mb-3">
                <MapPin className="tw-w-4 tw-h-4" />
                <span className="tw-text-sm">{item.location}</span>
              </div>

              <h3 className="tw-text-xl tw-font-bold tw-text-white tw-mb-4">
                {item.title}
              </h3>

              <div className="tw-flex tw-items-center tw-justify-between tw-border-t tw-border-[#2a2a2a] tw-pt-4">
                <div className="tw-text-2xl tw-font-bold tw-text-amber-400">
                  ${item.price}
                </div>
                <div className="tw-flex tw-gap-2">
                  <button 
                    onClick={() => {}}
                    className="tw-p-2 tw-text-purple-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                    title="مشاركة"
                  >
                    <Share2 className="tw-w-4 tw-h-4" />
                  </button>
                  <button 
                    onClick={() => handleRemove(item)}
                    className="tw-p-2 tw-text-red-400 hover:tw-bg-neutral-700 tw-rounded-lg tw-transition-colors"
                    title="إزالة من المفضلة"
                  >
                    <Heart className="tw-w-4 tw-h-4 tw-fill-current" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Remove Confirmation Modal */}
      {showRemoveModal && <RemoveModal />}
    </div>
  );
};