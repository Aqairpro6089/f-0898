import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { requestsApi } from '../../../lib/api';
import { 
  MapPin, Building2, Square, Bed, Bath,
  DollarSign, Search
} from 'lucide-react';

export const RequestProperty = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: '',
    location: '',
    minPrice: '',
    maxPrice: '',
    minArea: '',
    maxArea: '',
    bedrooms: '',
    bathrooms: ''
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const propertyTypes = [
    'شقة',
    'فيلا',
    'عمارة',
    'أرض',
    'محل تجاري',
    'مكتب',
    'مستودع'
  ];

  const locations = [
    'صنعاء',
    'عدن',
    'تعز',
    'الحديدة',
    'إب',
    'ذمار'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await requestsApi.createPropertyRequest({
        ...formData,
        minPrice: formData.minPrice ? parseFloat(formData.minPrice) : undefined,
        maxPrice: formData.maxPrice ? parseFloat(formData.maxPrice) : undefined,
        minArea: formData.minArea ? parseFloat(formData.minArea) : undefined,
        maxArea: formData.maxArea ? parseFloat(formData.maxArea) : undefined,
        bedrooms: formData.bedrooms ? parseInt(formData.bedrooms) : undefined,
        bathrooms: formData.bathrooms ? parseInt(formData.bathrooms) : undefined
      });

      if (error) throw error;

      setSuccess(true);
      setFormData({
        title: '',
        description: '',
        type: '',
        location: '',
        minPrice: '',
        maxPrice: '',
        minArea: '',
        maxArea: '',
        bedrooms: '',
        bathrooms: ''
      });

      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إضافة الطلب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
      <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
        <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
          <Search className="tw-w-6 tw-h-6 tw-text-amber-400" />
        </div>
        <div>
          <h2 className="tw-text-xl tw-font-bold tw-text-white">طلب عقار</h2>
          <p className="tw-text-gray-400">أضف طلبك للعقار المطلوب</p>
        </div>
      </div>

      {success && (
        <div className="tw-bg-green-500/10 tw-border tw-border-green-500 tw-text-green-500 tw-p-4 tw-rounded-xl tw-mb-6">
          تم إضافة الطلب بنجاح
        </div>
      )}

      {error && (
        <div className="tw-bg-red-500/10 tw-border tw-border-red-500 tw-text-red-500 tw-p-4 tw-rounded-xl tw-mb-6">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="tw-space-y-6">
        {/* Basic Information */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              عنوان الطلب
              <span className="tw-text-amber-400">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              placeholder="مثال: مطلوب شقة عائلية في صنعاء"
              required
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              نوع العقار
              <span className="tw-text-amber-400">*</span>
            </label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              required
            >
              <option value="">اختر نوع العقار</option>
              {propertyTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الموقع
              <span className="tw-text-amber-400">*</span>
            </label>
            <select
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              required
            >
              <option value="">اختر الموقع</option>
              {locations.map((location) => (
                <option key={location} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Price Range */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر من
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.minPrice}
                onChange={(e) => setFormData({ ...formData, minPrice: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              السعر إلى
            </label>
            <div className="tw-relative">
              <input
                type="number"
                value={formData.maxPrice}
                onChange={(e) => setFormData({ ...formData, maxPrice: e.target.value })}
                className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
              />
              <span className="tw-absolute tw-left-4 tw-top-1/2 -tw-translate-y-1/2 tw-text-gray-400">
                $
              </span>
            </div>
          </div>
        </div>

        {/* Area Range */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              المساحة من (م²)
            </label>
            <input
              type="number"
              value={formData.minArea}
              onChange={(e) => setFormData({ ...formData, minArea: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              المساحة إلى (م²)
            </label>
            <input
              type="number"
              value={formData.maxArea}
              onChange={(e) => setFormData({ ...formData, maxArea: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            />
          </div>
        </div>

        {/* Rooms */}
        <div className="tw-grid tw-grid-cols-1 md:tw-grid-cols-2 tw-gap-6">
          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              غرف النوم
            </label>
            <select
              value={formData.bedrooms}
              onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            >
              <option value="">الكل</option>
              {[1,2,3,4,5,6].map(num => (
                <option key={num} value={num}>{num}+</option>
              ))}
            </select>
          </div>

          <div>
            <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
              الحمامات
            </label>
            <select
              value={formData.bathrooms}
              onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
              className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            >
              <option value="">الكل</option>
              {[1,2,3,4].map(num => (
                <option key={num} value={num}>{num}+</option>
              ))}
            </select>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="tw-block tw-text-sm tw-font-medium tw-text-gray-300 tw-mb-2">
            تفاصيل إضافية
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="tw-w-full tw-bg-neutral-800 tw-border tw-border-neutral-700 tw-rounded-xl tw-px-4 tw-py-3 tw-text-white focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-amber-400"
            rows={6}
            placeholder="اكتب أي متطلبات أو تفاصيل إضافية..."
          />
        </div>

        {/* Submit Button */}
        <div className="tw-flex tw-justify-end">
          <button
            type="submit"
            disabled={loading}
            className="tw-px-8 tw-py-3 tw-bg-amber-400 hover:tw-bg-amber-500 tw-text-black tw-rounded-xl tw-font-medium tw-transition-colors disabled:tw-opacity-50 disabled:tw-cursor-not-allowed"
          >
            {loading ? 'جاري الإضافة...' : 'إضافة الطلب'}
          </button>
        </div>
      </form>
    </div>
  );
};