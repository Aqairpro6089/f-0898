import React from 'react';
import { useAuth } from '../../../context/AuthContext';
import { 
  BarChart2, TrendingUp, Users, DollarSign,
  Eye, MessageCircle, Star, Heart
} from 'lucide-react';

export const MyStats = () => {
  const { user } = useAuth();

  // Mock statistics data
  const stats = {
    overview: {
      totalListings: user?.stats?.listings || 0,
      totalViews: user?.stats?.views || 0,
      totalLeads: user?.stats?.leads || 0,
      averageRating: user?.stats?.rating || 0
    },
    performance: {
      thisMonth: {
        views: 245,
        leads: 12,
        favorites: 34,
        messages: 18
      },
      lastMonth: {
        views: 198,
        leads: 8,
        favorites: 27,
        messages: 15
      }
    }
  };

  const calculateGrowth = (current: number, previous: number) => {
    if (!previous) return 100;
    return ((current - previous) / previous) * 100;
  };

  return (
    <div className="tw-space-y-8">
      {/* Overview Stats */}
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
        <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
          <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
            <BarChart2 className="tw-w-6 tw-h-6 tw-text-amber-400" />
          </div>
          <h2 className="tw-text-xl tw-font-bold tw-text-white">نظرة عامة</h2>
        </div>

        <div className="tw-grid tw-grid-cols-2 md:tw-grid-cols-4 tw-gap-6">
          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-3">
              <div className="tw-p-2 tw-bg-purple-400/10 tw-rounded-lg">
                <Eye className="tw-w-4 tw-h-4 tw-text-purple-400" />
              </div>
              <span className="tw-text-gray-400">المشاهدات</span>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.overview.totalViews}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-3">
              <div className="tw-p-2 tw-bg-emerald-400/10 tw-rounded-lg">
                <MessageCircle className="tw-w-4 tw-h-4 tw-text-emerald-400" />
              </div>
              <span className="tw-text-gray-400">التواصل</span>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.overview.totalLeads}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-3">
              <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
                <Star className="tw-w-4 tw-h-4 tw-text-amber-400" />
              </div>
              <span className="tw-text-gray-400">التقييم</span>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.overview.averageRating}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-gap-3 tw-mb-3">
              <div className="tw-p-2 tw-bg-blue-400/10 tw-rounded-lg">
                <Heart className="tw-w-4 tw-h-4 tw-text-blue-400" />
              </div>
              <span className="tw-text-gray-400">الإعجابات</span>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.performance.thisMonth.favorites}
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Performance */}
      <div className="tw-bg-[#1a1a1a] tw-rounded-2xl tw-p-6">
        <div className="tw-flex tw-items-center tw-gap-3 tw-mb-6">
          <div className="tw-p-2 tw-bg-amber-400/10 tw-rounded-lg">
            <TrendingUp className="tw-w-6 tw-h-6 tw-text-amber-400" />
          </div>
          <h2 className="tw-text-xl tw-font-bold tw-text-white">أداء هذا الشهر</h2>
        </div>

        <div className="tw-grid tw-grid-cols-2 md:tw-grid-cols-4 tw-gap-6">
          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
              <span className="tw-text-gray-400">المشاهدات</span>
              <div className={`tw-text-sm ${
                calculateGrowth(stats.performance.thisMonth.views, stats.performance.lastMonth.views) >= 0
                  ? 'tw-text-green-400'
                  : 'tw-text-red-400'
              }`}>
                {calculateGrowth(stats.performance.thisMonth.views, stats.performance.lastMonth.views).toFixed(1)}%
              </div>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.performance.thisMonth.views}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
              <span className="tw-text-gray-400">التواصل</span>
              <div className={`tw-text-sm ${
                calculateGrowth(stats.performance.thisMonth.leads, stats.performance.lastMonth.leads) >= 0
                  ? 'tw-text-green-400'
                  : 'tw-text-red-400'
              }`}>
                {calculateGrowth(stats.performance.thisMonth.leads, stats.performance.lastMonth.leads).toFixed(1)}%
              </div>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.performance.thisMonth.leads}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
              <span className="tw-text-gray-400">الإعجابات</span>
              <div className={`tw-text-sm ${
                calculateGrowth(stats.performance.thisMonth.favorites, stats.performance.lastMonth.favorites) >= 0
                  ? 'tw-text-green-400'
                  : 'tw-text-red-400'
              }`}>
                {calculateGrowth(stats.performance.thisMonth.favorites, stats.performance.lastMonth.favorites).toFixed(1)}%
              </div>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.performance.thisMonth.favorites}
            </div>
          </div>

          <div className="tw-bg-neutral-800 tw-rounded-xl tw-p-4">
            <div className="tw-flex tw-items-center tw-justify-between tw-mb-2">
              <span className="tw-text-gray-400">الرسائل</span>
              <div className={`tw-text-sm ${
                calculateGrowth(stats.performance.thisMonth.messages, stats.performance.lastMonth.messages) >= 0
                  ? 'tw-text-green-400'
                  : 'tw-text-red-400'
              }`}>
                {calculateGrowth(stats.performance.thisMonth.messages, stats.performance.lastMonth.messages).toFixed(1)}%
              </div>
            </div>
            <div className="tw-text-2xl tw-font-bold tw-text-white">
              {stats.performance.thisMonth.messages}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};