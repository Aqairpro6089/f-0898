// Property Categories
export const propertyCategories = [
  { id: 'apartments', title: 'شقق' },
  { id: 'houses', title: 'بيوت' },
  { id: 'villas', title: 'فلل' },
  { id: 'chalets', title: 'شاليهات' },
  { id: 'resorts', title: 'منتجعات' },
  { id: 'hotels', title: 'فنادق' },
  { id: 'shops', title: 'محلات تجارية' },
  { id: 'residential-land', title: 'أراضي سكنية' },
  { id: 'warehouses', title: 'مستودعات' },
  { id: 'commercial-buildings', title: 'مباني تجارية' },
  { id: 'investment-buildings', title: 'عمائر استثمارية' },
  { id: 'farms', title: 'مزارع' }
];

// Vehicle Categories
export const vehicleCategories = [
  { id: 'personal', title: 'سيارات شخصية' },
  { id: 'rental-office', title: 'سيارات مكتب للإيجار' },
  { id: 'showroom', title: 'سيارات معارض' },
  { id: 'public-transport', title: 'سيارات نقل جماعي' },
  { id: 'company', title: 'سيارات شركات' },
  { id: 'tourism', title: 'سيارات خاصة بالسياحة' },
  { id: 'commercial', title: 'سيارات تجارية' },
  { id: 'luxury', title: 'سيارات فاخرة' },
  { id: 'sports', title: 'سيارات رياضية' },
  { id: 'cargo', title: 'سيارات نقل بضائع' },
  { id: 'shipping', title: 'سيارات مخصصة للشحن' },
  { id: 'wedding', title: 'سيارات كلاسيكية للأفراح' }
];