import React, { createContext, useContext, useState, useEffect } from 'react';
import { pricingPlans as defaultPlans } from '../data/pricing';

interface PricingPlan {
  id: string;
  title: string;
  price: string;
  period: string;
  features: string[];
  color: 'purple' | 'neutral';
}

interface SubscriptionContextType {
  plans: PricingPlan[];
  updatePlans: (newPlans: PricingPlan[]) => void;
  premiumContentEnabled: boolean;
  setPremiumContentEnabled: (enabled: boolean) => void;
}

const SubscriptionContext = createContext<SubscriptionContextType | null>(null);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [plans, setPlans] = useState<PricingPlan[]>(() => {
    const storedPlans = localStorage.getItem('subscription_plans');
    return storedPlans ? JSON.parse(storedPlans) : defaultPlans;
  });

  // Add premium content control state
  const [premiumContentEnabled, setPremiumContentEnabled] = useState(() => {
    const stored = localStorage.getItem('premium_content_enabled');
    return stored ? JSON.parse(stored) : false;
  });

  // Update plans and persist to localStorage
  const updatePlans = (newPlans: PricingPlan[]) => {
    setPlans(newPlans);
    localStorage.setItem('subscription_plans', JSON.stringify(newPlans));
  };

  // Update premium content state and persist to localStorage
  useEffect(() => {
    localStorage.setItem('premium_content_enabled', JSON.stringify(premiumContentEnabled));
  }, [premiumContentEnabled]);

  return (
    <SubscriptionContext.Provider value={{ 
      plans, 
      updatePlans,
      premiumContentEnabled,
      setPremiumContentEnabled
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};