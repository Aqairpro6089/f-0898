/*
  # Initial Database Schema

  1. New Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - username (text, unique) 
      - full_name (text)
      - phone (text)
      - country (text)
      - account_type (text) - 'personal' or 'business'
      - business_name (text, nullable)
      - business_type (text, nullable)
      - selected_plan (text)
      - role (text)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - properties
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - type (text)
      - price (numeric)
      - location (text)
      - area (numeric)
      - bedrooms (integer)
      - bathrooms (integer)
      - features (text[])
      - images (text[])
      - status (text)
      - is_premium (boolean)
      - is_locked (boolean)
      - user_id (uuid, foreign key)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - vehicles
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - make (text)
      - model (text)
      - year (integer)
      - price (numeric)
      - location (text)
      - mileage (numeric)
      - fuel_type (text)
      - transmission (text)
      - features (text[])
      - images (text[])
      - status (text)
      - is_premium (boolean)
      - is_locked (boolean)
      - user_id (uuid, foreign key)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - property_requests
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - type (text)
      - location (text)
      - min_price (numeric)
      - max_price (numeric)
      - min_area (numeric)
      - max_area (numeric)
      - bedrooms (integer)
      - bathrooms (integer)
      - user_id (uuid, foreign key)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - vehicle_requests
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - make (text)
      - model (text)
      - min_year (integer)
      - max_year (integer)
      - min_price (numeric)
      - max_price (numeric)
      - location (text)
      - user_id (uuid, foreign key)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - subscriptions
      - id (uuid, primary key)
      - user_id (uuid, foreign key)
      - plan_id (text)
      - status (text)
      - start_date (timestamptz)
      - end_date (timestamptz)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add admin-specific policies

  3. Functions
    - Add trigger functions for updated_at timestamps
    - Add function to check subscription status
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email text UNIQUE NOT NULL,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL,
  phone text,
  country text NOT NULL DEFAULT 'ye',
  account_type text NOT NULL CHECK (account_type IN ('personal', 'business')),
  business_name text,
  business_type text,
  selected_plan text NOT NULL DEFAULT 'free',
  role text NOT NULL DEFAULT 'user',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Properties table
CREATE TABLE properties (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  type text NOT NULL,
  price numeric NOT NULL,
  location text NOT NULL,
  area numeric,
  bedrooms integer,
  bathrooms integer,
  features text[],
  images text[],
  status text NOT NULL DEFAULT 'pending',
  is_premium boolean NOT NULL DEFAULT false,
  is_locked boolean NOT NULL DEFAULT false,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Vehicles table
CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  make text NOT NULL,
  model text NOT NULL,
  year integer NOT NULL,
  price numeric NOT NULL,
  location text NOT NULL,
  mileage numeric,
  fuel_type text,
  transmission text,
  features text[],
  images text[],
  status text NOT NULL DEFAULT 'pending',
  is_premium boolean NOT NULL DEFAULT false,
  is_locked boolean NOT NULL DEFAULT false,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Property requests table
CREATE TABLE property_requests (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  type text NOT NULL,
  location text NOT NULL,
  min_price numeric,
  max_price numeric,
  min_area numeric,
  max_area numeric,
  bedrooms integer,
  bathrooms integer,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Vehicle requests table
CREATE TABLE vehicle_requests (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  make text,
  model text,
  min_year integer,
  max_year integer,
  min_price numeric,
  max_price numeric,
  location text NOT NULL,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Subscriptions table
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  start_date timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  end_date timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Add updated_at triggers
CREATE TRIGGER set_timestamp_users
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_properties
  BEFORE UPDATE ON properties
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_vehicles
  BEFORE UPDATE ON vehicles
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_property_requests
  BEFORE UPDATE ON property_requests
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_vehicle_requests
  BEFORE UPDATE ON vehicle_requests
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_subscriptions
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION trigger_set_timestamp();

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Users policies
CREATE POLICY "Users can view their own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Properties policies
CREATE POLICY "Anyone can view active properties"
  ON properties FOR SELECT
  USING (status = 'active' AND NOT is_locked);

CREATE POLICY "Users can create properties"
  ON properties FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own properties"
  ON properties FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own properties"
  ON properties FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Vehicles policies
CREATE POLICY "Anyone can view active vehicles"
  ON vehicles FOR SELECT
  USING (status = 'active' AND NOT is_locked);

CREATE POLICY "Users can create vehicles"
  ON vehicles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own vehicles"
  ON vehicles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own vehicles"
  ON vehicles FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Property requests policies
CREATE POLICY "Anyone can view active property requests"
  ON property_requests FOR SELECT
  USING (status = 'active');

CREATE POLICY "Users can create property requests"
  ON property_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own property requests"
  ON property_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own property requests"
  ON property_requests FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Vehicle requests policies
CREATE POLICY "Anyone can view active vehicle requests"
  ON vehicle_requests FOR SELECT
  USING (status = 'active');

CREATE POLICY "Users can create vehicle requests"
  ON vehicle_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own vehicle requests"
  ON vehicle_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own vehicle requests"
  ON vehicle_requests FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Subscriptions policies
CREATE POLICY "Users can view their own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to check subscription status
CREATE OR REPLACE FUNCTION check_subscription_status()
RETURNS trigger AS $$
BEGIN
  -- Update subscription status based on end_date
  IF NEW.end_date < CURRENT_TIMESTAMP THEN
    NEW.status := 'expired';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add subscription status trigger
CREATE TRIGGER check_subscription_status
  BEFORE INSERT OR UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION check_subscription_status();